#!/usr/bin/env python3
"""Deterministic protocol fixture. Never contacts OpenAI or reads real credentials."""
import json, os, sys
from pathlib import Path
state = Path(os.environ['CODEX_HOME'])
signed_in = False
mode = 'normal'
number = 0
held = None
last_thread = None
catalog_mode = 'normal'

def send(obj):
    # Split in the middle of UTF-8/JSON to exercise the client's byte buffer.
    raw = (json.dumps(obj, ensure_ascii=False)+'\n').encode()
    for offset in range(0, len(raw), 13):
        sys.stdout.buffer.write(raw[offset:offset+13])
    sys.stdout.buffer.flush()

def reply(req, value): send({'id': req['id'], 'result': value})
def notify(method, params): send({'method': method, 'params': params})
def complete(thread, turn, status='completed'):
    notify('turn/completed', {'threadId':thread, 'turn':{'id':turn,'status':status,'error': {'message':'fixture failure'} if status=='failed' else None}})
def answer(thread, turn):
    notify('turn/started', {'threadId':thread, 'turn':{'id':turn}})
    notify('item/agentMessage/delta', {'threadId':thread,'turnId':turn,'itemId':'item-'+turn,'delta':'您好，'})
    notify('item/agentMessage/delta', {'threadId':thread,'turnId':turn,'itemId':'item-'+turn,'delta':'PDF 回答。'})
    notify('item/completed', {'threadId':thread,'turnId':turn,'item':{'type':'agentMessage','id':'item-'+turn,'text':'您好，PDF 回答。'}})
    complete(thread, turn)

for raw in sys.stdin:
    req = json.loads(raw)
    method = req.get('method'); params = req.get('params', {})
    if method is None:
        if req.get('id') == 99999:
            assert req.get('result', {}).get('decision') == 'decline'
            (state/'approval-denied').write_text('yes')
        continue
    if method == 'initialized': continue
    if method == 'initialize':
        assert params['clientInfo']['name'] == 'smartpdf_reader'
        assert 'forced_login_method="chatgpt"' in sys.argv
        assert 'features.shell_tool=false' in sys.argv
        reply(req, {})
    elif method == 'account/read': reply(req, {'account':{'type':'chatgpt','email':'fixture@example.invalid','planType':'plus'} if signed_in else None})
    elif method == 'skills/list': reply(req, {'data':[{'skills':[{'path':str(state/'skills/unrelated/SKILL.md'),'enabled':True}]}]})
    elif method == 'account/login/start': reply(req, {'type':'chatgpt','loginId':'login-fixture','authUrl':'https://auth.openai.com/authorize?fixture=1'})
    elif method == 'account/login/cancel':
        reply(req, {}); notify('account/login/completed', {'loginId':params['loginId'],'success':False})
    elif method == 'test/completeLogin':
        signed_in = True; reply(req, {})
        notify('account/login/completed', {'loginId':'login-fixture','success':True})
        notify('account/updated', {'authMode':'chatgpt'})
    elif method == 'model/list':
        levels = ['low','medium','high','xhigh'] if catalog_mode == 'normal' else ['low','medium']
        reply(req, {'data':[
            {'model':'fixture-model','displayName':'Fixture model','isDefault':True,'defaultReasoningEffort':'medium','supportedReasoningEfforts':[{'reasoningEffort':x,'description':x} for x in levels]},
            {'model':'restricted-model','displayName':'Restricted model','defaultReasoningEffort':'high','supportedReasoningEfforts':[{'reasoningEffort':'high'}]},
            {'model':'legacy-model','displayName':'Legacy model'}], 'nextCursor':None})
    elif method == 'test/catalog': catalog_mode=params['mode']; reply(req, {})
    elif method == 'account/logout':
        signed_in = False; reply(req, {}); notify('account/updated', {'authMode':None})
    elif method == 'test/mode': mode=params['mode']; reply(req, {})
    elif method == 'test/echo': reply(req, params)
    elif method == 'test/timeout': pass
    elif method == 'thread/start':
        number += 1
        assert params['sandbox'] == 'read-only' and params['ephemeral'] is True
        assert 'reference data' in params['baseInstructions']
        assert params['config']['skills.config'][0]['enabled'] is False
        assert params.get('model') == 'fixture-model'
        reply(req, {'thread':{'id':'thread-'+str(number)}})
    elif method == 'turn/start':
        last_thread = params['threadId']; turn='turn-'+str(number)
        assert params['sandboxPolicy'] == {'type':'readOnly','networkAccess':False}
        if params.get('model') == 'fixture-model': assert params.get('effort') in ['low','medium','high','xhigh']
        elif params.get('model') == 'restricted-model': assert params.get('effort') == 'high'
        elif params.get('model') == 'legacy-model': assert 'effort' not in params
        with (state/'requests.jsonl').open('a') as f: f.write(json.dumps(params,ensure_ascii=False)+'\n')
        if mode == 'delayed': held=(req,last_thread,turn); continue
        if mode == 'fast':
            answer(last_thread, turn)
            reply(req, {'turn':{'id':turn}})
        else:
            reply(req, {'turn':{'id':turn}})
            if mode == 'normal': answer(last_thread, turn)
            elif mode == 'failed': complete(last_thread,turn,'failed')
    elif method == 'test/release':
        if held:
            r,t,u=held; reply(r, {'turn':{'id':u}}); answer(t,u); held=None
        reply(req,{})
    elif method == 'turn/interrupt': reply(req, {}); complete(params['threadId'],params['turnId'],'interrupted')
    elif method == 'test/approval':
        send({'id':99999,'method':'item/commandExecution/requestApproval','params':{}}); reply(req,{})
    else: send({'id':req['id'],'error':{'code':-32601,'message':'Unknown fixture method'}})
