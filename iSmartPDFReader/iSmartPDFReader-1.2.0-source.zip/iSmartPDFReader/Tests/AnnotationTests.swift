import AppKit
import PDFKit
import SwiftUI

@main
struct AnnotationTests {
    static func descendants(_ view: NSView) -> [NSView] { [view] + view.subviews.flatMap(descendants) }
    static func cards(_ view: NSView) -> [NSView] { descendants(view).filter { $0.identifier?.rawValue.hasPrefix("spdf.note-card.") == true } }
    static func check(_ value: @autoclosure () -> Bool, _ message: String) {
        precondition(value(), message)
    }
    static func pause() async { try? await Task.sleep(nanoseconds: 150_000_000) }

    static func main() {
        let app = NSApplication.shared
        app.setActivationPolicy(.regular)
        let window = NSWindow(contentRect: NSRect(x: 140, y: 160, width: 1100, height: 800),
            styleMask: [.titled, .closable, .resizable], backing: .buffered, defer: false)
        window.title = "SmartPDF Annotation Checks"
        window.isReleasedWhenClosed = false
        let view = CustomPDFView(frame: NSRect(x: 0, y: 0, width: 1100, height: 800))
        let document = PDFDocument()
        let page = PDFPage(); page.setBounds(CGRect(x: 0, y: 0, width: 620, height: 800), for: .mediaBox)
        document.insert(page, at: 0)
        view.document = document
        view.autoScales = true
        view.displayMode = .singlePage
        window.contentView = view
        window.makeKeyAndOrderFront(nil)
        app.activate(ignoringOtherApps: true)
        Task { @MainActor in
            await pause()
            let body = "从对话拖入的文字应保持清晰。PDF 中的批注仍是文本，而非低清图片。\nThis is selectable vector text. Zoom in to inspect the edges.\n" + String(repeating: "中英文混排可自动换行，文字不再挤在一条细窄的文本框中。", count: 6)
            let dropped = view.addDroppedText(body, on: page, at: CGPoint(x: 80, y: 675))
            check(dropped.font?.pointSize == 11, "compact default font size")
            let color = dropped.fontColor!.usingColorSpace(.deviceRGB)!
            check(color.redComponent > 0.8 && color.greenComponent < 0.2, "drop defaults to red")
            check(dropped.bounds.height > 80, "multi-line drop must fit text")
            check(page.bounds(for: .mediaBox).contains(dropped.bounds), "drop stays on page")
            await pause()
            let textOverlay = descendants(view).compactMap { $0 as? ReadablePDFTextView }.first!
            let hitPoint = textOverlay.convert(CGPoint(x:textOverlay.bounds.midX,y:textOverlay.bounds.midY), to:textOverlay.superview)
            check(textOverlay.hitTest(hitPoint) === textOverlay, "crisp text must receive drag events")
            let beforeMove = dropped.bounds
            let pointInWindow = view.convert(view.convert(CGPoint(x:beforeMove.midX,y:beforeMove.midY),from:page),to:nil)
            @MainActor func event(_ type:NSEvent.EventType,_ point:CGPoint) -> NSEvent {
                NSEvent.mouseEvent(with:type,location:point,modifierFlags:[],timestamp:0,windowNumber:window.windowNumber,context:nil,eventNumber:1,clickCount:1,pressure:1)!
            }
            textOverlay.mouseDown(with:event(.leftMouseDown,pointInWindow))
            textOverlay.mouseDragged(with:event(.leftMouseDragged,CGPoint(x:pointInWindow.x+35,y:pointInWindow.y-20)))
            textOverlay.mouseUp(with:event(.leftMouseUp,CGPoint(x:pointInWindow.x+35,y:pointInWindow.y-20)))
            check(dropped.bounds != beforeMove, "text drag changes page position")
            view.performUndo()
            check(dropped.bounds == beforeMove && dropped.page === page, "undo moves text without undoing its creation")
            view.performRedo()
            check(dropped.bounds != beforeMove && dropped.page === page, "movement supports redo")
            view.performUndo()
            let menuPoint = view.convert(view.convert(CGPoint(x:80,y:390),from:page),to:nil)
            _ = view.menu(for:event(.rightMouseDown,menuPoint))
            view.addFreeText()
            await pause()
            let editor = descendants(view).compactMap { $0 as? NSTextView }.first { $0.isEditable }!
            editor.string = "右键添加的清晰红字 · Retina text"
            view.prepareForSaving()
            let manual = page.annotations.last { $0 is ReadablePDFTextAnnotation && $0 !== dropped }!
            check(manual.contents == editor.string && manual.font?.pointSize == 11, "right-click text uses same native/vector renderer")
            view.updateCalloutOverlaysForScaleChange()
            await pause()
            check(descendants(view).compactMap { $0 as? ReadablePDFTextView }.contains { $0.annotation === manual }, "right-click text has Retina display layer")
            let markdown = "## 观察与说明\n- **清晰显示**：支持中文、英文和长文本自动换行。\n- 独立标题栏，拖动标题即可移动卡片。\n- 点击铅笔编辑，点击勾号完成；原始 Markdown 保持完整。\n\nA readable note with proper wrapping and scrolling.\n\n" + String(repeating:"较长内容通过卡片内滚动查看，不会被压缩或与图标重叠。\n",count:10)
            let note = PDFAnnotation(bounds: CGRect(x: 575, y: 580, width: 14, height: 14), forType: .text, withProperties: nil)
            note.contents = markdown; note.color = .systemPurple; note.iconType = .comment
            page.addAnnotation(note)
            view.handleNoteDoubleClick(note)
            await pause()
            check(cards(view).count == 1, "first double click must show, not immediately hide")
            let first = cards(view)[0]
            check(view.bounds.insetBy(dx: 4, dy: 4).contains(view.convert(first.frame, from:first.superview)), "edge note card must stay in viewport")
            let text = descendants(first).compactMap { $0 as? NSTextView }.first!
            check(text.frame.width > 200 && text.frame.height > 100, "TextKit document view must have a real size")
            check(note.contents == markdown, "preview must preserve original markdown")
            let buttons = descendants(first).compactMap { $0 as? NSButton }
            let close = buttons.first { $0.toolTip == "收起批注" || $0.toolTip == "Collapse note" }!
            let point = first.convert(NSPoint(x: close.frame.midX,y: close.frame.midY), to:first.superview)
            let hit = first.hitTest(point)
            check(hit === close || hit?.isDescendant(of:close) == true, "title buttons must hit in parent coordinates")
            let edit = buttons.first { $0 !== close }!
            edit.performClick(nil)
            check(text.isEditable && text.string == markdown, "edit mode must expose original source")
            let changed = markdown + "\n新增内容 preserved."
            text.string = changed
            text.delegate?.textDidChange?(Notification(name:NSText.didChangeNotification,object:text))
            edit.performClick(nil)
            check(!text.isEditable && note.contents == changed, "editing commits without dropping markdown syntax")
            let oldSize = first.frame.size
            view.scaleFactor = max(0.4, view.scaleFactor * 0.65)
            view.updateCalloutOverlaysForScaleChange()
            await pause()
            check(first.frame.size == oldSize, "zoom must not shrink readable card typography")
            close.performClick(nil)
            check(cards(view).isEmpty, "collapse button removes card and focus")
            view.handleNoteDoubleClick(note)
            await pause()
            check(cards(view).count == 1, "reopen note")
            view.handleNoteDoubleClick(note)
            check(cards(view).isEmpty, "second double click hides")
            view.handleNoteDoubleClick(note)
            view.prepareForSaving()
            let root = URL(fileURLWithPath:CommandLine.arguments[1])
            let fixture = root.appendingPathComponent("Build/AnnotationFixture.pdf")
            let exportData = view.serializedDocumentData()!
            try! exportData.write(to:fixture)
            let reloaded = PDFDocument(url:fixture)!
            let exported = reloaded.page(at:0)!.annotations.first { $0.value(forAnnotationKey:.spdfSubject) as? String == ReadablePDFTextAnnotation.subject && $0.contents == body }!
            check(exported.contents == body && exported.font?.pointSize == 11 && exported.shouldDisplay, "text, visibility and font survive export")
            // Render the annotation itself at 1x and 3x using its vector draw path.
            for scale in [CGFloat(1),3] {
                let width = Int(dropped.bounds.width*scale), height = Int(dropped.bounds.height*scale)
                let bitmap = NSBitmapImageRep(bitmapDataPlanes:nil,pixelsWide:width,pixelsHigh:height,bitsPerSample:8,samplesPerPixel:4,hasAlpha:true,isPlanar:false,colorSpaceName:.deviceRGB,bytesPerRow:0,bitsPerPixel:0)!
                let context = NSGraphicsContext(bitmapImageRep:bitmap)!.cgContext
                context.setFillColor(NSColor.white.cgColor); context.fill(CGRect(x:0,y:0,width:width,height:height))
                context.scaleBy(x:scale,y:scale); context.translateBy(x:-dropped.bounds.minX,y:-dropped.bounds.minY)
                dropped.draw(with:.mediaBox,in:context)
                try! bitmap.representation(using:.png,properties:[:])!.write(to:root.appendingPathComponent("Build/AnnotationText-\(Int(scale))x.png"))
            }
            view.prepareForDocumentChange()
            check(cards(view).isEmpty, "switching PDFs removes all old overlays")
            view.document = reloaded; view.autoScales = true
            view.normalizeAnnotationsAfterLoad()
            view.restoreCalloutVisibilityStates()
            await pause()
            check(reloaded.page(at:0)!.annotations.contains { $0 is ReadablePDFTextAnnotation }, "reload restores crisp text renderer")
            // Tagged text must stay transparent even when PDFKit supplies its yellow fallback color.
            let reopenedText = reloaded.page(at:0)!.annotations.first { $0 is ReadablePDFTextAnnotation }!
            let transparency = NSBitmapImageRep(bitmapDataPlanes:nil,pixelsWide:340,pixelsHigh:300,bitsPerSample:8,samplesPerPixel:4,hasAlpha:true,isPlanar:false,colorSpaceName:.deviceRGB,bytesPerRow:0,bitsPerPixel:0)!
            let sample = NSGraphicsContext(bitmapImageRep:transparency)!.cgContext
            sample.setFillColor(NSColor.white.cgColor); sample.fill(CGRect(x:0,y:0,width:340,height:300))
            sample.translateBy(x:-reopenedText.bounds.minX,y:-reopenedText.bounds.minY)
            reopenedText.draw(with:.mediaBox,in:sample)
            let corner = transparency.colorAt(x:1,y:1)!.usingColorSpace(.deviceRGB)!
            check(corner.redComponent > 0.95 && corner.greenComponent > 0.95 && corner.blueComponent > 0.95, "reopened text must not acquire yellow fill")
            check(cards(view).count == 1, "saved note visibility restores once")
            check(reloaded.page(at:0)!.annotations.first { $0.type == "Text" }?.contents == changed, "note source survives export")
            // Check the same display mapping on rotated pages and on a second serialization.
            reloaded.page(at:0)!.rotation = 90
            view.layoutDocumentView()
            view.updateCalloutOverlaysForScaleChange()
            await pause()
            let rotatedOverlay = descendants(view).compactMap { $0 as? ReadablePDFTextView }.first!
            let rotatedAnnotation = rotatedOverlay.annotation!
            let mappedBounds = rotatedAnnotation.bounds.applying(rotatedOverlay.pageTransform)
            check(abs(mappedBounds.width - rotatedOverlay.bounds.width) < 1 && abs(mappedBounds.height - rotatedOverlay.bounds.height) < 1, "rotated text overlay mapping")
            let secondSave = PDFDocument(data:view.serializedDocumentData()!)!
            check(secondSave.page(at:0)!.annotations.first { $0.value(forAnnotationKey:.spdfSubject) as? String == ReadablePDFTextAnnotation.subject }!.shouldDisplay, "screen hiding must never leak into a saved PDF")
            reloaded.page(at:0)!.rotation = 0
            // Keep the fixture open for visual inspection at a comfortable scale.
            view.scaleFactor = 0.9
            view.updateCalloutOverlaysForScaleChange()
            await pause()
            check(descendants(view).contains { $0 is ReadablePDFTextView }, "Retina text overlay must be active")
            let pet = PaperSpriteView(frame:NSRect(x:20,y:window.contentView!.bounds.height-70,width:62,height:48))
            window.contentView!.addSubview(pet)
            var actions = Set<Int>()
            for _ in 0..<6 { pet.play(); actions.insert(pet.action) }
            check(actions.count == 6, "pet cycles distinct click actions")
            pet.tick()
            check(hypot(pet.gaze.x,pet.gaze.y) <= 2.41, "eye tracking stays inside eyes")
            if CommandLine.arguments.contains("--preview") {
                let sidebar = NSHostingView(rootView: VStack(spacing:0) {
                    SidebarHeader(title:"文档大纲",count:8)
                    MarkdownContentView(content:#"\*\*重点结论\*\* 与 **正常粗体**，保留 `a_b * c`。"#).padding(12)
                    Spacer()
                }.frame(width:240).background(Color(nsColor:.windowBackgroundColor)))
                sidebar.frame = NSRect(x:0,y:0,width:240,height:800)
                sidebar.autoresizingMask = [.height]; view.addSubview(sidebar)
                let chat = ChatGPTService()
                chat.documentName = "排版检查.pdf"
                chat.addMessage(role:"user",content:"简述主要结论")
                chat.addMessage(role:"assistant",content:#"\*\*重点结论\*\*：**正常粗体**与 `a_b * c` 都应正确显示。"# + "\n\n- 第一条结论\n- 第二条结论\n\n```swift\nlet value = 2 * 3\n```\n\n后续说明正常换行。")
                let chatView = NSHostingView(rootView:AIChatSidebar(aiService:chat))
                chatView.frame = NSRect(x:760,y:0,width:340,height:800)
                chatView.autoresizingMask = [.height,.minXMargin]; view.addSubview(chatView)
            }
            print("PASS: 11pt red text, native hit testing, dragging + undo, right-click text, Retina/vector rendering, note cards, PDF export/reload, rotation, document isolation, six pet actions and bounded eye tracking")
            fflush(stdout)
            if !CommandLine.arguments.contains("--preview") { app.terminate(nil) }
        }
        app.run()
    }
}
