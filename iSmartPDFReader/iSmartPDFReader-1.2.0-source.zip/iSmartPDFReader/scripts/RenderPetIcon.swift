import AppKit

// The standalone renderer uses the same native artwork as the live sidebar pet.
@MainActor func T(_ chinese: String, _ english: String) -> String { chinese }

@main
enum RenderPetIcon {
    @MainActor static func main() throws {
        let assets = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
        let metadata = try JSONSerialization.jsonObject(with: Data(contentsOf: assets.appendingPathComponent("Contents.json"))) as! [String: Any]
        let sprite = PaperSpriteView(frame: NSRect(x: 0, y: 0, width: 62, height: 48))
        for entry in metadata["images"] as? [[String: String]] ?? [] {
            guard let filename = entry["filename"], let size = entry["size"],
                  let points = Int(size.components(separatedBy: "x")[0]) else { continue }
            let pixels = points * (entry["scale"] == "2x" ? 2 : 1)
            let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: pixels, pixelsHigh: pixels,
                bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false,
                colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0)!
            let graphics = NSGraphicsContext(bitmapImageRep: bitmap)!
            let context = graphics.cgContext
            context.clear(CGRect(x: 0, y: 0, width: pixels, height: pixels))
            // Crop the animation's extra side margins for a recognizable square app icon.
            // Every size is drawn directly from paths, including the 1024px Retina icon.
            context.translateBy(x: 0, y: CGFloat(pixels))
            context.scaleBy(x: CGFloat(pixels) / 44, y: -CGFloat(pixels) / 44)
            context.translateBy(x: -9, y: -3)
            NSGraphicsContext.saveGraphicsState()
            NSGraphicsContext.current = graphics
            sprite.draw(sprite.bounds)
            NSGraphicsContext.restoreGraphicsState()
            try bitmap.representation(using: .png, properties: [:])!.write(to: assets.appendingPathComponent(filename))
        }
    }
}
