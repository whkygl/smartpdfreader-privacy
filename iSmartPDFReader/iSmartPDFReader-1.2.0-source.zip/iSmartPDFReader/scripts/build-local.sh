#!/bin/bash
set -euo pipefail
reader_root="$(cd "$(dirname "$0")/.." && pwd)"
reader_developer="${DEVELOPER_DIR:-/Library/Developer/CommandLineTools}"
reader_sdk="$reader_developer/SDKs/MacOSX26.5.sdk"
if [ ! -d "$reader_sdk" ]; then
    reader_sdk="$(DEVELOPER_DIR="$reader_developer" xcrun --sdk macosx --show-sdk-path)"
fi
reader_swift="$(DEVELOPER_DIR="$reader_developer" xcrun -f swiftc)"
reader_name="SmartPDF Reader ChatGPT"
reader_info="$reader_root/SmartPDFReader/Info.plist"
reader_entitlements="$reader_root/SmartPDFReader/SmartPDFReader.entitlements"
reader_marker="last-build-path.txt"
reader_conditions=()
if [ "${1:-}" = "--store-preview" ]; then
    reader_name="iSmartPDFReader Preview"
    reader_info="$reader_root/AppStore/Info.plist"
    reader_entitlements="$reader_root/AppStore/iSmartPDFReader.entitlements"
    reader_conditions=(-D APP_STORE)
    reader_marker="last-store-preview-path.txt"
elif [ -n "${1:-}" ]; then
    printf 'Usage: %s [--store-preview]\n' "$0" >&2
    exit 2
fi
reader_output="$reader_root/Build/$reader_name.app"
# Sign outside the Desktop FileProvider domain, which can reattach Finder metadata mid-sign.
reader_stage="$(mktemp -d "${TMPDIR:-/tmp}/SmartPDFReader-build.XXXXXX")"
reader_app="$reader_stage/$reader_name.app"
mkdir -p "$reader_root/Build"
mkdir -p "$reader_app/Contents/MacOS" "$reader_app/Contents/Resources"
"$reader_swift" -swift-version 5 -default-isolation MainActor -sdk "$reader_sdk" \
    "$reader_root/SmartPDFReader/SidebarPet.swift" "$reader_root/scripts/RenderPetIcon.swift" \
    -o "$reader_stage/RenderPetIcon"
"$reader_stage/RenderPetIcon" "$reader_root/SmartPDFReader/Assets.xcassets/AppIcon.appiconset"
"$reader_swift" -O -swift-version 5 -default-isolation MainActor "${reader_conditions[@]}" \
    -sdk "$reader_sdk" -target "$(uname -m)-apple-macosx14.0" \
    "$reader_root"/SmartPDFReader/*.swift -o "$reader_app/Contents/MacOS/SmartPDFReader"
cp "$reader_info" "$reader_app/Contents/Info.plist"
if [ "${1:-}" = "--store-preview" ]; then
    /usr/libexec/PlistBuddy -c 'Set :CFBundleExecutable SmartPDFReader' "$reader_app/Contents/Info.plist"
    /usr/libexec/PlistBuddy -c 'Set :CFBundleIdentifier KunguangWang.SmartPDFReader.StorePreview' "$reader_app/Contents/Info.plist"
    /usr/libexec/PlistBuddy -c 'Set :CFBundleDisplayName iSmartPDFReader Preview' "$reader_app/Contents/Info.plist"
fi
cp "$reader_root/SmartPDFReader/PrivacyInfo.xcprivacy" "$reader_app/Contents/Resources/"
cp "$reader_root/SmartPDFReader/License.txt" "$reader_app/Contents/Resources/"
cp "$reader_root/SmartPDFReader/PDFDocument.icns" "$reader_app/Contents/Resources/"
# Export named images directly so this build works without Xcode's asset compiler.
python3 - "$reader_root" "$reader_app" <<'PY'
from pathlib import Path
import json, shutil, sys
root, app = map(Path, sys.argv[1:])
resources = app / 'Contents/Resources'
assets = root / 'SmartPDFReader/Assets.xcassets'
for group in assets.glob('*.imageset'):
    for image in json.loads((group/'Contents.json').read_text()).get('images', []):
        if not image.get('filename'): continue
        scale = image.get('scale', '1x')
        suffix = '' if scale == '1x' else '@'+scale
        shutil.copyfile(group/image['filename'], resources/(group.stem+suffix+'.png'))
iconset = root/'Build/AppIcon.iconset'
iconset.mkdir(exist_ok=True)
for icon in (assets/'AppIcon.appiconset').glob('*.png'):
    shutil.copyfile(icon, iconset/icon.name)
PY
iconutil -c icns "$reader_root/Build/AppIcon.iconset" -o "$reader_app/Contents/Resources/AppIcon.icns"
xattr -cr "$reader_app"
codesign --force --sign - --entitlements "$reader_entitlements" "$reader_app"
codesign --verify --deep --strict "$reader_app"
ditto --noextattr --norsrc --noqtn "$reader_app" "$reader_output"
printf '%s\n' "$reader_app" > "$reader_root/Build/$reader_marker"
printf 'Built: %s\n' "$reader_app"
