#!/bin/bash
set -euo pipefail
reader_root="$(cd "$(dirname "$0")/.." && pwd)"
reader_archive="$reader_root/Build/iSmartPDFReader.xcarchive"
reader_export="$reader_root/Build/AppStoreExport"
cd "$reader_root"
xcodebuild -project SmartPDFReader.xcodeproj -scheme iSmartPDFReader-Store \
    -configuration Release -xcconfig AppStore/Release.xcconfig \
    -destination 'generic/platform=macOS' -archivePath "$reader_archive" \
    -allowProvisioningUpdates archive
xcodebuild -exportArchive -archivePath "$reader_archive" \
    -exportPath "$reader_export" -exportOptionsPlist AppStore/ExportOptions.plist \
    -allowProvisioningUpdates
