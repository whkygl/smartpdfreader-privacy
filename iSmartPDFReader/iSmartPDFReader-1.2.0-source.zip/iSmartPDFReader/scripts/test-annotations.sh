#!/bin/bash
set -euo pipefail
reader_root="$(cd "$(dirname "$0")/.." && pwd)"
reader_developer="${DEVELOPER_DIR:-/Library/Developer/CommandLineTools}"
reader_sdk="$reader_developer/SDKs/MacOSX26.5.sdk"
if [ ! -d "$reader_sdk" ]; then reader_sdk="$(DEVELOPER_DIR="$reader_developer" xcrun --sdk macosx --show-sdk-path)"; fi
reader_swift="$(DEVELOPER_DIR="$reader_developer" xcrun -f swiftc)"
reader_test="$reader_root/Build/SmartPDF Annotation Checks.app"
mkdir -p "$reader_test/Contents/MacOS"
"$reader_swift" -swift-version 5 -default-isolation MainActor -sdk "$reader_sdk" -D ANNOTATION_TESTS \
    "$reader_root"/SmartPDFReader/*.swift "$reader_root/Tests/AnnotationTests.swift" \
    -o "$reader_test/Contents/MacOS/AnnotationTests"
python3 - "$reader_test" <<'PY'
import plistlib,sys
from pathlib import Path
(Path(sys.argv[1])/'Contents/Info.plist').write_bytes(plistlib.dumps({'CFBundleExecutable':'AnnotationTests','CFBundleIdentifier':'local.smartpdf.annotation-checks','CFBundleName':'SmartPDF Annotation Checks','CFBundlePackageType':'APPL'}))
PY
"$reader_test/Contents/MacOS/AnnotationTests" "$reader_root" "$@"
python3 - "$reader_root/Build/AnnotationFixture.pdf" <<'PY'
from pathlib import Path
import re,sys,zlib
payload = Path(sys.argv[1]).read_bytes()
objects = {int(m[1]): m[2] for m in re.finditer(rb'(\d+) 0 obj\s*(.*?)endobj', payload, re.S)}
tagged = next(o for o in objects.values() if b'(SPDF_DROPPED_TEXT)' in o)
ap = int(re.search(rb'/AP (\d+) 0 R', tagged)[1])
stream_id = int(re.search(rb'/N (\d+) 0 R', objects[ap])[1])
stream = objects[stream_id]
data = stream.split(b'stream',1)[1].lstrip(b'\r\n').rsplit(b'endstream',1)[0].rstrip(b'\r\n')
if b'FlateDecode' in stream: data = zlib.decompress(data)
assert b'BT' in data and (b'Tj' in data or b'TJ' in data)
assert b'/Subtype /Image' not in payload
print('PASS: exported annotation contains vector text operators and no raster image objects')
PY
