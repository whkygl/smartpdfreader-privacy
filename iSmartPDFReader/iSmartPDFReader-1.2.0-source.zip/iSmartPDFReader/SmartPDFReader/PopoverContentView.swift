import SwiftUI

// MARK: - 占位视图
// 由于我们已升级为 AI 侧边栏交互模式，原有的弹出式翻译视图不再使用。
// 保留此文件定义是为了防止 Xcode 项目因找不到文件而报错。
struct PopoverContentView: View {
    // 这里的 Service 引用保留以兼容可能的旧代码引用，但不再实际读取其属性
    @ObservedObject var aiService: ChatGPTService
    
    var body: some View {
        // 返回空视图，因为它不会被显示
        EmptyView()
    }
}
