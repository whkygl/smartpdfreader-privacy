import Foundation
import AppKit
import SystemConfiguration
import Combine

/// Local JSONL client for the official Codex app-server. Passwords and tokens never enter the UI.
#if !APP_STORE
@MainActor
final class ChatGPTClient: ObservableObject {
    static let shared = ChatGPTClient()

    struct Model: Identifiable, Equatable {
        let id: String
        let name: String
        let reasoningEfforts: [String]
        let defaultReasoningEffort: String?
    }
    enum AccountState { case disconnected, signedOut, signingIn, signedIn }
    enum ClientError: LocalizedError {
        case message(String)
        var errorDescription: String? { if case .message(let text) = self { return text }; return nil }
    }

    @Published private(set) var state: AccountState = .disconnected
    @Published private(set) var email = ""
    @Published private(set) var plan = ""
    @Published private(set) var models: [Model] = []
    @Published var selectedModel: String = "" {
        didSet { defaults.set(selectedModel, forKey: "chatgptModel") }
    }
    @Published private var reasoningPreferences: [String: String] = [:] {
        didSet { defaults.set(reasoningPreferences, forKey: "chatgptReasoningEfforts") }
    }
    var availableReasoningEfforts: [String] {
        models.first(where: { $0.id == selectedModel })?.reasoningEfforts ?? []
    }
    var selectedReasoningEffort: String {
        get {
            let supported = availableReasoningEfforts
            if let saved = reasoningPreferences[selectedModel], supported.contains(saved) { return saved }
            // Prefer a short reasoning budget for everyday reading, without inventing unsupported levels.
            for fast in ["low", "minimal", "none"] where supported.contains(fast) { return fast }
            if let suggested = models.first(where: { $0.id == selectedModel })?.defaultReasoningEffort,
               supported.contains(suggested) { return suggested }
            return supported.first ?? ""
        }
        set {
            guard availableReasoningEfforts.contains(newValue) else { return }
            reasoningPreferences[selectedModel] = newValue
        }
    }

    func reasoningLabel(_ effort: String) -> String {
        switch effort {
        case "none": return T("无推理（最快）", "None (fastest)")
        case "minimal": return T("极低（更快）", "Minimal (faster)")
        case "low": return T("低（快速）", "Low (fast)")
        case "medium": return T("中（均衡）", "Medium (balanced)")
        case "high": return T("高（深入）", "High (deep)")
        case "xhigh": return T("超高", "Extra high")
        case "max": return T("最高", "Maximum")
        case "ultra": return T("极致", "Ultra")
        default: return effort
        }
    }
    @Published var errorMessage: String?
    @Published private(set) var executablePath = ""
    @Published private(set) var isConnecting = false
    let events = PassthroughSubject<[String: Any], Never>()

    let stateDirectory: URL
    let workingDirectory: URL
    private let executableOverride: URL?
    private let defaults: UserDefaults
    private let openURL: (URL) -> Bool
    private var process: Process?
    private var input: FileHandle?
    private var output: FileHandle?
    private var buffer = Data()
    private var nextID = 0
    private var pending: [Int: CheckedContinuation<[String: Any], Error>] = [:]
    private var timers: [Int: Task<Void, Never>] = [:]
    private var connectionTask: Task<Void, Error>?
    private var generation = UUID()
    private var loginID: String?
    private(set) var readerThreadConfiguration: [String: Any] = [:]

    init(executable: URL? = nil, stateDirectory: URL? = nil, defaults: UserDefaults = .standard, openURL: ((URL) -> Bool)? = nil) {
        self.defaults = defaults
        self.openURL = openURL ?? { NSWorkspace.shared.open($0) }
        executableOverride = executable
        self.stateDirectory = stateDirectory ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("SmartPDFReader-ChatGPT", isDirectory: true)
        workingDirectory = self.stateDirectory.appendingPathComponent("Reader", isDirectory: true)
        selectedModel = defaults.string(forKey: "chatgptModel") ?? ""
        reasoningPreferences = defaults.dictionary(forKey: "chatgptReasoningEfforts") as? [String: String] ?? [:]
    }

    var isSignedIn: Bool { state == .signedIn }
    var statusText: String {
        if isConnecting { return T("正在连接…", "Connecting…") }
        switch state {
        case .disconnected: return T("尚未连接", "Disconnected")
        case .signedOut: return T("请登录 ChatGPT", "Sign in to ChatGPT")
        case .signingIn: return T("请在浏览器完成登录", "Complete sign-in in your browser")
        case .signedIn: return email.isEmpty ? T("已登录 ChatGPT", "Signed in to ChatGPT") : email
        }
    }

    func connect() async throws {
        if let task = connectionTask { return try await task.value }
        if process?.isRunning == true { return }
        isConnecting = true
        errorMessage = nil
        let task = Task { try await self.launch() }
        connectionTask = task
        defer { connectionTask = nil; isConnecting = false }
        do { try await task.value }
        catch { disconnect(); errorMessage = error.localizedDescription; throw error }
    }

    func refresh() {
        Task {
            do {
                try await connect()
                try await readAccount()
                if isSignedIn { try await loadModels() }
            } catch { errorMessage = error.localizedDescription }
        }
    }

    func signIn() {
        guard state != .signingIn, !isConnecting else { return }
        Task {
            do {
                try await connect()
                errorMessage = nil
                let result = try await request("account/login/start", ["type": "chatgpt"])
                guard let id = result["loginId"] as? String,
                      let rawURL = result["authUrl"] as? String, let url = URL(string: rawURL),
                      url.scheme == "https", let host = url.host,
                      host == "auth.openai.com" || host == "chatgpt.com" else {
                    throw ClientError.message(T("未收到有效的官方登录链接，请更新 Codex 后重试。", "No valid official sign-in URL. Update Codex and try again."))
                }
                loginID = id
                state = .signingIn
                guard openURL(url) else {
                    await cancelLogin()
                    throw ClientError.message(T("无法打开默认浏览器。", "Could not open the default browser."))
                }
            } catch { errorMessage = error.localizedDescription }
        }
    }

    func cancelLogin() async {
        guard let id = loginID else { return }
        loginID = nil
        _ = try? await request("account/login/cancel", ["loginId": id])
        if !isSignedIn { state = .signedOut }
    }

    func signOut() {
        Task {
            do {
                if state == .signingIn { await cancelLogin() }
                _ = try await request("account/logout", [:])
                state = .signedOut; email = ""; plan = ""; models = []
                events.send(["method": "reader/accountCleared"])
            } catch { errorMessage = error.localizedDescription }
        }
    }

    func chooseExecutable() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = false
        panel.treatsFilePackagesAsDirectories = true
        panel.message = T("选择官方 Codex 可执行文件（codex）", "Choose the official Codex executable (codex)")
        guard panel.runModal() == .OK, let url = panel.url,
              FileManager.default.isExecutableFile(atPath: url.path) else { return }
        defaults.set(url.path, forKey: "chatgptCodexPath")
        disconnect()
        refresh()
    }

    private func locateExecutable() -> URL? {
        if let override = executableOverride { return override }
        let custom = defaults.string(forKey: "chatgptCodexPath") ?? ""
        let candidates = [custom,
            "/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex",
            "/Applications/Codex.app/Contents/Resources/codex",
            "/Applications/Codex.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex",
            "/opt/homebrew/bin/codex", "/usr/local/bin/codex",
            FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent(".local/bin/codex").path]
        return candidates.first { !$0.isEmpty && FileManager.default.isExecutableFile(atPath: $0) }.map { URL(fileURLWithPath: $0) }
    }

    private func launch() async throws {
        guard let executable = locateExecutable() else {
            throw ClientError.message(T("未找到 Codex。请安装官方 Codex CLI，或在设置中选择 codex 文件。", "Codex was not found. Install the official Codex CLI or choose its executable in Settings."))
        }
        let fm = FileManager.default
        try fm.createDirectory(at: workingDirectory, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        try fm.setAttributes([.posixPermissions: 0o700], ofItemAtPath: stateDirectory.path)
        let p = Process()
        p.executableURL = executable
        let settings = [
            "forced_login_method=\"chatgpt\"", "cli_auth_credentials_store=\"file\"",
            "features.shell_tool=false", "features.apply_patch_freeform=false",
            "features.multi_agent=false", "features.apps=false", "features.hooks=false",
            "features.remote_plugin=false", "features.shell_snapshot=false",
            "agents.enabled=false",
            "web_search=\"disabled\"", "mcp_servers={}", "analytics.enabled=false"
        ]
        p.arguments = ["app-server", "--listen", "stdio://"] + settings.flatMap { ["-c", $0] }
        // Use this application's state, never the user's Codex credentials or project configuration.
        var environment = ProcessInfo.processInfo.environment.filter {
            !$0.key.hasPrefix("CODEX_") && !$0.key.hasPrefix("OPENAI_") && $0.key != "ACCESS_TOKEN"
        }
        environment = Self.applyingSystemProxy(to: environment)
        environment["CODEX_HOME"] = stateDirectory.path
        p.environment = environment
        p.currentDirectoryURL = workingDirectory
        let stdin = Pipe(), stdout = Pipe(), stderr = Pipe()
        p.standardInput = stdin; p.standardOutput = stdout; p.standardError = stderr
        let token = UUID(); generation = token
        stdout.fileHandleForReading.readabilityHandler = { [weak self] handle in
            let chunk = handle.availableData
            if chunk.isEmpty { handle.readabilityHandler = nil; return }
            DispatchQueue.main.async {
                guard let self, self.generation == token else { return }
                if chunk.isEmpty { return }
                self.consume(chunk)
            }
        }
        // Drain diagnostics without writing login URLs, tokens, or document text to application logs.
        stderr.fileHandleForReading.readabilityHandler = { handle in
            if handle.availableData.isEmpty { handle.readabilityHandler = nil }
        }
        p.terminationHandler = { [weak self] _ in
            DispatchQueue.main.async {
                guard let self, self.generation == token else { return }
                self.disconnect()
                self.errorMessage = T("连接已断开，请点“重新连接”。", "Connection closed. Select Reconnect.")
            }
        }
        process = p; input = stdin.fileHandleForWriting; output = stdout.fileHandleForReading
        try p.run()
        executablePath = executable.path
        _ = try await request("initialize", ["clientInfo": ["name": "smartpdf_reader", "title": "SmartPDF Reader", "version": "1.1.5"]])
        try write(["method": "initialized", "params": [:]])
        // Disable the discovered catalog for reader threads, without changing global Codex settings.
        if let catalog = try? await request("skills/list", ["cwds": [workingDirectory.path]], timeout: 5) {
            let skills = (catalog["data"] as? [[String: Any]] ?? []).flatMap { $0["skills"] as? [[String: Any]] ?? [] }
            let paths = Set(skills.compactMap { $0["path"] as? String })
            readerThreadConfiguration = ["skills.config": paths.sorted().map { ["path": $0, "enabled": false] as [String: Any] }]
        }
        try await readAccount()
        if isSignedIn { try await loadModels() }
    }

    /// Native web views use macOS proxies; command-line HTTP clients generally require env vars.
    /// Bridge the user's existing system configuration for this child process only.
    static func applyingSystemProxy(to environment: [String: String], settings: [String: Any]? = nil) -> [String: String] {
        var result = environment
        let config = settings ?? (SCDynamicStoreCopyProxies(nil) as? [String: Any] ?? [:])
        if environment["ALL_PROXY"] != nil || environment["all_proxy"] != nil { return result }
        for (prefix, variable) in [("HTTP", "HTTP_PROXY"), ("HTTPS", "HTTPS_PROXY")] {
            guard environment[variable] == nil, environment[variable.lowercased()] == nil,
                  (config[prefix + "Enable"] as? NSNumber)?.boolValue == true,
                  let host = config[prefix + "Proxy"] as? String, !host.isEmpty,
                  let port = config[prefix + "Port"] as? Int, (1...65535).contains(port) else { continue }
            var url = URLComponents(); url.scheme = "http"; url.host = host; url.port = port
            if let value = url.string { result[variable] = value }
        }
        if result["NO_PROXY"] == nil && result["no_proxy"] == nil,
           result["HTTP_PROXY"] != nil || result["HTTPS_PROXY"] != nil {
            let exceptions = (config["ExceptionsList"] as? [String] ?? []).filter { $0 != "<local>" }
                .map { $0.replacingOccurrences(of: "*.", with: ".") }
            result["NO_PROXY"] = (["localhost", "127.0.0.1", "::1"] + exceptions).joined(separator: ",")
        }
        return result
    }

    private func readAccount() async throws {
        let result = try await request("account/read", ["refreshToken": false])
        if let account = result["account"] as? [String: Any], account["type"] as? String == "chatgpt" {
            email = account["email"] as? String ?? ""
            plan = account["planType"] as? String ?? ""
            state = .signedIn
        } else if state != .signingIn {
            state = .signedOut; email = ""; plan = ""
        }
    }

    func loadModels() async throws {
        var all: [Model] = [], cursor: String?
        repeat {
            var params: [String: Any] = ["includeHidden": false, "limit": 100]
            if let cursor { params["cursor"] = cursor }
            let result = try await request("model/list", params)
            for model in result["data"] as? [[String: Any]] ?? [] {
                guard let id = model["model"] as? String ?? model["id"] as? String else { continue }
                let efforts = (model["supportedReasoningEfforts"] as? [[String: Any]] ?? [])
                    .compactMap { $0["reasoningEffort"] as? String }
                    .filter { !$0.isEmpty }
                all.append(Model(id: id, name: model["displayName"] as? String ?? id,
                    reasoningEfforts: Array(NSOrderedSet(array: efforts)) as? [String] ?? efforts,
                    defaultReasoningEffort: model["defaultReasoningEffort"] as? String))
                if selectedModel.isEmpty && model["isDefault"] as? Bool == true { selectedModel = id }
            }
            let next = result["nextCursor"] as? String
            if next == cursor { break }
            cursor = next
        } while cursor != nil
        models = all
        if !models.contains(where: { $0.id == selectedModel }) { selectedModel = models.first?.id ?? "" }
    }

    func request(_ method: String, _ params: [String: Any], timeout: UInt64 = 30) async throws -> [String: Any] {
        guard process?.isRunning == true else { throw ClientError.message(T("请先连接 ChatGPT。", "Connect to ChatGPT first.")) }
        nextID += 1
        let id = nextID
        return try await withCheckedThrowingContinuation { continuation in
            pending[id] = continuation
            timers[id] = Task { [weak self] in
                do { try await Task.sleep(nanoseconds: timeout * 1_000_000_000) } catch { return }
                self?.finish(id, .failure(ClientError.message(T("连接超时，请检查网络后重试。", "Connection timed out. Check your network and retry."))))
            }
            do { try write(["id": id, "method": method, "params": params]) }
            catch { finish(id, .failure(error)) }
        }
    }

    private func write(_ object: [String: Any]) throws {
        guard let input else { throw ClientError.message(T("连接已关闭。", "Connection is closed.")) }
        var bytes = try JSONSerialization.data(withJSONObject: object)
        bytes.append(0x0A)
        try input.write(contentsOf: bytes)
    }

    private func finish(_ id: Int, _ result: Result<[String: Any], Error>) {
        timers.removeValue(forKey: id)?.cancel()
        pending.removeValue(forKey: id)?.resume(with: result)
    }

    private func consume(_ data: Data) {
        buffer.append(data)
        while let end = buffer.firstIndex(of: 0x0A) {
            let line = buffer[..<end]; buffer.removeSubrange(...end)
            guard let object = try? JSONSerialization.jsonObject(with: line) as? [String: Any] else { continue }
            if let method = object["method"] as? String {
                let params = object["params"] as? [String: Any] ?? [:]
                if let id = object["id"] {
                    // This reader never approves commands, edits, or external tool access.
                    let result: [String: Any]
                    if method.hasSuffix("requestApproval") { result = ["decision": "decline"] }
                    else {
                        try? write(["id": id, "error": ["code": -32601, "message": "PDF reader does not provide tools"]])
                        continue
                    }
                    try? write(["id": id, "result": result]); continue
                }
                if method == "account/login/completed", let id = params["loginId"] as? String, id == loginID {
                    loginID = nil
                    if params["success"] as? Bool == true { state = .signedOut; refresh() }
                    else { state = .signedOut; errorMessage = T("登录未完成，请重试。", "Sign-in did not complete. Please try again.") }
                } else if method == "account/updated" {
                    if params["authMode"] is NSNull {
                        state = .signedOut; email = ""; plan = ""; models = []
                        events.send(["method": "reader/accountCleared"])
                    } else if params["authMode"] as? String == "chatgpt" { refresh() }
                }
                events.send(object)
            } else if let id = object["id"] as? Int {
                if let error = object["error"] as? [String: Any] {
                    finish(id, .failure(ClientError.message(error["message"] as? String ?? T("请求失败。", "Request failed."))))
                } else { finish(id, .success(object["result"] as? [String: Any] ?? [:])) }
            }
        }
    }

    func disconnect() {
        generation = UUID()
        output?.readabilityHandler = nil
        process?.terminationHandler = nil
        if process?.isRunning == true { process?.terminate() }
        try? input?.close(); input = nil; output = nil; process = nil; buffer.removeAll()
        for id in Array(pending.keys) { finish(id, .failure(ClientError.message(T("连接已关闭。", "Connection closed.")))) }
        state = .disconnected; loginID = nil; email = ""; plan = ""; models = []
        events.send(["method": "reader/disconnected"])
    }
}

#endif

@MainActor
func T(_ chinese: String, _ english: String) -> String {
    LocalizationManager.shared.currentLanguage == .chinese ? chinese : english
}
