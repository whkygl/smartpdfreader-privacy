import SwiftUI
import AppKit

/// A tiny paper sprite, rendered with native paths so it stays sharp on every display.
struct SidebarPet: NSViewRepresentable {
    func makeNSView(context: Context) -> PaperSpriteView { PaperSpriteView() }
    func updateNSView(_ nsView: PaperSpriteView, context: Context) {}
}

final class PaperSpriteView: NSView {
    private var timer: Timer?
    private var started: TimeInterval = 0
    private(set) var action = -1
    private(set) var gaze = CGPoint.zero
    private var nextActions: [Int] = []
    private var previousAction = -1
    private var clock: TimeInterval { ProcessInfo.processInfo.systemUptime }
    override var isFlipped: Bool { true }
    override var intrinsicContentSize: NSSize { NSSize(width: 78, height: 60) }

    override init(frame: NSRect) {
        super.init(frame: frame)
        toolTip = T("页灵 · 点我玩一下", "Page sprite · Click to play")
        setAccessibilityElement(true)
        setAccessibilityRole(.button)
        setAccessibilityLabel(T("页灵，点击切换动作", "Page sprite, click for a new action"))
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        timer?.invalidate(); timer = nil
        if window != nil {
            let t = Timer(timeInterval: 1.0 / 30, repeats: true) { [weak self] _ in self?.tick() }
            RunLoop.main.add(t, forMode: .common); timer = t
        }
    }
    deinit { timer?.invalidate() }
    override func resetCursorRects() { addCursorRect(bounds, cursor: .pointingHand) }
    override func mouseDown(with event: NSEvent) { play() }
    override func accessibilityPerformPress() -> Bool { play(); return true }

    func play() {
        if nextActions.isEmpty {
            nextActions = Array(0..<6).shuffled()
            if nextActions.first == previousAction { nextActions.swapAt(0, 1) }
        }
        action = nextActions.removeFirst()
        previousAction = action
        setAccessibilityValue([T("跳跃", "Bounce"), T("翻转", "Tumble"), T("眨眼", "Wink"), T("伸懒腰", "Stretch"), T("招手", "Wave"), T("星光舞", "Sparkle dance")][action])
        started = clock; needsDisplay = true
    }

    func tick() {
        guard let window, window.isVisible, !isHiddenOrHasHiddenAncestor else { return }
        let mouse = convert(window.convertPoint(fromScreen: NSEvent.mouseLocation), from: nil)
        let dx = mouse.x - bounds.midX, dy = mouse.y - bounds.midY
        let distance = max(1, hypot(dx, dy))
        let strength = min(1, distance / 70)
        let next = CGPoint(x: dx / distance * 2.4 * strength, y: dy / distance * 2.4 * strength)
        if abs(next.x - gaze.x) + abs(next.y - gaze.y) > 0.03 { gaze = next; needsDisplay = true }
        if action >= 0 {
            if clock - started >= 1.25 { action = -1 }
            needsDisplay = true
        }
    }

    override func draw(_ dirtyRect: NSRect) {
        guard let c = NSGraphicsContext.current?.cgContext else { return }
        c.saveGState()
        defer { c.restoreGState() }
        // Scale the artwork itself, rather than adding empty space around a fixed-size pet.
        let scale = min(bounds.width / 62, bounds.height / 48)
        c.translateBy(x: bounds.midX - 31 * scale, y: bounds.midY - 24 * scale)
        c.scaleBy(x: scale, y: scale)
        c.setShouldAntialias(true)
        let elapsed = clock - started
        let t = max(0, min(1, elapsed / 1.25))
        let wave = sin(t * .pi)
        let reduce = NSWorkspace.shared.accessibilityDisplayShouldReduceMotion
        let accent = NSColor(srgbRed: 0.16, green: 0.67, blue: 0.62, alpha: 1)
        let ink = NSColor(srgbRed: 0.12, green: 0.21, blue: 0.27, alpha: 1)

        // Ground shadow remains still while the sprite jumps or tumbles.
        c.setFillColor(accent.withAlphaComponent(0.13).cgColor)
        c.fillEllipse(in: CGRect(x: 14, y: 42, width: 34, height: 4))
        c.saveGState()
        c.translateBy(x: 31, y: 25)
        if !reduce {
            switch action {
            case 0: c.translateBy(x: 0, y: -12 * abs(sin(t * .pi * 2)))
            case 1: c.rotate(by: t * .pi * 2)
            case 3: c.scaleBy(x: 1 + 0.2 * wave, y: 1 - 0.2 * wave)
            case 4: c.rotate(by: sin(t * .pi * 6) * 0.18)
            case 5: c.translateBy(x: sin(t * .pi * 4) * 6, y: -4 * wave)
            default: break
            }
        }
        // Rounded sheet with a folded corner and two little feet.
        c.setFillColor(accent.cgColor)
        c.fillEllipse(in: CGRect(x: -12, y: 14, width: 9, height: 5))
        c.fillEllipse(in: CGRect(x: 4, y: 14, width: 9, height: 5))
        let body = CGPath(roundedRect: CGRect(x: -17, y: -18, width: 34, height: 35), cornerWidth: 10, cornerHeight: 10, transform: nil)
        c.addPath(body); c.setFillColor(NSColor(srgbRed: 0.88, green: 0.97, blue: 0.95, alpha: 1).cgColor)
        c.setStrokeColor(accent.withAlphaComponent(0.65).cgColor); c.setLineWidth(1.1); c.drawPath(using: .fillStroke)
        c.move(to: CGPoint(x: 6, y: -18)); c.addLine(to: CGPoint(x: 15, y: -9)); c.addLine(to: CGPoint(x: 8, y: -9)); c.closePath()
        c.setFillColor(accent.withAlphaComponent(0.5).cgColor); c.fillPath()
        // A raised arm and a sparkle appear during the wave.
        if action == 4 || action == 5 {
            c.setStrokeColor(accent.cgColor); c.setLineWidth(2); c.setLineCap(.round)
            c.move(to: CGPoint(x: 16, y: 3)); c.addQuadCurve(to: CGPoint(x: 23, y: -6 - 4 * wave), control: CGPoint(x: 24, y: 3)); c.strokePath()
        }
        for x: CGFloat in [-7, 7] {
            c.setFillColor(NSColor.white.cgColor); c.fillEllipse(in: CGRect(x: x - 5, y: -8, width: 10, height: 12))
            if action == 2 && x > 0 && t > 0.15 && t < 0.8 {
                c.setStrokeColor(ink.cgColor); c.setLineWidth(1.7); c.setLineCap(.round)
                c.move(to: CGPoint(x: x - 3, y: -1)); c.addLine(to: CGPoint(x: x + 3, y: -1)); c.strokePath()
            } else {
                c.setFillColor(ink.cgColor)
                c.fillEllipse(in: CGRect(x: x - 2.1 + gaze.x, y: -4 + gaze.y, width: 4.2, height: 5.2))
                c.setFillColor(NSColor.white.cgColor)
                c.fillEllipse(in: CGRect(x: x - 0.9 + gaze.x, y: -3.2 + gaze.y, width: 1.2, height: 1.2))
            }
        }
        c.setStrokeColor(ink.cgColor); c.setLineWidth(1.1); c.setLineCap(.round)
        c.move(to: CGPoint(x: -3, y: 8)); c.addQuadCurve(to: CGPoint(x: 3, y: 8), control: CGPoint(x: 0, y: 11)); c.strokePath()
        c.restoreGState()
        if action == 5 {
            c.setStrokeColor(NSColor.systemOrange.withAlphaComponent(wave).cgColor); c.setLineWidth(1.4)
            for p in [CGPoint(x: 9, y: 10), CGPoint(x: 52, y: 9)] {
                c.move(to: CGPoint(x: p.x - 3, y: p.y)); c.addLine(to: CGPoint(x: p.x + 3, y: p.y))
                c.move(to: CGPoint(x: p.x, y: p.y - 3)); c.addLine(to: CGPoint(x: p.x, y: p.y + 3)); c.strokePath()
            }
        }
    }
}
