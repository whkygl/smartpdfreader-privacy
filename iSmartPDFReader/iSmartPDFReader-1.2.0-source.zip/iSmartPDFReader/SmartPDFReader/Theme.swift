import SwiftUI

// MARK: - 🎨 Premium Design System
// 设计理念: 现代极简 + 精致奢华 + 流畅动效
// 灵感来源: Linear, Raycast, Arc Browser, Notion

struct Theme {
    
    // MARK: - 🌈 Colors - 深邃优雅的配色系统
    struct Colors {
        // ═══════════════════════════════════════════════════════════════
        // 主色调 - 深邃的靛蓝宝石色 (Deep Sapphire)
        // ═══════════════════════════════════════════════════════════════
        static let primary = Color(hex: "6366F1")           // Indigo 500
        static let primaryLight = Color(hex: "818CF8")      // Indigo 400
        static let primaryDark = Color(hex: "4F46E5")       // Indigo 600
        static let primaryDeep = Color(hex: "3730A3")       // Indigo 800
        
        // ═══════════════════════════════════════════════════════════════
        // 强调色 - 温暖的琥珀金 (Amber Gold)
        // ═══════════════════════════════════════════════════════════════
        static let accent = Color(hex: "F59E0B")            // Amber 500
        static let accentLight = Color(hex: "FBBF24")       // Amber 400
        static let accentSoft = Color(hex: "FDE68A")        // Amber 200
        
        // ═══════════════════════════════════════════════════════════════
        // 辅助色 - 薰衣草紫 (Lavender)
        // ═══════════════════════════════════════════════════════════════
        static let secondary = Color(hex: "A78BFA")         // Violet 400
        static let secondaryLight = Color(hex: "C4B5FD")    // Violet 300
        static let secondaryDark = Color(hex: "7C3AED")     // Violet 600
        
        // ═══════════════════════════════════════════════════════════════
        // 点缀色 - 玫瑰粉 (Rose)
        // ═══════════════════════════════════════════════════════════════
        static let tertiary = Color(hex: "F472B6")          // Pink 400
        static let tertiaryLight = Color(hex: "F9A8D4")     // Pink 300
        
        // ═══════════════════════════════════════════════════════════════
        // 语义色 - 柔和优雅版本
        // ═══════════════════════════════════════════════════════════════
        static let success = Color(hex: "10B981")           // Emerald 500
        static let successLight = Color(hex: "34D399")      // Emerald 400
        static let successSoft = Color(hex: "D1FAE5")       // Emerald 100
        
        static let warning = Color(hex: "F59E0B")           // Amber 500
        static let warningLight = Color(hex: "FBBF24")      // Amber 400
        static let warningSoft = Color(hex: "FEF3C7")       // Amber 100
        
        static let error = Color(hex: "EF4444")             // Red 500
        static let errorLight = Color(hex: "F87171")        // Red 400
        static let errorSoft = Color(hex: "FEE2E2")         // Red 100
        
        static let info = Color(hex: "3B82F6")              // Blue 500
        static let infoLight = Color(hex: "60A5FA")         // Blue 400
        static let infoSoft = Color(hex: "DBEAFE")          // Blue 100
        
        // ═══════════════════════════════════════════════════════════════
        // 背景色 - 自适应深浅主题
        // ═══════════════════════════════════════════════════════════════
        static let background = Color(nsColor: .windowBackgroundColor)
        static let surface = Color(nsColor: .controlBackgroundColor)
        static let elevated = Color(nsColor: .textBackgroundColor)
        static let canvas = Color(hex: "FAFAFA")
        static let overlay = Color.black.opacity(0.5)
        static let overlayLight = Color.black.opacity(0.3)
        
        // ═══════════════════════════════════════════════════════════════
        // 文字色
        // ═══════════════════════════════════════════════════════════════
        static let textPrimary = Color.primary
        static let textSecondary = Color.secondary
        static let textTertiary = Color(nsColor: .tertiaryLabelColor)
        static let textQuaternary = Color(nsColor: .quaternaryLabelColor)
        static let textOnPrimary = Color.white
        static let textOnAccent = Color(hex: "1E1E2E")
        
        // ═══════════════════════════════════════════════════════════════
        // 边框色
        // ═══════════════════════════════════════════════════════════════
        static let border = Color(nsColor: .separatorColor)
        static let borderLight = Color.gray.opacity(0.12)
        static let borderSubtle = Color.gray.opacity(0.06)
        static let borderFocused = primary.opacity(0.6)
        static let borderGlow = primary.opacity(0.3)
        
        // ═══════════════════════════════════════════════════════════════
        // 渐变预设
        // ═══════════════════════════════════════════════════════════════
        static let gradientPrimary = LinearGradient(
            colors: [Color(hex: "6366F1"), Color(hex: "8B5CF6")],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        
        static let gradientAccent = LinearGradient(
            colors: [Color(hex: "F59E0B"), Color(hex: "EF4444")],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        
        static let gradientSubtle = LinearGradient(
            colors: [primary.opacity(0.06), secondary.opacity(0.03)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        
        static let gradientAurora = LinearGradient(
            colors: [
                Color(hex: "6366F1").opacity(0.8),
                Color(hex: "8B5CF6").opacity(0.6),
                Color(hex: "EC4899").opacity(0.4)
            ],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        
        static let gradientWarm = LinearGradient(
            colors: [Color(hex: "F59E0B"), Color(hex: "F97316"), Color(hex: "EF4444")],
            startPoint: .leading,
            endPoint: .trailing
        )
        
        static let gradientCool = LinearGradient(
            colors: [Color(hex: "0EA5E9"), Color(hex: "6366F1")],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        
        static let gradientNature = LinearGradient(
            colors: [Color(hex: "10B981"), Color(hex: "059669")],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        
        static let gradientSunset = LinearGradient(
            colors: [Color(hex: "F472B6"), Color(hex: "F59E0B")],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        
        static let gradientGlass = LinearGradient(
            colors: [Color.white.opacity(0.25), Color.white.opacity(0.05)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        
        static let meshGradientColors: [Color] = [
            Color(hex: "6366F1").opacity(0.08),
            Color(hex: "8B5CF6").opacity(0.06),
            Color(hex: "EC4899").opacity(0.04),
            Color(hex: "F59E0B").opacity(0.05)
        ]
        
        // ═══════════════════════════════════════════════════════════════
        // 批注高亮色
        // ═══════════════════════════════════════════════════════════════
        static let highlightYellow = Color(hex: "FEF08A").opacity(0.70)
        static let highlightGreen = Color(hex: "BBF7D0").opacity(0.70)
        static let highlightBlue = Color(hex: "BFDBFE").opacity(0.70)
        static let highlightPink = Color(hex: "FBCFE8").opacity(0.70)
        static let highlightPurple = Color(hex: "DDD6FE").opacity(0.70)
        static let highlightOrange = Color(hex: "FED7AA").opacity(0.70)
        static let highlightCyan = Color(hex: "A5F3FC").opacity(0.70)
        
        static let connectorDefault = Color(hex: "94A3B8")
        static let connectorActive = primary
        static let connectorHover = secondary
    }
    
    // MARK: - 📐 Spacing
    struct Spacing {
        static let xxs: CGFloat = 2
        static let xs: CGFloat = 4
        static let sm: CGFloat = 8
        static let md: CGFloat = 12
        static let lg: CGFloat = 16
        static let xl: CGFloat = 20
        static let xxl: CGFloat = 24
        static let xxxl: CGFloat = 32
        static let xxxxl: CGFloat = 48
    }
    
    // MARK: - 🔲 Corner Radius
    struct Radius {
        static let xs: CGFloat = 4
        static let sm: CGFloat = 6
        static let md: CGFloat = 8
        static let lg: CGFloat = 12
        static let xl: CGFloat = 16
        static let xxl: CGFloat = 20
        static let xxxl: CGFloat = 28
        static let full: CGFloat = 9999
        
        static let button: CGFloat = 10
        static let card: CGFloat = 14
        static let modal: CGFloat = 20
    }
    
    // MARK: - 🌫️ Shadows
    struct Shadows {
        static let none = ShadowStyle(color: .clear, radius: 0, x: 0, y: 0)
        static let xs = ShadowStyle(color: .black.opacity(0.03), radius: 2, x: 0, y: 1)
        static let small = ShadowStyle(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
        static let medium = ShadowStyle(color: .black.opacity(0.07), radius: 8, x: 0, y: 4)
        static let large = ShadowStyle(color: .black.opacity(0.10), radius: 16, x: 0, y: 8)
        static let xl = ShadowStyle(color: .black.opacity(0.12), radius: 24, x: 0, y: 12)
        
        static let primaryGlow = ShadowStyle(color: Colors.primary.opacity(0.35), radius: 16, x: 0, y: 6)
        static let accentGlow = ShadowStyle(color: Colors.accent.opacity(0.35), radius: 16, x: 0, y: 6)
        static let successGlow = ShadowStyle(color: Colors.success.opacity(0.35), radius: 16, x: 0, y: 6)
        
        static let inner = ShadowStyle(color: .black.opacity(0.05), radius: 2, x: 0, y: 1)
    }
    
    struct ShadowStyle {
        let color: Color
        let radius: CGFloat
        let x: CGFloat
        let y: CGFloat
    }
    
    // MARK: - 🔤 Typography
    struct Typography {
        static let display = Font.system(size: 36, weight: .bold, design: .rounded)
        static let largeTitle = Font.system(size: 28, weight: .bold, design: .rounded)
        static let title = Font.system(size: 22, weight: .semibold, design: .rounded)
        static let title2 = Font.system(size: 18, weight: .semibold, design: .rounded)
        static let title3 = Font.system(size: 16, weight: .medium, design: .rounded)
        
        static let headline = Font.system(size: 14, weight: .semibold, design: .default)
        static let subheadline = Font.system(size: 13, weight: .medium, design: .default)
        static let body = Font.system(size: 14, weight: .regular, design: .default)
        static let bodyMedium = Font.system(size: 14, weight: .medium, design: .default)
        static let callout = Font.system(size: 13, weight: .regular, design: .default)
        
        static let caption = Font.system(size: 12, weight: .regular, design: .default)
        static let captionMedium = Font.system(size: 12, weight: .medium, design: .default)
        static let caption2 = Font.system(size: 11, weight: .regular, design: .default)
        static let micro = Font.system(size: 10, weight: .medium, design: .default)
        
        static let mono = Font.system(size: 13, weight: .regular, design: .monospaced)
        static let monoSmall = Font.system(size: 11, weight: .regular, design: .monospaced)
    }
    
    // MARK: - ✨ Animation
    struct Animation {
        static let instant = SwiftUI.Animation.easeOut(duration: 0.1)
        static let quick = SwiftUI.Animation.easeOut(duration: 0.15)
        static let standard = SwiftUI.Animation.easeInOut(duration: 0.25)
        static let smooth = SwiftUI.Animation.easeInOut(duration: 0.35)
        static let slow = SwiftUI.Animation.easeInOut(duration: 0.5)
        
        static let springQuick = SwiftUI.Animation.spring(response: 0.3, dampingFraction: 0.7)
        static let spring = SwiftUI.Animation.spring(response: 0.4, dampingFraction: 0.7)
        static let springBouncy = SwiftUI.Animation.spring(response: 0.45, dampingFraction: 0.6)
        static let springGentle = SwiftUI.Animation.spring(response: 0.5, dampingFraction: 0.8)
        
        static let interactive = SwiftUI.Animation.interactiveSpring(response: 0.35, dampingFraction: 0.7)
    }
    
    // MARK: - 📏 Icon Sizes
    struct IconSize {
        static let xs: CGFloat = 12
        static let sm: CGFloat = 14
        static let md: CGFloat = 16
        static let lg: CGFloat = 20
        static let xl: CGFloat = 24
        static let xxl: CGFloat = 32
    }
}

// MARK: - Color Extension
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3:
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6:
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8:
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (1, 1, 1, 0)
        }
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue: Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}

// MARK: - View Extensions
extension View {
    func cardStyle(padding: CGFloat = Theme.Spacing.md) -> some View {
        self
            .padding(padding)
            .background(
                RoundedRectangle(cornerRadius: Theme.Radius.card)
                    .fill(.ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: Theme.Radius.card)
                            .fill(Color.white.opacity(0.03))
                    )
            )
            .overlay(
                RoundedRectangle(cornerRadius: Theme.Radius.card)
                    .stroke(Theme.Colors.borderLight, lineWidth: 0.5)
            )
            .shadow(color: .black.opacity(0.04), radius: 8, x: 0, y: 3)
    }
    
    func glassCard(padding: CGFloat = Theme.Spacing.md) -> some View {
        self
            .padding(padding)
            .background(
                ZStack {
                    RoundedRectangle(cornerRadius: Theme.Radius.card)
                        .fill(.ultraThinMaterial)
                    RoundedRectangle(cornerRadius: Theme.Radius.card)
                        .fill(Color.white.opacity(0.05))
                }
            )
            .overlay(
                RoundedRectangle(cornerRadius: Theme.Radius.card)
                    .stroke(
                        LinearGradient(
                            colors: [Color.white.opacity(0.25), Color.white.opacity(0.08)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 0.5
                    )
            )
            .shadow(color: .black.opacity(0.06), radius: 12, x: 0, y: 4)
    }
    
    func floatingCard() -> some View {
        self
            .background(
                RoundedRectangle(cornerRadius: Theme.Radius.modal)
                    .fill(.ultraThinMaterial)
                    .shadow(color: .black.opacity(0.15), radius: 30, x: 0, y: 15)
            )
            .overlay(
                RoundedRectangle(cornerRadius: Theme.Radius.modal)
                    .stroke(Color.white.opacity(0.12), lineWidth: 0.5)
            )
    }
    
    func glassStyle() -> some View {
        self
            .background(.ultraThinMaterial)
            .cornerRadius(Theme.Radius.lg)
    }
    
    func pressableButton() -> some View {
        self.buttonStyle(PressableButtonStyle())
    }
    
    func iconButton() -> some View {
        self.buttonStyle(IconButtonStyle())
    }
    
    func shimmer(isActive: Bool = true) -> some View {
        self.modifier(ShimmerModifier(isActive: isActive))
    }
    
    func pulseAnimation(isActive: Bool = true) -> some View {
        self.modifier(PulseModifier(isActive: isActive))
    }
    
    func hoverScale(scale: CGFloat = 1.02) -> some View {
        self.modifier(HoverScaleModifier(scale: scale))
    }
    
    @ViewBuilder
    func `if`<Content: View>(_ condition: Bool, transform: (Self) -> Content) -> some View {
        if condition {
            transform(self)
        } else {
            self
        }
    }
}

// MARK: - Button Styles
struct PressableButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.96 : 1.0)
            .opacity(configuration.isPressed ? 0.85 : 1.0)
            .animation(Theme.Animation.quick, value: configuration.isPressed)
    }
}

struct IconButtonStyle: ButtonStyle {
    @State private var isHovered = false
    
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.9 : (isHovered ? 1.05 : 1.0))
            .opacity(configuration.isPressed ? 0.7 : 1.0)
            .animation(Theme.Animation.springQuick, value: configuration.isPressed)
            .animation(Theme.Animation.springQuick, value: isHovered)
            .onHover { hovering in
                isHovered = hovering
            }
    }
}

struct GlowButtonStyle: ButtonStyle {
    var color: Color = Theme.Colors.primary
    @State private var isHovered = false
    
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding(.horizontal, Theme.Spacing.lg)
            .padding(.vertical, Theme.Spacing.sm)
            .background(
                RoundedRectangle(cornerRadius: Theme.Radius.button)
                    .fill(color)
                    .shadow(
                        color: color.opacity(configuration.isPressed ? 0.2 : (isHovered ? 0.5 : 0.35)),
                        radius: configuration.isPressed ? 4 : (isHovered ? 16 : 12),
                        y: configuration.isPressed ? 2 : (isHovered ? 6 : 4)
                    )
            )
            .foregroundColor(.white)
            .scaleEffect(configuration.isPressed ? 0.96 : (isHovered ? 1.02 : 1.0))
            .animation(Theme.Animation.springQuick, value: configuration.isPressed)
            .animation(Theme.Animation.springQuick, value: isHovered)
            .onHover { hovering in isHovered = hovering }
    }
}

struct GradientButtonStyle: ButtonStyle {
    var gradient: LinearGradient = Theme.Colors.gradientPrimary
    @State private var isHovered = false
    
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding(.horizontal, Theme.Spacing.lg)
            .padding(.vertical, Theme.Spacing.sm)
            .background(
                ZStack {
                    RoundedRectangle(cornerRadius: Theme.Radius.button)
                        .fill(gradient)
                    RoundedRectangle(cornerRadius: Theme.Radius.button)
                        .fill(
                            LinearGradient(
                                colors: [Color.white.opacity(0.25), Color.clear],
                                startPoint: .top,
                                endPoint: .center
                            )
                        )
                }
                .shadow(
                    color: Theme.Colors.primary.opacity(configuration.isPressed ? 0.15 : (isHovered ? 0.4 : 0.3)),
                    radius: configuration.isPressed ? 4 : (isHovered ? 16 : 12),
                    y: configuration.isPressed ? 2 : (isHovered ? 8 : 5)
                )
            )
            .overlay(
                RoundedRectangle(cornerRadius: Theme.Radius.button)
                    .stroke(Color.white.opacity(0.2), lineWidth: 0.5)
            )
            .foregroundColor(.white)
            .scaleEffect(configuration.isPressed ? 0.96 : (isHovered ? 1.02 : 1.0))
            .animation(Theme.Animation.springQuick, value: configuration.isPressed)
            .animation(Theme.Animation.springQuick, value: isHovered)
            .onHover { hovering in isHovered = hovering }
    }
}

// MARK: - View Modifiers
struct ShimmerModifier: ViewModifier {
    let isActive: Bool
    @State private var phase: CGFloat = 0
    
    func body(content: Content) -> some View {
        if isActive {
            content
                .overlay(
                    GeometryReader { geo in
                        LinearGradient(
                            colors: [.clear, .white.opacity(0.3), .clear],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                        .frame(width: geo.size.width * 0.6)
                        .offset(x: -geo.size.width * 0.3 + phase * geo.size.width * 1.6)
                        .blur(radius: 3)
                    }
                    .mask(content)
                )
                .onAppear {
                    withAnimation(.linear(duration: 2.0).repeatForever(autoreverses: false)) {
                        phase = 1
                    }
                }
        } else {
            content
        }
    }
}

struct PulseModifier: ViewModifier {
    let isActive: Bool
    @State private var isPulsing = false
    
    func body(content: Content) -> some View {
        content
            .scaleEffect(isActive && isPulsing ? 1.05 : 1.0)
            .opacity(isActive && isPulsing ? 0.85 : 1.0)
            .onAppear {
                if isActive {
                    withAnimation(Animation.easeInOut(duration: 1.0).repeatForever(autoreverses: true)) {
                        isPulsing = true
                    }
                }
            }
    }
}

struct HoverScaleModifier: ViewModifier {
    let scale: CGFloat
    @State private var isHovered = false
    
    func body(content: Content) -> some View {
        content
            .scaleEffect(isHovered ? scale : 1.0)
            .animation(Theme.Animation.springQuick, value: isHovered)
            .onHover { hovering in isHovered = hovering }
    }
}

// MARK: - App Icons
struct AppIcons {
    static func gradient(_ systemName: String, colors: [Color] = [Theme.Colors.primary, Theme.Colors.secondary]) -> some View {
        Image(systemName: systemName)
            .foregroundStyle(
                LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing)
            )
    }
    
    static func glow(_ systemName: String, color: Color = Theme.Colors.primary) -> some View {
        Image(systemName: systemName)
            .foregroundColor(color)
            .shadow(color: color.opacity(0.5), radius: 4, x: 0, y: 0)
    }
}

// MARK: - Animated Background
struct AnimatedMeshGradient: View {
    @State private var animate = false
    var intensity: CGFloat = 1.0
    
    var body: some View {
        ZStack {
            Circle()
                .fill(Theme.Colors.primary.opacity(0.15 * intensity))
                .frame(width: 400, height: 400)
                .blur(radius: 100)
                .offset(x: animate ? 150 : -150, y: animate ? -80 : 80)
            
            Circle()
                .fill(Theme.Colors.secondary.opacity(0.12 * intensity))
                .frame(width: 350, height: 350)
                .blur(radius: 90)
                .offset(x: animate ? -120 : 120, y: animate ? 100 : -100)
            
            Circle()
                .fill(Theme.Colors.accent.opacity(0.08 * intensity))
                .frame(width: 200, height: 200)
                .blur(radius: 60)
                .offset(x: animate ? 80 : -80, y: animate ? 150 : -150)
            
            Circle()
                .fill(Theme.Colors.tertiary.opacity(0.06 * intensity))
                .frame(width: 150, height: 150)
                .blur(radius: 50)
                .offset(x: animate ? -100 : 100, y: animate ? -50 : 50)
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 12).repeatForever(autoreverses: true)) {
                animate = true
            }
        }
    }
}

// MARK: - Decorative Elements
struct FloatingOrb: View {
    var color: Color = Theme.Colors.primary
    var size: CGFloat = 100
    @State private var offset: CGSize = .zero
    
    var body: some View {
        Circle()
            .fill(
                RadialGradient(
                    colors: [color.opacity(0.4), color.opacity(0.1), .clear],
                    center: .center,
                    startRadius: 0,
                    endRadius: size / 2
                )
            )
            .frame(width: size, height: size)
            .blur(radius: size / 4)
            .offset(offset)
            .onAppear {
                withAnimation(Animation.easeInOut(duration: Double.random(in: 4...8)).repeatForever(autoreverses: true)) {
                    offset = CGSize(
                        width: CGFloat.random(in: -30...30),
                        height: CGFloat.random(in: -30...30)
                    )
                }
            }
    }
}

// MARK: - Progress Indicators
struct PulsingDot: View {
    var color: Color = Theme.Colors.primary
    var size: CGFloat = 8
    @State private var isPulsing = false
    
    var body: some View {
        Circle()
            .fill(color)
            .frame(width: size, height: size)
            .scaleEffect(isPulsing ? 1.2 : 0.8)
            .opacity(isPulsing ? 0.6 : 1.0)
            .animation(Animation.easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: isPulsing)
            .onAppear { isPulsing = true }
    }
}

struct LoadingDots: View {
    var color: Color = Theme.Colors.primary
    @State private var animationPhase = 0
    
    var body: some View {
        HStack(spacing: 4) {
            ForEach(0..<3, id: \.self) { index in
                Circle()
                    .fill(color)
                    .frame(width: 6, height: 6)
                    .scaleEffect(animationPhase == index ? 1.2 : 0.8)
                    .opacity(animationPhase == index ? 1.0 : 0.5)
            }
        }
        .onAppear {
            Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true) { _ in
                withAnimation(Theme.Animation.springQuick) {
                    animationPhase = (animationPhase + 1) % 3
                }
            }
        }
    }
}

// MARK: - Dividers
struct GradientDivider: View {
    var height: CGFloat = 1
    
    var body: some View {
        Rectangle()
            .fill(
                LinearGradient(
                    colors: [.clear, Theme.Colors.border, .clear],
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .frame(height: height)
    }
}

// MARK: - Empty State View
struct EmptyStateView: View {
    var icon: String
    var title: String
    var subtitle: String?
    var action: (() -> Void)?
    var actionTitle: String?
    
    var body: some View {
        VStack(spacing: Theme.Spacing.lg) {
            ZStack {
                Circle()
                    .fill(Theme.Colors.gradientSubtle)
                    .frame(width: 100, height: 100)
                
                Image(systemName: icon)
                    .font(.system(size: 40, weight: .light))
                    .foregroundStyle(Theme.Colors.gradientPrimary)
            }
            
            VStack(spacing: Theme.Spacing.sm) {
                Text(title)
                    .font(Theme.Typography.title3)
                    .foregroundColor(Theme.Colors.textPrimary)
                
                if let subtitle = subtitle {
                    Text(subtitle)
                        .font(Theme.Typography.callout)
                        .foregroundColor(Theme.Colors.textSecondary)
                        .multilineTextAlignment(.center)
                }
            }
            
            if let action = action, let actionTitle = actionTitle {
                Button(action: action) {
                    Text(actionTitle)
                        .font(Theme.Typography.bodyMedium)
                }
                .buttonStyle(GradientButtonStyle())
                .padding(.top, Theme.Spacing.sm)
            }
        }
        .padding(Theme.Spacing.xxxl)
    }
}
