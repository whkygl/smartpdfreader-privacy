
import QuartzCore
import SwiftUI
import PDFKit
import UniformTypeIdentifiers

// MARK: - PDFAnnotationKey compatibility
// Some macOS SDKs do not expose PDFAnnotationKey.subject; PDF spec uses key `Subj`.
extension PDFAnnotationKey {
    static let spdfSubject = PDFAnnotationKey(rawValue: "Subj")
}

// MARK: - 0. 浮动菜单视图 (美化版)
struct SelectionMenuView: View {
    var onCopy: () -> Void
    var onHighlight: (NSColor) -> Void
    var onUnderline: (NSColor) -> Void
    var onNote: () -> Void
    var onTranslate: () -> Void
    var onDismiss: () -> Void
    
    @State private var isHovering = false
    @State private var highlightColor: NSColor = .systemYellow.withAlphaComponent(0.5)
    @State private var underlineColor: NSColor = .systemGreen
    @State private var hoveredButton: String? = nil
    @ObservedObject private var localization = LocalizationManager.shared
    
    // 使用本地化颜色名称
    private var localizedColors: [(String, NSColor)] {
        [
            (L(.colorYellow), .systemYellow),
            (L(.colorGreen), .systemGreen),
            (L(.colorBlue), .systemBlue),
            (L(.colorRed), .systemRed),
            (L(.colorPurple), .systemPurple),
            (L(.colorOrange), .systemOrange),
            (L(.colorCyan), .systemTeal)
        ]
    }

    private func colorDotImage(_ color: NSColor) -> NSImage {
        let size = NSSize(width: 12, height: 12)
        let img = NSImage(size: size)
        img.lockFocus()
        let rect = NSRect(origin: .zero, size: size)
        let path = NSBezierPath(ovalIn: rect.insetBy(dx: 0.5, dy: 0.5))
        color.setFill()
        path.fill()
        NSColor.black.withAlphaComponent(0.1).setStroke()
        path.lineWidth = 0.5
        path.stroke()
        img.unlockFocus()
        img.isTemplate = false
        return img
    }

    var body: some View {
        HStack(spacing: 6) {
            // 复制按钮
            MenuButton(
                icon: "doc.on.doc",
                isHovered: hoveredButton == "copy",
                action: onCopy
            )
            .onHover { hoveredButton = $0 ? "copy" : nil }
            .help(L(.copyTooltip))
            
            MenuDivider()
            
            // 高亮按钮组
            HStack(spacing: 2) {
                MenuButton(
                    icon: "highlighter",
                    isHovered: hoveredButton == "highlight",
                    tintColor: Color(nsColor: highlightColor),
                    action: { onHighlight(highlightColor) }
                )
                .onHover { hoveredButton = $0 ? "highlight" : nil }
                
                Menu {
                    ForEach(localizedColors, id: \.0) { name, color in
                        Button(action: {
                            let c = color.withAlphaComponent(0.5)
                            highlightColor = c
                            onHighlight(c)
                        }) {
                            HStack(spacing: 8) {
                                Image(nsImage: colorDotImage(color))
                                    .renderingMode(.original)
                                Text(name)
                                    .font(.system(size: 12))
                            }
                        }
                    }
                } label: {
                    Image(systemName: "chevron.down")
                        .font(.system(size: 8, weight: .bold))
                        .foregroundColor(.secondary)
                        .frame(width: 14, height: 28)
                }
                .menuStyle(.borderlessButton)
                .frame(width: 14)
            }
            .help(L(.highlightTooltip))
            
            MenuDivider()
            
            // 下划线按钮组
            HStack(spacing: 2) {
                MenuButton(
                    icon: "underline",
                    isHovered: hoveredButton == "underline",
                    tintColor: Color(nsColor: underlineColor),
                    action: { onUnderline(underlineColor) }
                )
                .onHover { hoveredButton = $0 ? "underline" : nil }
                
                Menu {
                    ForEach(localizedColors, id: \.0) { name, color in
                        Button(action: {
                            underlineColor = color
                            onUnderline(color)
                        }) {
                            HStack(spacing: 8) {
                                Image(nsImage: colorDotImage(color))
                                    .renderingMode(.original)
                                Text(name)
                                    .font(.system(size: 12))
                            }
                        }
                    }
                } label: {
                    Image(systemName: "chevron.down")
                        .font(.system(size: 8, weight: .bold))
                        .foregroundColor(.secondary)
                        .frame(width: 14, height: 28)
                }
                .menuStyle(.borderlessButton)
                .frame(width: 14)
            }
            .help(L(.underlineTooltip))
            
            MenuDivider()
            
            // 批注按钮
            MenuButton(
                icon: "bubble.left.and.bubble.right",
                isHovered: hoveredButton == "note",
                action: onNote
            )
            .onHover { hoveredButton = $0 ? "note" : nil }
            .help(L(.addNoteTooltip))
            
            MenuDivider()
            
            // 翻译按钮
            MenuButton(
                icon: "translate",
                isHovered: hoveredButton == "translate",
                action: onTranslate
            )
            .onHover { hoveredButton = $0 ? "translate" : nil }
            .help(L(.translateTooltip))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(
            ZStack {
                RoundedRectangle(cornerRadius: 14)
                    .fill(.ultraThinMaterial)
                RoundedRectangle(cornerRadius: 14)
                    .fill(Color.white.opacity(0.6))
            }
        )
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(
                    LinearGradient(
                        colors: [Color.white.opacity(0.5), Color.white.opacity(0.2)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: 0.5
                )
        )
        .shadow(color: .black.opacity(0.08), radius: 16, x: 0, y: 6)
        .shadow(color: Theme.Colors.primary.opacity(0.05), radius: 24, x: 0, y: 10)
        .onHover { hovering in
            isHovering = hovering
            if !hovering {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                    if !self.isHovering { onDismiss() }
                }
            }
        }
    }
}

// MARK: - 菜单按钮组件
struct MenuButton: View {
    let icon: String
    var isHovered: Bool = false
    var tintColor: Color? = nil
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 15, weight: .medium))
                .foregroundColor(tintColor ?? (isHovered ? Theme.Colors.primary : .secondary))
                .frame(width: 32, height: 32)
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .fill(isHovered ? Theme.Colors.primary.opacity(0.1) : Color.clear)
                )
        }
        .buttonStyle(.plain)
        .scaleEffect(isHovered ? 1.05 : 1.0)
        .animation(Theme.Animation.springQuick, value: isHovered)
    }
}

// MARK: - 菜单分隔线
struct MenuDivider: View {
    var body: some View {
        Rectangle()
            .fill(
                LinearGradient(
                    colors: [Color.gray.opacity(0), Color.gray.opacity(0.2), Color.gray.opacity(0)],
                    startPoint: .top,
                    endPoint: .bottom
                )
            )
            .frame(width: 1, height: 22)
    }
}

extension Notification.Name { static let findInPDF = Notification.Name("findInPDF") }

// MARK: - 1. 输入视图 (美化版)
struct NoteInputView: View {
    @State private var text: String
    @State private var isPreview: Bool = false
    var onSave: (String) -> Void
    var onCancel: () -> Void
    @ObservedObject private var localization = LocalizationManager.shared
    
    init(initialText: String = "", onSave: @escaping (String) -> Void, onCancel: @escaping () -> Void) {
        _text = State(initialValue: initialText)
        self.onSave = onSave
        self.onCancel = onCancel
    }
    
    var body: some View {
        VStack(spacing: Theme.Spacing.lg) {
            // 标题栏
            HStack {
                HStack(spacing: Theme.Spacing.sm) {
                    Image(systemName: isPreview ? "eye" : "pencil.line")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(Theme.Colors.gradientPrimary)
                    
                    Text(isPreview ? L(.previewMode) : L(.editNote))
                        .font(Theme.Typography.headline)
                        .foregroundColor(Theme.Colors.textPrimary)
                }
                
                Spacer()
                
                // Markdown 预览切换
                Toggle(isOn: $isPreview) {
                    Text("Markdown")
                        .font(Theme.Typography.caption)
                        .foregroundColor(Theme.Colors.textSecondary)
                }
                .toggleStyle(.switch)
                .controlSize(.mini)
            }
            
            // 内容区域
            Group {
                if isPreview {
                    ScrollView {
                        Text(toMarkdown(text))
                            .font(Theme.Typography.body)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(Theme.Spacing.md)
                    }
                    .background(
                        RoundedRectangle(cornerRadius: Theme.Radius.md)
                            .fill(Theme.Colors.surface.opacity(0.5))
                    )
                } else {
                    TextEditor(text: $text)
                        .font(Theme.Typography.body)
                        .padding(Theme.Spacing.sm)
                        .scrollContentBackground(.hidden)
                        .background(
                            RoundedRectangle(cornerRadius: Theme.Radius.md)
                                .fill(Theme.Colors.surface.opacity(0.3))
                        )
                }
            }
            .frame(height: 150)
            .overlay(
                RoundedRectangle(cornerRadius: Theme.Radius.md)
                    .stroke(Theme.Colors.borderLight, lineWidth: 1)
            )
            
            // 操作按钮
            HStack {
                Button(action: onCancel) {
                    Text(L(.cancel))
                        .font(Theme.Typography.bodyMedium)
                        .foregroundColor(Theme.Colors.textSecondary)
                        .padding(.horizontal, Theme.Spacing.lg)
                        .padding(.vertical, Theme.Spacing.sm)
                        .background(
                            RoundedRectangle(cornerRadius: Theme.Radius.md)
                                .fill(Theme.Colors.surface)
                        )
                }
                .buttonStyle(.plain)
                .keyboardShortcut(.cancelAction)
                
                Spacer()
                
                Button(action: {
                    let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
                    onSave(t)
                }) {
                    HStack(spacing: Theme.Spacing.xs) {
                        Image(systemName: "checkmark")
                            .font(.system(size: 12, weight: .bold))
                        Text(L(.save))
                            .font(Theme.Typography.bodyMedium)
                    }
                    .foregroundColor(.white)
                    .padding(.horizontal, Theme.Spacing.lg)
                    .padding(.vertical, Theme.Spacing.sm)
                    .background(
                        RoundedRectangle(cornerRadius: Theme.Radius.md)
                            .fill(Theme.Colors.gradientPrimary)
                    )
                }
                .buttonStyle(.plain)
                .keyboardShortcut(.defaultAction)
            }
        }
        .padding(Theme.Spacing.xl)
        .frame(width: 400)
        .background(
            RoundedRectangle(cornerRadius: Theme.Radius.xl)
                .fill(.ultraThinMaterial)
        )
        .overlay(
            RoundedRectangle(cornerRadius: Theme.Radius.xl)
                .stroke(Theme.Colors.borderLight, lineWidth: 0.5)
        )
    }
    
    func toMarkdown(_ text: String) -> AttributedString {
        // 更完整的Markdown转换
        var processed = text
        
        // 处理标题 (# ## ### #### ##### ######)
        // 将标题转换为粗体
        processed = processed.replacingOccurrences(of: "(?m)^######\\s+(.+)$", with: "**$1**", options: .regularExpression)
        processed = processed.replacingOccurrences(of: "(?m)^#####\\s+(.+)$", with: "**$1**", options: .regularExpression)
        processed = processed.replacingOccurrences(of: "(?m)^####\\s+(.+)$", with: "**$1**", options: .regularExpression)
        processed = processed.replacingOccurrences(of: "(?m)^###\\s+(.+)$", with: "**$1**", options: .regularExpression)
        processed = processed.replacingOccurrences(of: "(?m)^##\\s+(.+)$", with: "**$1**", options: .regularExpression)
        processed = processed.replacingOccurrences(of: "(?m)^#\\s+(.+)$", with: "**$1**", options: .regularExpression)
        
        // 处理列表项 (- 和 *)
        processed = processed.replacingOccurrences(of: "(?m)^\\s*[-*]\\s+", with: "• ", options: .regularExpression)
        
        // 处理有序列表
        processed = processed.replacingOccurrences(of: "(?m)^\\s*\\d+\\.\\s+", with: "• ", options: .regularExpression)
        
        // 处理水平线
        processed = processed.replacingOccurrences(of: "(?m)^[-*_]{3,}$", with: "───────────", options: .regularExpression)
        
        // 处理引用块
        processed = processed.replacingOccurrences(of: "(?m)^>\\s*", with: "│ ", options: .regularExpression)
        
        // 处理代码块标记（移除```）
        processed = processed.replacingOccurrences(of: "```[a-zA-Z]*\\n?", with: "", options: .regularExpression)
        
        // 处理行内代码
        processed = processed.replacingOccurrences(of: "`([^`]+)`", with: "「$1」", options: .regularExpression)
        
        // 确保换行正确处理
        processed = processed.replacingOccurrences(of: "\n", with: "  \n")
        
        do {
            return try AttributedString(markdown: processed, options: AttributedString.MarkdownParsingOptions(interpretedSyntax: .inlineOnlyPreservingWhitespace))
        } catch {
            return AttributedString(text)
        }
    }
}

struct FreeTextEditView: View {
    @State private var text: String
    var onSave: (String) -> Void
    var onCancel: () -> Void
    @ObservedObject private var localization = LocalizationManager.shared
    
    init(initialText: String, onSave: @escaping (String) -> Void, onCancel: @escaping () -> Void) {
        _text = State(initialValue: initialText)
        self.onSave = onSave
        self.onCancel = onCancel
    }
    
    var body: some View {
        VStack(spacing: Theme.Spacing.lg) {
            // 标题栏
            HStack {
                HStack(spacing: Theme.Spacing.sm) {
                    Image(systemName: "textformat")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(Theme.Colors.gradientPrimary)
                    
                    Text(L(.editText))
                        .font(Theme.Typography.headline)
                        .foregroundColor(Theme.Colors.textPrimary)
                }
                
                Spacer()
            }
            
            // 编辑区域
            TextEditor(text: $text)
                .font(Theme.Typography.body)
                .padding(Theme.Spacing.sm)
                .scrollContentBackground(.hidden)
                .frame(height: 130)
                .background(
                    RoundedRectangle(cornerRadius: Theme.Radius.md)
                        .fill(Theme.Colors.surface.opacity(0.3))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: Theme.Radius.md)
                        .stroke(Theme.Colors.borderLight, lineWidth: 1)
                )
            
            // 操作按钮
            HStack {
                Button(action: onCancel) {
                    Text(L(.cancel))
                        .font(Theme.Typography.bodyMedium)
                        .foregroundColor(Theme.Colors.textSecondary)
                        .padding(.horizontal, Theme.Spacing.lg)
                        .padding(.vertical, Theme.Spacing.sm)
                        .background(
                            RoundedRectangle(cornerRadius: Theme.Radius.md)
                                .fill(Theme.Colors.surface)
                        )
                }
                .buttonStyle(.plain)
                .keyboardShortcut(.cancelAction)
                
                Spacer()
                
                Button(action: {
                    let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !t.isEmpty { onSave(t) }
                }) {
                    HStack(spacing: Theme.Spacing.xs) {
                        Image(systemName: "checkmark")
                            .font(.system(size: 12, weight: .bold))
                        Text(L(.save))
                            .font(Theme.Typography.bodyMedium)
                    }
                    .foregroundColor(.white)
                    .padding(.horizontal, Theme.Spacing.lg)
                    .padding(.vertical, Theme.Spacing.sm)
                    .background(
                        RoundedRectangle(cornerRadius: Theme.Radius.md)
                            .fill(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                                  ? LinearGradient(colors: [.gray], startPoint: .leading, endPoint: .trailing)
                                  : Theme.Colors.gradientPrimary)
                    )
                }
                .buttonStyle(.plain)
                .keyboardShortcut(.defaultAction)
                .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }
        .padding(Theme.Spacing.xl)
        .frame(width: 380)
        .background(
            RoundedRectangle(cornerRadius: Theme.Radius.xl)
                .fill(.ultraThinMaterial)
        )
        .overlay(
            RoundedRectangle(cornerRadius: Theme.Radius.xl)
                .stroke(Theme.Colors.borderLight, lineWidth: 0.5)
        )
    }
}

// MARK: - 2. 自定义 PDFView
class CustomPDFView: PDFView {
    weak var coordinator: PDFKitView.Coordinator?
    var lastMouseUpEvent: NSEvent?
    
    // 拖拽与选择状态
    private var draggedAnnotation: PDFAnnotation?
    private var selectedAnnotation: PDFAnnotation?
    
    private var dragStartLocation: CGPoint = .zero
    private var originalAnnotationBounds: CGRect = .zero
    // For line/arrow endpoint editing
    private var originalLineStartPagePoint: CGPoint = .zero
    private var originalLineEndPagePoint: CGPoint = .zero
    
    private enum DragMode { case move; case resize(ResizeHandle) }
    private enum ResizeHandle {
        case topLeft, topRight, bottomLeft, bottomRight, left, right, top, bottom
        case lineStart, lineEnd
    }
    private var dragMode: DragMode = .move
    
    private var lastContextPagePoint: CGPoint = .zero
    private weak var lastContextPage: PDFPage?
    
    // MARK: - 撤销/重做支持
    private var pdfUndoManager: UndoManager = {
        let manager = UndoManager()
        manager.groupsByEvent = false
        return manager
    }()
    private var undoObserver: NSObjectProtocol?
    private var redoObserver: NSObjectProtocol?

    // MARK: - Note icon sizing
    private let noteIconSize: CGFloat = 14
    private var noteIconHalf: CGFloat { noteIconSize / 2 }
    // For notes placed near a highlight/shape corner, keep a small overlap like before
    private let noteIconCornerInset: CGFloat = 3
    
    // MARK: - Markdown to Plain Text Conversion
    /// 将markdown格式的文本转换为可读的纯文本（移除或转换markdown标记）
    private static func convertMarkdownToPlainText(_ text: String) -> String {
        ChatMarkdown.plainText(text)
    }

    // MARK: - Shape drawing tool
    private enum ShapeTool: String { case none, line, arrow, rect, ellipse }
    private var cursorTrackingArea: NSTrackingArea?
    
    private var shapeTool: ShapeTool = .none {
        didSet {
            window?.invalidateCursorRects(for: self)
            discardCursorRects()
            if shapeTool != .none { NSCursor.crosshair.set() } else { NSCursor.arrow.set() }
        }
    }
    
    private var activeShapeTool: ShapeTool = .none
    private var shapeDraftAnnotation: PDFAnnotation?
    private weak var shapeDraftPage: PDFPage?
    private var shapeStartPagePoint: CGPoint = .zero
    private let shapeStrokeColor: NSColor = .systemRed
    private let shapeLineWidth: CGFloat = 2.0

    override func resetCursorRects() {
        if shapeTool != .none { addCursorRect(bounds, cursor: .crosshair) } else { super.resetCursorRects() }
    }

    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        if let ta = cursorTrackingArea { removeTrackingArea(ta) }
        let options: NSTrackingArea.Options = [.activeInActiveApp, .inVisibleRect, .mouseMoved, .cursorUpdate]
        let ta = NSTrackingArea(rect: self.bounds, options: options, owner: self, userInfo: nil)
        addTrackingArea(ta)
        cursorTrackingArea = ta
    }
    
    // MARK: - 设置撤销/重做通知监听
    func setupUndoRedoObservers() {
        undoObserver = NotificationCenter.default.addObserver(forName: .performUndo, object: nil, queue: .main) { [weak self] _ in
            self?.performUndo()
        }
        redoObserver = NotificationCenter.default.addObserver(forName: .performRedo, object: nil, queue: .main) { [weak self] _ in
            self?.performRedo()
        }
    }
    
    deinit {
        if let observer = undoObserver {
            NotificationCenter.default.removeObserver(observer)
        }
        if let observer = redoObserver {
            NotificationCenter.default.removeObserver(observer)
        }
    }
    
    // MARK: - 键盘事件处理
    override var acceptsFirstResponder: Bool { true }
    
    override func keyDown(with event: NSEvent) {
        // 删除键 (Delete/Backspace) 删除选中的元素
        if event.keyCode == 51 || event.keyCode == 117 { // 51 = Backspace, 117 = Delete
            deleteSelectedAnnotation()
            return
        }
        super.keyDown(with: event)
    }
    
    // MARK: - 删除选中的批注
    func deleteSelectedAnnotation() {
        guard let annotation = selectedAnnotation, let page = annotation.page else { return }
        
        // 注册撤销操作
        registerUndoForAnnotationRemoval(annotation, on: page)
        
        // 检查是否有关联的批注需要一起删除
        if let gid = smartGroupID(of: annotation), let doc = self.document {
            // 先清理overlay和连线（无论是哪种类型的批注）
            removeConnectorLayer(gid)
            removeOverlay(groupID: gid)
            
            // 删除高亮或下划线时，同时删除关联的批注
            if isHighlight(annotation) || isUnderline(annotation) {
                for i in 0..<doc.pageCount {
                    guard let p = doc.page(at: i) else { continue }
                    let anns = p.annotations.filter { $0.userName == gid }
                    for ann in anns {
                        if isHighlight(ann) || isUnderline(ann) || isNote(ann) || isNoteCalloutText(ann) || isNoteConnectorLine(ann) {
                            p.removeAnnotation(ann)
                        }
                    }
                }
            } else if isShape(annotation) {
                // 删除图形时，同时删除关联的批注
                for i in 0..<doc.pageCount {
                    guard let p = doc.page(at: i) else { continue }
                    for ann in p.annotations where ann.userName == gid {
                        if isShape(ann) || isNote(ann) || isNoteCalloutText(ann) || isNoteConnectorLine(ann) { p.removeAnnotation(ann) }
                    }
                }
            } else if isNote(annotation) {
                // 删除批注时，也删除关联的callout
                if let ft = findCalloutText(groupID: gid, on: page) { page.removeAnnotation(ft) }
                if let ln = findCalloutConnector(groupID: gid, on: page) { page.removeAnnotation(ln) }
                page.removeAnnotation(annotation)
            } else {
                page.removeAnnotation(annotation)
            }
        } else {
            page.removeAnnotation(annotation)
        }
        
        selectedAnnotation = nil
        clearSelection()
        forceRefresh()
        NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
    }
    
    // MARK: - 撤销/重做方法
    func performUndo() {
        if pdfUndoManager.canUndo {
            pdfUndoManager.undo()
            forceRefresh()
            NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
        }
    }
    
    func performRedo() {
        if pdfUndoManager.canRedo {
            pdfUndoManager.redo()
            forceRefresh()
            NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
        }
    }
    
    // MARK: - 撤销注册方法
    private func registerAnnotationUndo(_ title: String, action: @escaping (CustomPDFView) -> Void) {
        let ownsGroup = !pdfUndoManager.isUndoing && !pdfUndoManager.isRedoing
        if ownsGroup { pdfUndoManager.beginUndoGrouping() }
        pdfUndoManager.registerUndo(withTarget: self, handler: action)
        pdfUndoManager.setActionName(title)
        if ownsGroup { pdfUndoManager.endUndoGrouping() }
    }

    private func registerUndoForAnnotationRemoval(_ annotation: PDFAnnotation, on page: PDFPage) {
        registerAnnotationUndo(L(.delete)) { [weak page] target in
            guard let p = page else { return }
            target.registerUndoForAnnotationAddition(annotation, on: p)
            p.addAnnotation(annotation)
            target.forceRefresh()
        }
    }
    
    func registerUndoForAnnotationAddition(_ annotation: PDFAnnotation, on page: PDFPage) {
        registerAnnotationUndo(L(.addNote)) { [weak page] target in
            guard let p = page else { return }
            target.registerUndoForAnnotationRemoval(annotation, on: p)
            p.removeAnnotation(annotation)
            target.forceRefresh()
        }
    }

    override func cursorUpdate(with event: NSEvent) {
        if shapeTool != .none { NSCursor.crosshair.set(); return }
        super.cursorUpdate(with: event)
    }
    
    override func hitTest(_ point: NSPoint) -> NSView? {
        // 让 overlay 优先接收鼠标事件（否则 PDFView 很容易把事件吞掉）
        if let host = calloutOverlayHostView {
            let pInHost = host.convert(point, from: self)
            for ov in calloutOverlays.values {
                if !ov.isHidden, ov.frame.contains(pInHost) {
                    let pInOv = ov.convert(pInHost, from: host)
                    return ov.hitTest(pInOv) ?? ov
                }
            }
        } else {
            for ov in calloutOverlays.values {
                if !ov.isHidden, ov.frame.contains(point) {
                    let p = ov.convert(point, from: self)
                    return ov.hitTest(p) ?? ov
                }
            }
        }
        return super.hitTest(point)
    }
    
    override func mouseMoved(with event: NSEvent) {
        if shapeTool != .none { NSCursor.crosshair.set(); return }
        
        // 检查是否在图形或文本元素边缘，显示调整大小光标
        let point = self.convert(event.locationInWindow, from: nil)
        if let page = self.page(for: point, nearest: true) {
            let pagePoint = self.convert(point, to: page)
            
            // 检查选中的批注
            if let sel = selectedAnnotation, sel.page == page {
                if let handle = hitResizeHandle(for: sel, at: pagePoint) {
                    setCursorForHandle(handle)
                    return
                }
            }
            
            // 检查FreeText批注边缘
            if let ft = findAnnotations(on: page, at: pagePoint).reversed().first(where: { isFreeText($0) }) {
                if let handle = hitResizeHandle(for: ft, at: pagePoint) {
                    setCursorForHandle(handle)
                    return
                }
            }
            
            // 检查图形批注边缘
            if let shape = findAnnotations(on: page, at: pagePoint).reversed().first(where: { isShape($0) }) {
                if hitShapeBorder(shape, at: pagePoint) {
                    let subtype = getSubtypeString(shape)
                    if subtype == "/Line" || subtype == "Line" {
                        // 线条：检查端点
                        if let handle = hitResizeHandle(for: shape, at: pagePoint) {
                            setCursorForHandle(handle)
                            return
                        }
                    } else {
                        // 矩形/椭圆：检查边缘
                        let handle = getEdgeHandle(for: shape, at: pagePoint)
                        if handle != nil {
                            setCursorForHandle(handle!)
                            return
                        }
                    }
                    NSCursor.openHand.set()
                    return
                }
            }
        }
        
        NSCursor.arrow.set()
        super.mouseMoved(with: event)
    }
    
    // 根据调整手柄设置光标
    private func setCursorForHandle(_ handle: ResizeHandle) {
        switch handle {
        case .topLeft, .bottomRight:
            NSCursor(image: NSImage(systemSymbolName: "arrow.up.left.and.arrow.down.right", accessibilityDescription: nil) ?? NSImage(), hotSpot: NSPoint(x: 8, y: 8)).set()
        case .topRight, .bottomLeft:
            NSCursor(image: NSImage(systemSymbolName: "arrow.up.right.and.arrow.down.left", accessibilityDescription: nil) ?? NSImage(), hotSpot: NSPoint(x: 8, y: 8)).set()
        case .left, .right:
            NSCursor.resizeLeftRight.set()
        case .top, .bottom:
            NSCursor.resizeUpDown.set()
        case .lineStart, .lineEnd:
            NSCursor.crosshair.set()
        }
    }
    
    // 获取图形边缘的调整手柄
    private func getEdgeHandle(for ann: PDFAnnotation, at pagePoint: CGPoint) -> ResizeHandle? {
        let bounds = ann.bounds
        let tol: CGFloat = 8
        
        let nearLeft = abs(pagePoint.x - bounds.minX) <= tol
        let nearRight = abs(pagePoint.x - bounds.maxX) <= tol
        let nearTop = abs(pagePoint.y - bounds.maxY) <= tol
        let nearBottom = abs(pagePoint.y - bounds.minY) <= tol
        
        // 角落优先
        if nearLeft && nearTop { return .topLeft }
        if nearRight && nearTop { return .topRight }
        if nearLeft && nearBottom { return .bottomLeft }
        if nearRight && nearBottom { return .bottomRight }
        
        // 边缘
        if nearLeft { return .left }
        if nearRight { return .right }
        if nearTop { return .top }
        if nearBottom { return .bottom }
        
        return nil
    }

    private func rectFrom(_ a: CGPoint, _ b: CGPoint) -> CGRect {
        CGRect(x: min(a.x, b.x), y: min(a.y, b.y), width: abs(a.x - b.x), height: abs(a.y - b.y))
    }

    private func ensureMinSize(_ r: CGRect, min: CGFloat = 6) -> CGRect {
        var rr = r
        if rr.width < min { rr.size.width = min }
        if rr.height < min { rr.size.height = min }
        return rr
    }

    private func applyStrokeStyle(_ ann: PDFAnnotation) {
        let border = PDFBorder(); border.lineWidth = shapeLineWidth; ann.border = border; ann.color = shapeStrokeColor; ann.interiorColor = .clear
    }

    private func updateLineAnnotation(_ ann: PDFAnnotation, start: CGPoint, end: CGPoint) {
        let lw = ann.border?.lineWidth ?? shapeLineWidth
        let r = rectFrom(start, end).insetBy(dx: -lw, dy: -lw)
        let b = ensureMinSize(r, min: 2)
        ann.bounds = b
        ann.startPoint = CGPoint(x: start.x - b.minX, y: start.y - b.minY)
        ann.endPoint = CGPoint(x: end.x - b.minX, y: end.y - b.minY)
    }

    // MARK: - Shape hit-testing
    private func distancePointToSegment(_ p: CGPoint, _ a: CGPoint, _ b: CGPoint) -> CGFloat {
        let abx = b.x - a.x; let aby = b.y - a.y; let apx = p.x - a.x; let apy = p.y - a.y
        let abLen2 = abx * abx + aby * aby
        if abLen2 == 0 { return sqrt((p.x - a.x)*(p.x - a.x) + (p.y - a.y)*(p.y - a.y)) }
        let t = max(0, min(1, (apx * abx + apy * aby) / abLen2))
        let proj = CGPoint(x: a.x + t * abx, y: a.y + t * aby)
        return sqrt((p.x - proj.x)*(p.x - proj.x) + (p.y - proj.y)*(p.y - proj.y))
    }

    private func hitShapeBorder(_ ann: PDFAnnotation, at pagePoint: CGPoint, tol: CGFloat = 6) -> Bool {
        let t = getSubtypeString(ann)
        let lw = ann.border?.lineWidth ?? shapeLineWidth
        let effectiveTol = max(tol, lw * 2)

        if t == "/Square" || t == "Square" || t == "/Circle" || t == "Circle" {
            let outer = ann.bounds.insetBy(dx: -effectiveTol, dy: -effectiveTol)
            let inner = ann.bounds.insetBy(dx: effectiveTol, dy: effectiveTol)
            return outer.contains(pagePoint) && !inner.contains(pagePoint)
        }
        if t == "/Line" || t == "Line" {
            let a = CGPoint(x: ann.bounds.minX + ann.startPoint.x, y: ann.bounds.minY + ann.startPoint.y)
            let b = CGPoint(x: ann.bounds.minX + ann.endPoint.x, y: ann.bounds.minY + ann.endPoint.y)
            return distancePointToSegment(pagePoint, a, b) <= effectiveTol
        }
        return ann.bounds.insetBy(dx: -effectiveTol, dy: -effectiveTol).contains(pagePoint)
    }

    // MARK: - Annotation grouping
    private let smartGroupPrefix = "SPDF-GRP:"
    private func newSmartGroupID() -> String { smartGroupPrefix + UUID().uuidString }
    private func smartGroupID(of a: PDFAnnotation) -> String? {
        guard let id = a.userName, id.hasPrefix(smartGroupPrefix) else { return nil }
        return id
    }
    private func isUnderline(_ a: PDFAnnotation) -> Bool { let s = getSubtypeString(a); return s == "/Underline" || s == "Underline" }

    // Payload classes for context menus
    private final class MarkColorPayload: NSObject {
        let annotation: PDFAnnotation; let baseColor: NSColor; let isHighlight: Bool
        init(annotation: PDFAnnotation, baseColor: NSColor, isHighlight: Bool) { self.annotation = annotation; self.baseColor = baseColor; self.isHighlight = isHighlight }
    }
    private final class NoteColorPayload: NSObject {
        let annotation: PDFAnnotation; let baseColor: NSColor
        init(annotation: PDFAnnotation, baseColor: NSColor) { self.annotation = annotation; self.baseColor = baseColor }
    }
    private final class FreeTextColorPayload: NSObject {
        let annotation: PDFAnnotation; let baseColor: NSColor
        init(annotation: PDFAnnotation, baseColor: NSColor) { self.annotation = annotation; self.baseColor = baseColor }
    }
    private final class ShapeColorPayload: NSObject {
        let annotation: PDFAnnotation; let baseColor: NSColor
        init(annotation: PDFAnnotation, baseColor: NSColor) { self.annotation = annotation; self.baseColor = baseColor }
    }

    private var menuColors: [(String, NSColor)] {
        [(L(.colorYellow), .systemYellow), (L(.colorGreen), .systemGreen), (L(.colorBlue), .systemBlue), (L(.colorRed), .systemRed), (L(.colorPurple), .systemPurple), (L(.colorOrange), .systemOrange), (L(.colorCyan), .systemTeal)]
    }

    private func colorDotImage(_ color: NSColor) -> NSImage {
        let size = NSSize(width: 10, height: 10)
        let img = NSImage(size: size)
        img.lockFocus()
        let rect = NSRect(origin: .zero, size: size)
        let path = NSBezierPath(ovalIn: rect.insetBy(dx: 0.25, dy: 0.25))
        color.setFill()
        path.fill()
        NSColor.black.withAlphaComponent(0.15).setStroke()
        path.lineWidth = 0.5
        path.stroke()
        img.unlockFocus()
        img.isTemplate = false
        return img
    }
    
    private func findLinkedNote(for anchor: PDFAnnotation) -> PDFAnnotation? {
        guard let doc = self.document else { return nil }
        if let gid = smartGroupID(of: anchor) {
            for i in 0..<doc.pageCount {
                guard let p = doc.page(at: i) else { continue }
                if let n = p.annotations.first(where: { isNote($0) && $0.userName == gid }) { return n }
            }
        }
        if let p = anchor.page {
            let expanded = anchor.bounds.insetBy(dx: -60, dy: -60)
            return p.annotations.first(where: { isNote($0) && expanded.intersects($0.bounds) })
        }
        return nil
    }

    private func ensureGroupID(for anchor: PDFAnnotation) -> String {
        if let gid = smartGroupID(of: anchor) { return gid }
        let gid = newSmartGroupID()
        anchor.userName = gid
        return gid
    }

    // MARK: - Heart drop: attach dragged text as a linked note to an existing highlight/underline/shape
    private func upsertLinkedNote(for anchor: PDFAnnotation, content: String) {
        let gid = ensureGroupID(for: anchor)

        // If a linked note already exists anywhere in the document (same group id), update it.
        if let doc = self.document {
            for i in 0..<doc.pageCount {
                guard let p = doc.page(at: i) else { continue }
                if let existingNote = p.annotations.first(where: { isNote($0) && $0.userName == gid }) {
                    existingNote.contents = content
                    // Keep note color aligned with anchor.
                    existingNote.color = anchor.color

                    // If callout textbox exists, keep it in sync too.
                    if let ft = findCalloutText(groupID: gid, on: p) {
                        ft.contents = content
                        autoSizeCalloutTextBox(ft, text: content)
                        refreshNoteCalloutConnector(groupID: gid, on: p)
                    }

                    forceRefresh()
                    NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
                    return
                }
            }
        }

        // Otherwise create a new linked note on the anchor's page.
        guard let page = anchor.page else { return }
        let anchorColor = anchor.color
        let c = (anchorColor.alphaComponent == 0) ? NSColor.systemYellow.withAlphaComponent(0.5) : anchorColor
        _ = addNoteAnnotation(page: page, highlightBounds: anchor.bounds, color: c, content: content, groupID: gid)
        forceRefresh()
    }

    override func mouseUp(with event: NSEvent) {
        if shapeDraftAnnotation != nil {
            if let ann = shapeDraftAnnotation { selectedAnnotation = ann }
            shapeDraftAnnotation = nil; shapeDraftPage = nil; activeShapeTool = .none; shapeTool = .none
            NSCursor.arrow.set(); forceRefresh()
            NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
            return
        }
        if let moved = draggedAnnotation {
            if moved.bounds != originalAnnotationBounds {
                registerBoundsUndo(moved, previous: originalAnnotationBounds)
                NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
            }
            draggedAnnotation = nil; dragMode = .move; self.layoutDocumentView(); return
        }
        super.mouseUp(with: event)
        self.lastMouseUpEvent = event
        DispatchQueue.main.async {
            if let selection = self.currentSelection, let text = selection.string, !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                self.coordinator?.showSelectionMenu(in: self)
            }
        }
    }
    
    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        // 监听documentView的边界变化（滚动）
        if let docView = documentView {
            docView.postsFrameChangedNotifications = true
            docView.postsBoundsChangedNotifications = true
            NotificationCenter.default.addObserver(
                self,
                selector: #selector(handleDocumentViewBoundsChange),
                name: NSView.boundsDidChangeNotification,
                object: enclosingScrollView?.contentView
            )
        }
    }
    
    @objc private func handleDocumentViewBoundsChange(_ notification: Notification) {
        // 页面滚动时更新overlay位置
        updateCalloutOverlayPositions()
        updateTextOverlays()
    }
    
    override func layout() {
        super.layout()
        calloutConnectorHostView?.frame = bounds
        calloutOverlayHostView?.frame = bounds
        if let host = calloutConnectorHostView {
            for (_, l) in calloutConnectorLayers { l.frame = host.bounds }
        }
        updateCalloutOverlayPositions()
        updateTextOverlays()
    }
    
    override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation { return sender.draggingPasteboard.types?.contains(.string) == true ? .copy : super.draggingEntered(sender) }
    
    override func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
        let pboard = sender.draggingPasteboard
        if let text = pboard.string(forType: .string) {
            let pointInView = self.convert(sender.draggingLocation, from: nil)
            if let page = self.page(for: pointInView, nearest: true) {
                let pointInPage = self.convert(pointInView, to: page)
                let isHeart = pboard.types?.contains(NSPasteboard.PasteboardType("com.smartpdf.isheart")) ?? false

                // Drop onto current text selection: add highlight + note using the dragged text.
                if let sel = currentSelection, sel.pages.contains(page) {
                    let sb = sel.bounds(for: page)
                    if !sb.isEmpty, sb.insetBy(dx: -6, dy: -6).contains(pointInPage) {
                        _ = addNoteToSelection(color: .systemYellow.withAlphaComponent(0.5), content: text)
                        return true
                    }
                }
                // If dropped onto a supported target (shape / underline / highlight), always attach as a linked note.
                // This applies to both heart-drags and normal text drags from the left dialog.
                let hits = findAnnotations(on: page, at: pointInPage)
                
                // 拖放到FreeText中：只有当FreeText已经处于编辑状态时才允许插入文本
                if let freeText = hits.reversed().first(where: { isFreeText($0) && !isNoteCalloutText($0) && $0.bounds.contains(pointInPage) }) {
                    // 检查该FreeText是否正在被编辑
                    if inlineEditingAnnotation === freeText,
                       let editor = inlineEditorScrollView?.documentView as? DraggableTextView {
                        // FreeText已在编辑状态，在光标位置插入文本
                        // 将markdown格式转换为纯文本
                        let plainText = CustomPDFView.convertMarkdownToPlainText(text)
                        
                        // 计算在FreeText内的相对位置
                        let relativePoint = CGPoint(
                            x: pointInPage.x - freeText.bounds.minX,
                            y: pointInPage.y - freeText.bounds.minY
                        )
                        
                        // 将PDF坐标转换为文本视图坐标
                        let textViewPoint = CGPoint(
                            x: relativePoint.x,
                            y: freeText.bounds.height - relativePoint.y  // 翻转Y坐标
                        )
                        
                        // 计算插入位置
                        var insertionIndex = (editor.string as NSString).length // 默认在末尾
                        
                        if let layoutManager = editor.layoutManager,
                           let textContainer = editor.textContainer {
                            let adjustedPoint = CGPoint(
                                x: textViewPoint.x - editor.textContainerInset.width,
                                y: textViewPoint.y - editor.textContainerInset.height
                            )
                            var fraction: CGFloat = 0
                            let glyphIndex = layoutManager.glyphIndex(for: adjustedPoint, in: textContainer, fractionOfDistanceThroughGlyph: &fraction)
                            var charIndex = layoutManager.characterIndexForGlyph(at: glyphIndex)
                            if fraction > 0.5 && charIndex < (editor.string as NSString).length {
                                charIndex += 1
                            }
                            insertionIndex = min(charIndex, (editor.string as NSString).length)
                        }
                        
                        // 在计算出的位置插入文本
                        if let textStorage = editor.textStorage {
                            var attrs: [NSAttributedString.Key: Any] = [
                                .font: editor.font ?? NSFont.systemFont(ofSize: 14),
                                .foregroundColor: editor.textColor ?? NSColor.labelColor
                            ]
                            let textLength = (editor.string as NSString).length
                            if textLength > 0 && insertionIndex > 0 {
                                attrs = textStorage.attributes(at: max(0, insertionIndex - 1), effectiveRange: nil)
                            }
                            
                            let attrString = NSAttributedString(string: plainText, attributes: attrs)
                            textStorage.insert(attrString, at: insertionIndex)
                        }
                        
                        // 将光标移到插入文本末尾
                        let newCursorPosition = insertionIndex + (plainText as NSString).length
                        editor.setSelectedRange(NSRange(location: newCursorPosition, length: 0))
                        editor.scrollRangeToVisible(NSRange(location: newCursorPosition, length: 0))
                        editor.needsDisplay = true
                        
                        return true
                    }
                    // FreeText未在编辑状态，不处理拖放（继续按其他逻辑处理）
                }

                if let shape = hits.reversed().first(where: {
                    isShape($0) && (hitShapeBorder($0, at: pointInPage) || $0.bounds.contains(pointInPage))
                }) {
                    upsertLinkedNote(for: shape, content: text)
                    layoutDocumentView()
                    return true
                }

                if let mark = hits.reversed().first(where: {
                    (isHighlight($0) || isUnderline($0)) && $0.bounds.contains(pointInPage)
                }) {
                    upsertLinkedNote(for: mark, content: text)
                    layoutDocumentView()
                    return true
                }

                // Heart drag fallback: if not dropped on a supported target, create a standalone heart note icon (old behavior).
                if isHeart {
                    let bounds = CGRect(x: pointInPage.x - noteIconHalf,
                                        y: pointInPage.y - noteIconHalf,
                                        width: noteIconSize,
                                        height: noteIconSize)
                    let ann = PDFAnnotation(bounds: bounds, forType: .text, withProperties: nil)
                    ann.iconType = .comment
                    ann.color = .systemPink
                    ann.shouldPrint = true
                    ann.contents = text
                    page.addAnnotation(ann)
                    layoutDocumentView()
                    NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
                    return true
                }

                addDroppedText(text, on: page, at: pointInPage)
                return true
            }
        }
        return super.performDragOperation(sender)
    }

    private func getSubtypeString(_ a: PDFAnnotation) -> String { if let s = a.value(forAnnotationKey: .subtype) as? String { return s }; if let s = a.value(forAnnotationKey: .subtype) as? PDFAnnotationSubtype { return s.rawValue }; return a.type ?? "" }
    private func isHighlight(_ a: PDFAnnotation) -> Bool { return getSubtypeString(a) == "/Highlight" || getSubtypeString(a) == "Highlight" }
    private func isNote(_ a: PDFAnnotation) -> Bool { return getSubtypeString(a) == "/Text" || getSubtypeString(a) == "Text" }
    private func isFreeText(_ a: PDFAnnotation) -> Bool { return getSubtypeString(a) == "/FreeText" || getSubtypeString(a) == "FreeText" }
    
    @discardableResult
    func addDroppedText(_ text: String, on page: PDFPage, at point: CGPoint) -> PDFAnnotation {
        let plainText = Self.convertMarkdownToPlainText(text)
        let pageBounds = page.bounds(for: displayBox).insetBy(dx: 12, dy: 12)
        let font = NSFont.systemFont(ofSize: 11)
        let width = min(280, max(40, pageBounds.width))
        let size = ReadablePDFTextAnnotation.fittedSize(text: plainText, font: font, width: width, maxHeight: max(36, pageBounds.height))
        let x = min(max(point.x, pageBounds.minX), pageBounds.maxX - size.width)
        let y = min(max(point.y - size.height, pageBounds.minY), pageBounds.maxY - size.height)
        let annotation = ReadablePDFTextAnnotation(bounds: CGRect(origin: CGPoint(x: x, y: y), size: size), forType: .freeText, withProperties: nil)
        annotation.font = font; annotation.fontColor = NSColor(srgbRed: 0.83, green: 0.13, blue: 0.18, alpha: 1)
        annotation.color = .clear; annotation.border = nil; annotation.contents = plainText
        annotation.setValue(ReadablePDFTextAnnotation.subject, forAnnotationKey: .spdfSubject)
        annotation.shouldPrint = true
        page.addAnnotation(annotation)
        registerUndoForAnnotationAddition(annotation, on: page)
        forceRefresh()
        NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
        return annotation
    }

    private var textOverlays: [ObjectIdentifier: ReadablePDFTextView] = [:]
    private var textOverlayHost: NSView?

    private func updateTextOverlays() {
        guard document != nil else { return }
        let visible = visiblePages
        var annotations: [ObjectIdentifier: ReadablePDFTextAnnotation] = [:]
        for page in visible {
            for annotation in page.annotations {
                guard let text = annotation as? ReadablePDFTextAnnotation else { continue }
                let key = ObjectIdentifier(text)
                if text.shouldDisplay || textOverlays[key] != nil { annotations[key] = text }
            }
        }
        for (key, overlay) in Array(textOverlays) where annotations[key] == nil {
            overlay.annotation?.shouldDisplay = true
            overlay.removeFromSuperview(); textOverlays.removeValue(forKey: key)
        }
        guard !annotations.isEmpty else { return }
        if textOverlayHost == nil {
            let host = PassthroughHostView(frame: bounds)
            host.wantsLayer = true; host.layer?.masksToBounds = true
            host.autoresizingMask = [.width, .height]
            if let documentView { addSubview(host, positioned: .above, relativeTo: documentView) }
            else { addSubview(host) }
            textOverlayHost = host
        }
        guard let host = textOverlayHost else { return }
        host.frame = bounds
        for (key, annotation) in annotations {
            guard let page = annotation.page else { continue }
            let overlay: ReadablePDFTextView
            if let existing = textOverlays[key] { overlay = existing }
            else {
                overlay = ReadablePDFTextView(); overlay.annotation = annotation; overlay.owner = self
                overlay.identifier = NSUserInterfaceItemIdentifier("spdf.readable-text")
                host.addSubview(overlay); textOverlays[key] = overlay
            }
            if annotation.shouldDisplay { annotation.shouldDisplay = false }
            overlay.frame = host.convert(convert(annotation.bounds, from: page), from: self)
            let origin = overlay.convert(convert(CGPoint.zero, from: page), from: self)
            let x = overlay.convert(convert(CGPoint(x: 1, y: 0), from: page), from: self)
            let y = overlay.convert(convert(CGPoint(x: 0, y: 1), from: page), from: self)
            overlay.pageTransform = CGAffineTransform(a: x.x - origin.x, b: x.y - origin.y,
                c: y.x - origin.x, d: y.y - origin.y, tx: origin.x, ty: origin.y)
            overlay.needsDisplay = true
        }
    }

    func canInteractWithText(_ annotation: PDFAnnotation) -> Bool {
        shapeTool == .none && inlineEditingAnnotation !== annotation
    }

    private func registerBoundsUndo(_ annotation: PDFAnnotation, previous: CGRect) {
        registerAnnotationUndo(T("移动文字", "Move text")) { target in
            let current = annotation.bounds
            annotation.bounds = previous
            target.registerBoundsUndo(annotation, previous: current)
            target.forceRefresh()
            NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
        }
    }

    func serializedDocumentData() -> Data? {
        prepareForSaving()
        defer { updateTextOverlays() }
        return document?.dataRepresentation()
    }

    func prepareForSaving() {
        closeInlineEditor(commit: true)
        for overlay in calloutOverlays.values { overlay.finishEditing() }
        for overlay in textOverlays.values { overlay.annotation?.shouldDisplay = true }
    }

    func prepareForDocumentChange() {
        closeInlineEditor(commit: true)
        coordinator?.popover?.close()
        for overlay in textOverlays.values { overlay.annotation?.shouldDisplay = true; overlay.removeFromSuperview() }
        textOverlays.removeAll()
        for overlay in calloutOverlays.values { overlay.finishEditing(); overlay.removeFromSuperview() }
        calloutOverlays.removeAll()
        for layer in calloutConnectorLayers.values { layer.removeFromSuperlayer() }
        calloutConnectorLayers.removeAll()
        removeOverlayEditMonitor()
        selectedAnnotation = nil; draggedAnnotation = nil
    }

    // MARK: - Note Callout Identifiers
    private let noteCalloutSubject = "SPDF_NOTE_CALLOUT"
    private let noteConnectorSubject = "SPDF_NOTE_CONNECTOR"
    private func annotationSubject(_ a: PDFAnnotation) -> String? { a.value(forAnnotationKey: .spdfSubject) as? String }
    private func setAnnotationSubject(_ a: PDFAnnotation, _ s: String) { a.setValue(s, forAnnotationKey: .spdfSubject) }
    private func isNoteCalloutText(_ a: PDFAnnotation) -> Bool { let t = getSubtypeString(a); return (t == "/FreeText" || t == "FreeText") && annotationSubject(a) == noteCalloutSubject }
    private func isNoteConnectorLine(_ a: PDFAnnotation) -> Bool { let t = getSubtypeString(a); return (t == "/Line" || t == "Line") && annotationSubject(a) == noteConnectorSubject }
    // MARK: - Inline editor for note callout FreeText (no separate popover)
    private weak var inlineEditingAnnotation: PDFAnnotation?
    private var inlineEditorScrollView: NSScrollView?
    private var inlineEditorMonitor: Any?
    private var inlineEditingOriginalFontColor: NSColor?
    private var inlineEditingOriginalContents: String?

    // For dismissing overlay edit mode when clicking outside
    private var overlayEditMonitor: Any?
    private func removeOverlayEditMonitor() {
        if let m = overlayEditMonitor {
            NSEvent.removeMonitor(m)
            overlayEditMonitor = nil
        }
    }

    private func installOverlayEditDismissMonitor(excluding overlayView: NSView) {
        // Ensure only one active monitor.
        removeOverlayEditMonitor()

        overlayEditMonitor = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown]) { [weak self, weak overlayView] event in
            guard let self else { return event }

            // If the overlay is gone, stop monitoring.
            guard let ov = overlayView else {
                self.removeOverlayEditMonitor()
                return event
            }

            // If click is inside the overlay, let it pass.
            if let w = ov.window, event.window === w, let cv = w.contentView {
                let loc = event.locationInWindow
                let p = cv.convert(loc, from: nil)
                if let hit = cv.hitTest(p), hit.isDescendant(of: ov) {
                    return event
                }
            }

            // Click outside overlay: if we're currently editing an overlay's text view, end editing.
            if let w = self.window, let tv = w.firstResponder as? NSTextView {
                for (_, overlay) in self.calloutOverlays {
                    if tv.isDescendant(of: overlay) {
                        w.makeFirstResponder(self)
                        // 编辑结束，刷新侧边栏
                        NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
                        break
                    }
                }
            }

            self.removeOverlayEditMonitor()
            return event
        }
    }

    private func closeInlineEditor(commit: Bool) {
        guard let scroll = inlineEditorScrollView,
              let tv = scroll.documentView as? NSTextView else {
            inlineEditingAnnotation = nil
            inlineEditingOriginalFontColor = nil
            inlineEditingOriginalContents = nil
            return
        }

        // Capture before defer clears state
        let editingAnn = inlineEditingAnnotation
        let originalColor = inlineEditingOriginalFontColor
        let originalContents = inlineEditingOriginalContents

        defer {
            if let ann = editingAnn {
                // Restore the original font color so the PDF annotation text renders again.
                if let oc = originalColor {
                    ann.fontColor = oc
                } else if ann.fontColor == .clear {
                    ann.fontColor = .labelColor
                }

                // If we were hiding the text by clearing contents, restore on cancel.
                if !commit, let ocText = originalContents {
                    ann.contents = ocText
                }

                // Force PDFKit to regenerate appearance after temporary edits.
                ann.removeValue(forAnnotationKey: PDFAnnotationKey(rawValue: "AP"))
            }

            if let m = inlineEditorMonitor { NSEvent.removeMonitor(m); inlineEditorMonitor = nil }
            scroll.removeFromSuperview()
            inlineEditorScrollView = nil
            inlineEditingAnnotation = nil
            inlineEditingOriginalFontColor = nil
            inlineEditingOriginalContents = nil
        }

        guard commit, let ann = editingAnn else { return }
        let newText = tv.string
        ann.contents = newText
        if ann is ReadablePDFTextAnnotation, let page = ann.page {
            let size = ReadablePDFTextAnnotation.fittedSize(text: newText, font: ann.font ?? .systemFont(ofSize: 14),
                width: ann.bounds.width, maxHeight: page.bounds(for: displayBox).height - 24)
            let top = ann.bounds.maxY
            ann.bounds.size.height = max(ann.bounds.height, size.height)
            ann.bounds.origin.y = max(page.bounds(for: displayBox).minY + 12, top - ann.bounds.height)
        }

        // If this FreeText is a callout, also sync the owning note and update size/connector.
        if isNoteCalloutText(ann),
           let page = ann.page,
           let gid = ann.userName {
            if let note = page.annotations.first(where: { isNote($0) && $0.userName == gid }) {
                note.contents = newText
            }
            autoSizeCalloutTextBox(ann, text: newText)
            refreshNoteCalloutConnector(groupID: gid, on: page)
        }

        forceRefresh()
        // [新增] 发送通知刷新侧边栏
        NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
    }

    private func installInlineEditorDismissMonitor(excluding editorView: NSView) {
        if inlineEditorMonitor != nil { return }
        inlineEditorMonitor = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown]) { [weak self, weak editorView] event in
            guard let self else { return event }
            guard let evView = editorView else {
                self.closeInlineEditor(commit: true)
                return event
            }

            // 检查点击是否在编辑器内部（包括ScrollView和其子视图TextView）
            if let w = evView.window, event.window === w {
                let loc = event.locationInWindow
                
                // 方法1：检查hitTest结果是否是编辑器的后代
                if let contentView = w.contentView {
                    let p = contentView.convert(loc, from: nil)
                    if let hit = contentView.hitTest(p) {
                        // 检查点击的视图是否是编辑器或其子视图
                        if hit.isDescendant(of: evView) || hit === evView {
                            return event
                        }
                        // 特别检查：如果点击的是NSTextView（DraggableTextView）
                        if hit is NSTextView, let scroll = evView as? NSScrollView, hit.isDescendant(of: scroll) {
                            return event
                        }
                    }
                }
                
                // 方法2：直接检查点击位置是否在编辑器的frame内
                let pointInEditor = evView.convert(loc, from: nil)
                if evView.bounds.contains(pointInEditor) {
                    return event
                }
                
                // 检查点击位置是否在ScrollView的documentView内
                if let scroll = evView as? NSScrollView, let docView = scroll.documentView {
                    let pointInDocView = docView.convert(loc, from: nil)
                    if docView.bounds.contains(pointInDocView) {
                        return event
                    }
                }
            }
            
            // 只有当点击发生在PDF视图区域内时才关闭编辑器
            // 如果点击在其他窗口或PDF视图以外的区域（如AI侧边栏），保持编辑状态
            if let selfWindow = self.window, event.window === selfWindow {
                let loc = event.locationInWindow
                let pointInSelf = self.convert(loc, from: nil)
                
                // 只有点击在PDF视图内部时才关闭编辑器
                if self.bounds.contains(pointInSelf) {
                    self.closeInlineEditor(commit: true)
                }
                // 点击在同一窗口但不在PDF视图内（如AI侧边栏），不关闭编辑器
            }
            // 点击在其他窗口，不关闭编辑器
            
            return event
        }
    }

    // MARK: - 支持拖放的NSTextView子类（用于FreeText内联编辑）
    private final class DraggableTextView: NSTextView {
        weak var ownerPDFView: CustomPDFView?
        private var isDragInProgress: Bool = false
        
        // 使用CAShapeLayer来绘制自定义光标（更可靠）
        private var dragCursorLayer: CAShapeLayer?
        private var cursorBlinkTimer: Timer?
        
        override init(frame frameRect: NSRect, textContainer container: NSTextContainer?) {
            super.init(frame: frameRect, textContainer: container)
            setupDragSupport()
        }
        
        override init(frame frameRect: NSRect) {
            super.init(frame: frameRect)
            setupDragSupport()
        }
        
        required init?(coder: NSCoder) {
            super.init(coder: coder)
            setupDragSupport()
        }
        
        deinit {
            stopCursorBlinkTimer()
            removeDragCursor()
        }
        
        private func setupDragSupport() {
            // 注册支持的拖放类型：普通字符串和AI侧边栏的心形拖放
            registerForDraggedTypes([.string, NSPasteboard.PasteboardType("com.smartpdf.isheart")])
            wantsLayer = true
        }
        
        // 创建拖放光标层
        private func createDragCursor() {
            removeDragCursor()
            
            let cursor = CAShapeLayer()
            cursor.strokeColor = NSColor.systemBlue.cgColor
            cursor.lineWidth = 2.0
            cursor.lineCap = .round
            self.layer?.addSublayer(cursor)
            dragCursorLayer = cursor
        }
        
        // 更新光标位置和形状
        private func updateDragCursorPosition(at charIndex: Int) {
            guard let layoutManager = self.layoutManager,
                  let textContainer = self.textContainer,
                  let cursor = dragCursorLayer else { return }
            
            // 获取字符位置的矩形
            let glyphRange = layoutManager.glyphRange(forCharacterRange: NSRange(location: charIndex, length: 0), actualCharacterRange: nil)
            var lineFragmentRect = layoutManager.lineFragmentRect(forGlyphAt: max(0, glyphRange.location > 0 ? glyphRange.location - 1 : 0), effectiveRange: nil)
            
            // 获取光标的x位置
            var cursorX: CGFloat
            if charIndex == 0 {
                cursorX = textContainerInset.width
            } else if charIndex >= (string as NSString).length {
                // 在文本末尾
                let lastGlyphIndex = layoutManager.glyphIndexForCharacter(at: max(0, (string as NSString).length - 1))
                let lastGlyphRect = layoutManager.boundingRect(forGlyphRange: NSRange(location: lastGlyphIndex, length: 1), in: textContainer)
                cursorX = lastGlyphRect.maxX + textContainerInset.width
                lineFragmentRect = layoutManager.lineFragmentRect(forGlyphAt: lastGlyphIndex, effectiveRange: nil)
            } else {
                let glyphRect = layoutManager.boundingRect(forGlyphRange: NSRange(location: glyphRange.location, length: 1), in: textContainer)
                cursorX = glyphRect.minX + textContainerInset.width
            }
            
            // 计算光标的Y位置（考虑翻转坐标系）
            let cursorY = lineFragmentRect.minY + textContainerInset.height
            let cursorHeight = lineFragmentRect.height
            
            // 由于layer坐标系和view坐标系可能不同，需要调整
            let path = CGMutablePath()
            path.move(to: CGPoint(x: cursorX, y: cursorY))
            path.addLine(to: CGPoint(x: cursorX, y: cursorY + cursorHeight))
            cursor.path = path
        }
        
        // 移除光标层
        private func removeDragCursor() {
            dragCursorLayer?.removeFromSuperlayer()
            dragCursorLayer = nil
        }
        
        // 启动光标闪烁
        private func startCursorBlinkTimer() {
            stopCursorBlinkTimer()
            
            // 使用CABasicAnimation实现闪烁
            if let cursor = dragCursorLayer {
                let animation = CABasicAnimation(keyPath: "opacity")
                animation.fromValue = 1.0
                animation.toValue = 0.0
                animation.duration = 0.5
                animation.autoreverses = true
                animation.repeatCount = .infinity
                cursor.add(animation, forKey: "blink")
            }
        }
        
        private func stopCursorBlinkTimer() {
            cursorBlinkTimer?.invalidate()
            cursorBlinkTimer = nil
            dragCursorLayer?.removeAnimation(forKey: "blink")
        }
        
        override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation {
            // 检查是否包含文本内容（普通字符串或AI侧边栏心形拖放）
            let hasText = sender.draggingPasteboard.types?.contains(.string) == true
            if hasText {
                isDragInProgress = true
                
                // 创建并显示拖放光标
                createDragCursor()
                
                // 更新光标位置
                updateCursorPositionForDrag(sender)
                
                // 启动闪烁动画
                startCursorBlinkTimer()
                
                return .copy
            }
            return []
        }
        
        override func draggingUpdated(_ sender: NSDraggingInfo) -> NSDragOperation {
            let hasText = sender.draggingPasteboard.types?.contains(.string) == true
            if hasText {
                updateCursorPositionForDrag(sender)
                return .copy
            }
            return []
        }
        
        override func draggingExited(_ sender: NSDraggingInfo?) {
            isDragInProgress = false
            stopCursorBlinkTimer()
            removeDragCursor()
        }
        
        private func updateCursorPositionForDrag(_ sender: NSDraggingInfo) {
            let localPoint = convert(sender.draggingLocation, from: nil)
            
            if let layoutManager = self.layoutManager,
               let textContainer = self.textContainer {
                // 调整坐标以考虑textContainerInset
                let adjustedPoint = CGPoint(x: localPoint.x - textContainerInset.width,
                                           y: localPoint.y - textContainerInset.height)
                
                // 获取字符索引
                var fraction: CGFloat = 0
                let glyphIndex = layoutManager.glyphIndex(for: adjustedPoint, in: textContainer, fractionOfDistanceThroughGlyph: &fraction)
                var charIndex = layoutManager.characterIndexForGlyph(at: glyphIndex)
                
                // 如果点击位置在字符的后半部分，则光标应该在下一个字符位置
                if fraction > 0.5 && charIndex < (string as NSString).length {
                    charIndex += 1
                }
                
                let safeIndex = min(charIndex, (string as NSString).length)
                
                // 设置插入点位置（长度为0表示只有光标，没有选择）
                setSelectedRange(NSRange(location: safeIndex, length: 0))
                
                // 更新自定义光标位置
                updateDragCursorPosition(at: safeIndex)
            }
        }
        
        override func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
            if let text = sender.draggingPasteboard.string(forType: .string) {
                isDragInProgress = false
                stopCursorBlinkTimer()
                removeDragCursor()
                
                // 将markdown格式转换为纯文本
                let plainText = CustomPDFView.convertMarkdownToPlainText(text)
                
                // 确保有焦点
                if window?.firstResponder !== self {
                    window?.makeFirstResponder(self)
                }
                
                // 获取当前插入点位置
                let insertionPoint = selectedRange().location
                let textLength = (string as NSString).length
                let safeInsertionPoint = min(insertionPoint, textLength)
                
                // 使用textStorage直接插入文本
                if let textStorage = self.textStorage {
                    // 获取当前的文本属性
                    var attrs: [NSAttributedString.Key: Any] = [
                        .font: font ?? NSFont.systemFont(ofSize: 14),
                        .foregroundColor: textColor ?? NSColor.labelColor
                    ]
                    if textLength > 0 && safeInsertionPoint > 0 {
                        attrs = textStorage.attributes(at: max(0, safeInsertionPoint - 1), effectiveRange: nil)
                    }
                    
                    let attrString = NSAttributedString(string: plainText, attributes: attrs)
                    textStorage.insert(attrString, at: safeInsertionPoint)
                }
                
                // 将光标移到插入文本末尾
                let newCursorPosition = safeInsertionPoint + (plainText as NSString).length
                
                DispatchQueue.main.async { [weak self] in
                    guard let self else { return }
                    self.setSelectedRange(NSRange(location: newCursorPosition, length: 0))
                    self.scrollRangeToVisible(NSRange(location: newCursorPosition, length: 0))
                    self.needsDisplay = true
                }
                
                return true
            }
            return false
        }
        
        override func concludeDragOperation(_ sender: NSDraggingInfo?) {
            isDragInProgress = false
            stopCursorBlinkTimer()
            removeDragCursor()
            DispatchQueue.main.async { [weak self] in
                guard let self else { return }
                // 确保仍然是第一响应者，这样光标会继续闪烁
                if self.window?.firstResponder !== self {
                    self.window?.makeFirstResponder(self)
                }
                self.needsDisplay = true
            }
        }
    }

    // 1. 优化 beginInlineEdit 方法
    private func beginInlineEdit(for ft: PDFAnnotation, clickPointInPage: CGPoint? = nil) {
        // Close any existing editor first.
        closeInlineEditor(commit: true)
        guard let page = ft.page, let docView = self.documentView else { return }

        // 将批注坐标转换为 documentView 坐标
        let viewRect = self.convert(ft.bounds, from: page)
        var rectInDoc = docView.convert(viewRect, from: self)

        // 确保最小尺寸，避免无法编辑
        if rectInDoc.width < 60 { rectInDoc.size.width = 60 }
        if rectInDoc.height < 40 { rectInDoc.size.height = 40 }

        // 保存原始状态
        inlineEditingOriginalFontColor = ft.fontColor
        inlineEditingOriginalContents = ft.contents ?? ""
        ft.contents = ""
        ft.fontColor = .clear
        ft.removeValue(forAnnotationKey: PDFAnnotationKey(rawValue: "AP"))

        // 创建 ScrollView 和 TextView
        let scroll = NSScrollView(frame: rectInDoc)
        scroll.hasVerticalScroller = true
        scroll.drawsBackground = false
        scroll.borderType = .noBorder

        let tv = DraggableTextView(frame: scroll.bounds)
        tv.ownerPDFView = self
        tv.string = inlineEditingOriginalContents ?? ""
        let pageFont = ft.font ?? NSFont.systemFont(ofSize: 14)
        tv.font = NSFont(descriptor: pageFont.fontDescriptor, size: pageFont.pointSize * scaleFactor) ?? .systemFont(ofSize: 14 * scaleFactor)
        tv.textColor = inlineEditingOriginalFontColor ?? .labelColor
        tv.drawsBackground = false
        tv.backgroundColor = .clear
        tv.isRichText = false
        tv.importsGraphics = false
        tv.isVerticallyResizable = true
        tv.isHorizontallyResizable = false
        tv.textContainerInset = NSSize(width: 3 * scaleFactor, height: 3 * scaleFactor)
        let editParagraph = NSMutableParagraphStyle(); editParagraph.lineSpacing = 1.5 * scaleFactor
        tv.defaultParagraphStyle = editParagraph

        // 配置 TextContainer
        if let tc = tv.textContainer {
            tc.lineFragmentPadding = 0
            tc.widthTracksTextView = true
            tc.containerSize = NSSize(width: rectInDoc.width, height: CGFloat.greatestFiniteMagnitude)
        }

        scroll.documentView = tv
        docView.addSubview(scroll)

        inlineEditingAnnotation = ft
        inlineEditorScrollView = scroll

        self.window?.makeFirstResponder(tv)
        
        // [修复关键点] 优化光标定位逻辑
        if let clickPoint = clickPointInPage {
            // clickPoint 是 PDF 页面坐标 (原点左下)
            // ft.bounds 是 PDF 页面坐标
            // 我们需要计算相对于 TextView 内容区域的点击位置
            
            // 1. 计算相对于批注左上角的偏移量 (PDF坐标系中，y越上值越大)
            // PDF Rect: (x, y, w, h). maxY is top.
            let offsetX = clickPoint.x - ft.bounds.minX
            let offsetY = ft.bounds.maxY - clickPoint.y // 翻转Y轴：顶点距离
            
            // 2. 加上 TextView 的内边距
            let textPoint = CGPoint(x: offsetX, y: offsetY)
            
            // 3. 利用 LayoutManager 计算最近的字符索引
            if let layoutManager = tv.layoutManager, let textContainer = tv.textContainer {
                // 考虑 inset
                let locationInContainer = CGPoint(
                    x: textPoint.x - tv.textContainerInset.width,
                    y: textPoint.y - tv.textContainerInset.height
                )
                
                let glyphIndex = layoutManager.glyphIndex(for: locationInContainer, in: textContainer)
                let charIndex = layoutManager.characterIndexForGlyph(at: glyphIndex)
                
                tv.setSelectedRange(NSRange(location: charIndex, length: 0))
            }
        } else {
            // 如果没有点击位置（如新建），全选文本
            tv.selectAll(nil)
        }
        
        installInlineEditorDismissMonitor(excluding: scroll)
    }
    
    private func isShape(_ a: PDFAnnotation) -> Bool { let t = getSubtypeString(a); if t == "/Line" || t == "Line" { return !isNoteConnectorLine(a) }; return t == "/Square" || t == "Square" || t == "/Circle" || t == "Circle" }
    private func findAnnotations(on p: PDFPage, at pp: CGPoint) -> [PDFAnnotation] {
        return p.annotations.filter {
            // 忽略被刻意隐藏的注解（例如：被 toggle off 的 callout 文本框，以及 shouldDisplay=false 的原生连接线）
            guard $0.shouldDisplay || textOverlays[ObjectIdentifier($0)] != nil else { return false }
            return $0.bounds.insetBy(dx: -10, dy: -10).contains(pp)
        }
    }

    private func getBoxHandleRects(for bounds: CGRect) -> [ResizeHandle: CGRect] {
        let size: CGFloat = 8; let half = size / 2
        return [
            .topLeft: CGRect(x: bounds.minX - half, y: bounds.maxY - half, width: size, height: size),
            .top: CGRect(x: bounds.midX - half, y: bounds.maxY - half, width: size, height: size),
            .topRight: CGRect(x: bounds.maxX - half, y: bounds.maxY - half, width: size, height: size),
            .right: CGRect(x: bounds.maxX - half, y: bounds.midY - half, width: size, height: size),
            .bottomRight: CGRect(x: bounds.maxX - half, y: bounds.minY - half, width: size, height: size),
            .bottom: CGRect(x: bounds.midX - half, y: bounds.minY - half, width: size, height: size),
            .bottomLeft: CGRect(x: bounds.minX - half, y: bounds.minY - half, width: size, height: size),
            .left: CGRect(x: bounds.minX - half, y: bounds.midY - half, width: size, height: size)
        ]
    }

    private func getHandleRects(for annotation: PDFAnnotation) -> [ResizeHandle: CGRect] {
        let size: CGFloat = 8; let half = size / 2
        let t = getSubtypeString(annotation)
        if t == "/Line" || t == "Line" {
            let start = CGPoint(x: annotation.bounds.minX + annotation.startPoint.x, y: annotation.bounds.minY + annotation.startPoint.y)
            let end = CGPoint(x: annotation.bounds.minX + annotation.endPoint.x, y: annotation.bounds.minY + annotation.endPoint.y)
            return [.lineStart: CGRect(x: start.x - half, y: start.y - half, width: size, height: size), .lineEnd: CGRect(x: end.x - half, y: end.y - half, width: size, height: size)]
        }
        return getBoxHandleRects(for: annotation.bounds)
    }

    private func hitResizeHandle(for a: PDFAnnotation, at pp: CGPoint) -> ResizeHandle? {
        if a == selectedAnnotation { for (handle, rect) in getHandleRects(for: a) { if rect.contains(pp) { return handle } } }
        if isFreeText(a) {
             let b = a.bounds; let inner = b.insetBy(dx: 10, dy: 10); if inner.contains(pp) { return nil }
             let tol: CGFloat = 6; let (nl, nr, nb, nt) = (abs(pp.x-b.minX)<=tol, abs(pp.x-b.maxX)<=tol, abs(pp.y-b.minY)<=tol, abs(pp.y-b.maxY)<=tol)
             if nl && nt { return .topLeft }; if nr && nt { return .topRight }; if nl && nb { return .bottomLeft }; if nr && nb { return .bottomRight }
             if nl { return .left }; if nr { return .right }; if nt { return .top }; if nb { return .bottom }; return nil
        }
        return nil
    }

    private func resizedBounds(from o: CGRect, handle: ResizeHandle, dx: CGFloat, dy: CGFloat) -> CGRect {
        var (x0, y0, x1, y1) = (o.minX, o.minY, o.maxX, o.maxY)
        switch handle {
        case .topLeft: x0 += dx; y1 += dy; case .topRight: x1 += dx; y1 += dy; case .bottomLeft: x0 += dx; y0 += dy; case .bottomRight: x1 += dx; y0 += dy
        case .left: x0 += dx; case .right: x1 += dx; case .top: y1 += dy; case .bottom: y0 += dy; case .lineStart, .lineEnd: break
        }
        return CGRect(x: x0, y: y0, width: max(10, x1-x0), height: max(10, y1-y0))
    }
    
    // MARK: - Draw (includes beautified connector)
    override func draw(_ page: PDFPage, to context: CGContext) {
        super.draw(page, to: context)
        
        // ✅ 美化连接线绘制
        // 我们遍历所有注解，如果是 Note Connector，我们手动画一条平滑曲线，
        // 因为我们在创建时已设置 shouldDisplay = false 隐藏了原生直线。
        let annotations = page.annotations
        for ann in annotations {
            if isNoteConnectorLine(ann) {
                // 仅当关联的文本框可见时才绘制
                guard let gid = ann.userName,
                      let ft = findCalloutText(groupID: gid, on: page),
                      ft.shouldDisplay else { continue }
                
                // 尝试获取关联 Note 的颜色
                var drawColor: NSColor = .systemGray
                if let note = page.annotations.first(where: { isNote($0) && $0.userName == gid }) {
                    drawColor = note.color
                }
                
                drawBeautifulConnector(annotation: ann, context: context, color: drawColor)
            }
        }
        
        // 选中图形的控制点绘制
        guard let sel = selectedAnnotation, sel.page == page else { return }
        context.saveGState()
        let subtype = getSubtypeString(sel)
        if subtype == "/Line" || subtype == "Line" {
            let handles = getHandleRects(for: sel)
            context.setStrokeColor(NSColor.systemBlue.cgColor)
            context.setLineWidth(1.0)
            context.setFillColor(NSColor.white.cgColor)
            for (_, rect) in handles { context.fillEllipse(in: rect); context.strokeEllipse(in: rect) }
        } else {
            context.setStrokeColor(NSColor.systemBlue.cgColor)
            context.setLineWidth(1.0)
            context.stroke(sel.bounds)
            let handles = getBoxHandleRects(for: sel.bounds)
            context.setFillColor(NSColor.white.cgColor)
            for (_, rect) in handles { context.fillEllipse(in: rect); context.strokeEllipse(in: rect) }
        }
        context.restoreGState()
    }
    
    // ✅ 美化版连接线：三段贝塞尔曲线 + 渐变效果 + 拐点光晕
    private func drawBeautifulConnector(annotation: PDFAnnotation, context: CGContext, color: NSColor) {
        context.saveGState()

        // 1) Page-space endpoints
        let start = CGPoint(x: annotation.bounds.minX + annotation.startPoint.x,
                            y: annotation.bounds.minY + annotation.startPoint.y)
        let end = CGPoint(x: annotation.bounds.minX + annotation.endPoint.x,
                          y: annotation.bounds.minY + annotation.endPoint.y)

        // 2) 计算拐点位置 (智能选择方向)
        let dx = end.x - start.x
        let dy = end.y - start.y
        let pivot: CGPoint
        let useBezier: Bool
        
        // 根据距离决定是否使用贝塞尔曲线
        let distance = sqrt(dx * dx + dy * dy)
        useBezier = distance > 30
        
        if abs(dx) >= abs(dy) {
            pivot = CGPoint(x: start.x, y: end.y)
        } else {
            pivot = CGPoint(x: end.x, y: start.y)
        }

        // 3) 绘制主线条
        let lineWidth = max(1.8, (annotation.border?.lineWidth ?? 1.5))
        let mainColor = color.withAlphaComponent(0.85)
        let shadowColor = color.withAlphaComponent(0.2)
        
        // 绘制阴影层
        context.setStrokeColor(shadowColor.cgColor)
        context.setLineWidth(lineWidth + 2)
        context.setLineCap(.round)
        context.setLineJoin(.round)
        
        let shadowPath = CGMutablePath()
        if useBezier {
            // 使用平滑的贝塞尔曲线
            shadowPath.move(to: start)
            
            // 计算控制点
            let ctrl1 = CGPoint(x: pivot.x, y: start.y + (pivot.y - start.y) * 0.5)
            let ctrl2 = CGPoint(x: pivot.x, y: pivot.y)
            
            shadowPath.addQuadCurve(to: pivot, control: ctrl1)
            shadowPath.addQuadCurve(to: end, control: ctrl2)
        } else {
            shadowPath.move(to: start)
            shadowPath.addLine(to: pivot)
            shadowPath.addLine(to: end)
        }
        context.addPath(shadowPath)
        context.strokePath()
        
        // 绘制主线条
        context.setStrokeColor(mainColor.cgColor)
        context.setLineWidth(lineWidth)
        
        let mainPath = CGMutablePath()
        if useBezier {
            mainPath.move(to: start)
            
            let ctrl1 = CGPoint(x: pivot.x, y: start.y + (pivot.y - start.y) * 0.5)
            let ctrl2 = CGPoint(x: pivot.x, y: pivot.y)
            
            mainPath.addQuadCurve(to: pivot, control: ctrl1)
            mainPath.addQuadCurve(to: end, control: ctrl2)
        } else {
            mainPath.move(to: start)
            mainPath.addLine(to: pivot)
            mainPath.addLine(to: end)
        }
        context.addPath(mainPath)
        context.strokePath()

        // 4) 拐点装饰：渐变光晕圆点
        let dotRadius: CGFloat = max(3.5, lineWidth * 1.5)
        
        // 外层光晕
        let glowRect = CGRect(x: pivot.x - dotRadius * 1.8, y: pivot.y - dotRadius * 1.8,
                              width: dotRadius * 3.6, height: dotRadius * 3.6)
        context.setFillColor(color.withAlphaComponent(0.15).cgColor)
        context.fillEllipse(in: glowRect)
        
        // 主圆点
        let dotRect = CGRect(x: pivot.x - dotRadius, y: pivot.y - dotRadius,
                             width: dotRadius * 2, height: dotRadius * 2)
        context.setFillColor(mainColor.cgColor)
        context.fillEllipse(in: dotRect)
        
        // 内层高光
        let highlightRadius = dotRadius * 0.5
        let highlightRect = CGRect(x: pivot.x - highlightRadius + 0.5,
                                   y: pivot.y - highlightRadius + 0.5,
                                   width: highlightRadius * 2 - 1,
                                   height: highlightRadius * 2 - 1)
        context.setFillColor(NSColor.white.withAlphaComponent(0.4).cgColor)
        context.fillEllipse(in: highlightRect)
        
        // 5) 起点和终点装饰（小圆点）
        let endDotRadius: CGFloat = max(2.5, lineWidth * 1.0)
        
        // 起点圆点
        let startDotRect = CGRect(x: start.x - endDotRadius, y: start.y - endDotRadius,
                                  width: endDotRadius * 2, height: endDotRadius * 2)
        context.setFillColor(mainColor.cgColor)
        context.fillEllipse(in: startDotRect)
        
        // 终点圆点
        let endDotRect = CGRect(x: end.x - endDotRadius, y: end.y - endDotRadius,
                                width: endDotRadius * 2, height: endDotRadius * 2)
        context.setFillColor(mainColor.cgColor)
        context.fillEllipse(in: endDotRect)

        context.restoreGState()
    }

    override func mouseDown(with event: NSEvent) {
        // 如果内联编辑器正在显示，检查点击是否在编辑器内部
        if let scroll = inlineEditorScrollView {
            let loc = event.locationInWindow
            // 将窗口坐标转换为编辑器坐标
            let pointInScroll = scroll.convert(loc, from: nil)
            if scroll.bounds.contains(pointInScroll) {
                // 点击在编辑器内部，不处理，让编辑器自己处理
                return
            }
            // 检查是否点击在TextView内部
            if let tv = scroll.documentView as? NSTextView {
                let pointInTV = tv.convert(loc, from: nil)
                if tv.bounds.contains(pointInTV) {
                    // 点击在TextView内部，不处理
                    return
                }
            }
            closeInlineEditor(commit: true)
        }
        
        let point = self.convert(event.locationInWindow, from: nil)
        guard let page = self.page(for: point, nearest: true) else { super.mouseDown(with: event); return }
        let pagePoint = self.convert(point, to: page)
        
        if shapeTool != .none {
            clearSelection()
            selectedAnnotation = nil
            shapeDraftPage = page
            shapeStartPagePoint = pagePoint
            activeShapeTool = shapeTool
            let ann: PDFAnnotation
            switch activeShapeTool {
            case .line, .arrow:
                ann = PDFAnnotation(bounds: CGRect(x: pagePoint.x, y: pagePoint.y, width: 2, height: 2), forType: .line, withProperties: nil)
                applyStrokeStyle(ann)
                if activeShapeTool == .arrow { ann.endLineStyle = .closedArrow }
                updateLineAnnotation(ann, start: pagePoint, end: pagePoint)
            case .rect:
                let b = CGRect(x: pagePoint.x, y: pagePoint.y, width: 1, height: 1)
                ann = PDFAnnotation(bounds: b, forType: .square, withProperties: nil)
                applyStrokeStyle(ann)
            case .ellipse:
                let b = CGRect(x: pagePoint.x, y: pagePoint.y, width: 1, height: 1)
                ann = PDFAnnotation(bounds: b, forType: .circle, withProperties: nil)
                applyStrokeStyle(ann)
            case .none: ann = PDFAnnotation(bounds: .zero, forType: .square, withProperties: nil)
            }
            page.addAnnotation(ann); shapeDraftAnnotation = ann; forceRefresh(); return
        }

        if let sel = selectedAnnotation, sel.page == page {
            // If a FreeText is already selected, double-click on its text area should start inline editing.
            // (Otherwise the early selectedAnnotation move/resize logic consumes the event and blocks editing.)
            if event.clickCount >= 2, isFreeText(sel), (sel.shouldDisplay || textOverlays[ObjectIdentifier(sel)] != nil), sel.bounds.contains(pagePoint) {
                // Avoid entering edit mode when double-clicking on resize handles/border.
                if hitResizeHandle(for: sel, at: pagePoint) == nil {
                    clearSelection()
                    selectedAnnotation = sel
                    draggedAnnotation = nil
                    beginInlineEdit(for: sel, clickPointInPage: pagePoint)
                    forceRefresh()
                    return
                }
            }
            if let handle = hitResizeHandle(for: sel, at: pagePoint) {
                draggedAnnotation = sel; dragStartLocation = pagePoint; originalAnnotationBounds = sel.bounds
                let subtype = getSubtypeString(sel)
                if subtype == "/Line" || subtype == "Line" {
                    originalLineStartPagePoint = CGPoint(x: sel.bounds.minX + sel.startPoint.x, y: sel.bounds.minY + sel.startPoint.y)
                    originalLineEndPagePoint = CGPoint(x: sel.bounds.minX + sel.endPoint.x, y: sel.bounds.minY + sel.endPoint.y)
                }
                dragMode = .resize(handle); return
            }
            if isShape(sel), sel.bounds.contains(pagePoint) {
                if hitShapeBorder(sel, at: pagePoint) {
                    draggedAnnotation = sel; dragStartLocation = pagePoint; originalAnnotationBounds = sel.bounds; dragMode = .move; return
                } else {
                    selectedAnnotation = nil; clearSelection(); forceRefresh()
                }
            }
            if sel.bounds.contains(pagePoint) && !isShape(sel) {
                draggedAnnotation = sel; dragStartLocation = pagePoint; originalAnnotationBounds = sel.bounds; dragMode = .move; return
            }
        }
        
        if let n = findAnnotations(on: page, at: pagePoint).reversed().first(where: { isNote($0) }) {
            if event.clickCount < 2 {
                selectedAnnotation = nil; draggedAnnotation = n; dragStartLocation = pagePoint; originalAnnotationBounds = n.bounds; dragMode = .move; clearSelection(); forceRefresh(); return
            } else {
                handleNoteDoubleClick(n); return
            }
        }
        
        if let ft = findAnnotations(on: page, at: pagePoint).reversed().first(where: { isFreeText($0) }) {
            if event.clickCount >= 2 {
                // Double click FreeText: edit directly in place (callout textbox and normal FreeText).
                // If the user double-clicks near border/handles, do not enter edit mode.
                if hitResizeHandle(for: ft, at: pagePoint) == nil {
                    clearSelection()
                    selectedAnnotation = ft
                    draggedAnnotation = nil
                    beginInlineEdit(for: ft, clickPointInPage: pagePoint)
                    forceRefresh()
                    return
                } else {
                    // Border/handle double click: just select.
                    selectedAnnotation = ft
                    draggedAnnotation = nil
                    clearSelection()
                    forceRefresh()
                    return
                }
            } else {
                selectedAnnotation = ft
                draggedAnnotation = ft
                dragStartLocation = pagePoint
                originalAnnotationBounds = ft.bounds
                dragMode = hitResizeHandle(for: ft, at: pagePoint).map { .resize($0) } ?? .move
                clearSelection()
                forceRefresh()
                return
            }
        }

        if let shape = findAnnotations(on: page, at: pagePoint).reversed().first(where: { isShape($0) }) {
            if hitShapeBorder(shape, at: pagePoint) {
                selectedAnnotation = shape; draggedAnnotation = shape; dragStartLocation = pagePoint; originalAnnotationBounds = shape.bounds; dragMode = .move; clearSelection(); forceRefresh(); return
            }
        }
        
        if selectedAnnotation != nil { selectedAnnotation = nil; forceRefresh() }
        super.mouseDown(with: event)
    }
    
    override func mouseDragged(with event: NSEvent) {
        if inlineEditorScrollView != nil { return }
        if let ann = shapeDraftAnnotation, let p = shapeDraftPage {
            let pp = self.convert(self.convert(event.locationInWindow, from: nil), to: p)
            switch activeShapeTool {
            case .line, .arrow: updateLineAnnotation(ann, start: shapeStartPagePoint, end: pp)
            case .rect, .ellipse: ann.bounds = ensureMinSize(rectFrom(shapeStartPagePoint, pp), min: 8)
            case .none: break
            }
            setNeedsDisplay(bounds); return
        }
        
        if let a = draggedAnnotation, let p = a.page {
            let pp = self.convert(self.convert(event.locationInWindow, from: nil), to: p)
            let dx = pp.x - dragStartLocation.x; let dy = pp.y - dragStartLocation.y
            switch dragMode {
            case .move:
                a.bounds.origin = CGPoint(x: originalAnnotationBounds.minX + dx, y: originalAnnotationBounds.minY + dy)
                if a is ReadablePDFTextAnnotation {
                    let pageBounds = p.bounds(for: displayBox).insetBy(dx: 4, dy: 4)
                    a.bounds.origin.x = max(pageBounds.minX, min(a.bounds.minX, pageBounds.maxX - a.bounds.width))
                    a.bounds.origin.y = max(pageBounds.minY, min(a.bounds.minY, pageBounds.maxY - a.bounds.height))
                }
            case .resize(let h):
                let subtype = getSubtypeString(a)
                if (subtype == "/Line" || subtype == "Line"), (h == .lineStart || h == .lineEnd) {
                    let newPoint = pp
                    let start = (h == .lineStart) ? newPoint : originalLineStartPagePoint
                    let end = (h == .lineEnd) ? newPoint : originalLineEndPagePoint
                    updateLineAnnotation(a, start: start, end: end)
                } else {
                    a.bounds = resizedBounds(from: originalAnnotationBounds, handle: h, dx: dx, dy: dy)
                }
            }
            if let gid = smartGroupID(of: a), (isNote(a) || isNoteCalloutText(a)) {
                refreshNoteCalloutConnector(groupID: gid, on: p)

                // ✅ 如果该批注正在显示屏幕 overlay 文本框，则移动时同步更新 overlay 与连线
                if calloutOverlays[gid] != nil {
                    updateCalloutOverlayPositions()
                    updateConnectorLayer(gid)
                }
            }
            layoutDocumentView(); setNeedsDisplay(bounds); return
        }
        super.mouseDragged(with: event)
    }
    override func menu(for event: NSEvent) -> NSMenu? {
        let point = self.convert(event.locationInWindow, from: nil)
        guard let page = self.page(for: point, nearest: true) else { return nil }
        let pagePoint = self.convert(point, to: page)
        lastContextPagePoint = pagePoint; lastContextPage = page
        if currentSelection != nil { let m = NSMenu(title: "Selection"); m.addItem(withTitle: L(.copy), action: #selector(copy(_:)), keyEquivalent: "c"); return m }
        let hits = findAnnotations(on: page, at: pagePoint)
        let menu = NSMenu(title: "Actions")

        if let ft = hits.reversed().first(where: { isFreeText($0) }) {
            let edit = NSMenuItem(title: L(.editText), action: #selector(editFreeText(_:)), keyEquivalent: ""); edit.target = self; edit.representedObject = ft; menu.addItem(edit)
            let colorSub = NSMenu(title: L(.changeColor))
            for (name, c) in menuColors {
                let item = NSMenuItem(title: name, action: #selector(changeFreeTextColor(_:)), keyEquivalent: ""); item.target = self; item.representedObject = FreeTextColorPayload(annotation: ft, baseColor: c); item.image = colorDotImage(c); colorSub.addItem(item)
            }
            let colorMenuItem = NSMenuItem(title: L(.changeColor), action: nil, keyEquivalent: ""); colorMenuItem.submenu = colorSub; menu.addItem(colorMenuItem)
            let sm = NSMenu(); let fontSizes: [(String, CGFloat)] = [(L(.fontExtraSmall), 10), (L(.fontSmall), 12), (L(.fontSlightlySmall), 14), (L(.fontMedium), 16), (L(.fontStandard), 18), (L(.fontSlightlyLarge), 20), (L(.fontLarge), 24), (L(.fontExtraLarge), 28), (L(.fontHuge), 32)]
            for (title, size) in fontSizes { let i = NSMenuItem(title: title, action: #selector(setFontSize(_:)), keyEquivalent: ""); i.target = self; i.representedObject = (ft, size); sm.addItem(i) }
            let fm = NSMenuItem(title: L(.fontSize), action: nil, keyEquivalent: ""); fm.submenu = sm; menu.addItem(fm)
            let d = NSMenuItem(title: L(.deleteText), action: #selector(deleteAnn(_:)), keyEquivalent: ""); d.target = self; d.representedObject = ft; menu.addItem(d); return menu
        }

        if let shape = hits.reversed().first(where: { isShape($0) }) {
            let hasNote = (findLinkedNote(for: shape) != nil)
            if hasNote, let linked = findLinkedNote(for: shape) {
                let e = NSMenuItem(title: L(.editNote), action: #selector(editNote(_:)), keyEquivalent: ""); e.target = self; e.representedObject = linked; menu.addItem(e)
                let d = NSMenuItem(title: L(.deleteShape), action: #selector(deleteAnn(_:)), keyEquivalent: ""); d.target = self; d.representedObject = shape; menu.addItem(d)
                let dn = NSMenuItem(title: L(.deleteNote), action: #selector(deleteLinkedNote(_:)), keyEquivalent: ""); dn.target = self; dn.representedObject = shape; menu.addItem(dn)
            } else {
                let a = NSMenuItem(title: L(.addNoteToShape), action: #selector(addNoteToShape(_:)), keyEquivalent: ""); a.target = self; a.representedObject = shape; menu.addItem(a)
                let d = NSMenuItem(title: L(.deleteShape), action: #selector(deleteAnn(_:)), keyEquivalent: ""); d.target = self; d.representedObject = shape; menu.addItem(d)
            }
            let colorSub = NSMenu(title: L(.changeColor))
            for (name, c) in menuColors {
                let item = NSMenuItem(title: name, action: #selector(changeShapeColor(_:)), keyEquivalent: ""); item.target = self; item.representedObject = ShapeColorPayload(annotation: shape, baseColor: c); item.image = colorDotImage(c); colorSub.addItem(item)
            }
            let colorMenuItem = NSMenuItem(title: L(.changeColor), action: nil, keyEquivalent: ""); colorMenuItem.submenu = colorSub; menu.addItem(colorMenuItem)
            let widthSub = NSMenu(title: L(.lineWidth)); widthSub.addItem(lineWidthSliderMenuItem(for: shape)); let widthMenuItem = NSMenuItem(title: L(.lineWidth), action: nil, keyEquivalent: ""); widthMenuItem.submenu = widthSub; menu.addItem(widthMenuItem); return menu
        }

        if let n = hits.reversed().first(where: { isNote($0) }) {
            let e = NSMenuItem(title: L(.editNote), action: #selector(editNote(_:)), keyEquivalent: ""); e.target = self; e.representedObject = n; menu.addItem(e)
            let colorSub = NSMenu(title: L(.changeColor))
            for (name, c) in menuColors {
                let item = NSMenuItem(title: name, action: #selector(changeNoteColor(_:)), keyEquivalent: ""); item.target = self; item.representedObject = NoteColorPayload(annotation: n, baseColor: c); item.image = colorDotImage(c); colorSub.addItem(item)
            }
            let colorMenuItem = NSMenuItem(title: L(.changeColor), action: nil, keyEquivalent: ""); colorMenuItem.submenu = colorSub; menu.addItem(colorMenuItem)
            let d = NSMenuItem(title: L(.deleteNote), action: #selector(deleteAnn(_:)), keyEquivalent: ""); d.target = self; d.representedObject = n; menu.addItem(d); return menu
        }

        if let mark = hits.reversed().first(where: { isUnderline($0) || isHighlight($0) }) {
            let isHL = isHighlight(mark)
            let hasNote = (findLinkedNote(for: mark) != nil)
            let colorSub = NSMenu(title: L(.changeColor))
            for (name, c) in menuColors {
                let item = NSMenuItem(title: name, action: #selector(changeMarkColor(_:)), keyEquivalent: ""); item.target = self; item.representedObject = MarkColorPayload(annotation: mark, baseColor: c, isHighlight: isHL); item.image = colorDotImage(c); colorSub.addItem(item)
            }
            let colorMenuItem = NSMenuItem(title: L(.changeColor), action: nil, keyEquivalent: ""); colorMenuItem.submenu = colorSub
            if hasNote, let linked = findLinkedNote(for: mark) {
                let e = NSMenuItem(title: L(.editNote), action: #selector(editNote(_:)), keyEquivalent: ""); e.target = self; e.representedObject = linked; menu.addItem(e)
                let delTitle = isHL ? L(.deleteHighlight) : L(.deleteUnderline); let d = NSMenuItem(title: delTitle, action: #selector(deleteAnn(_:)), keyEquivalent: ""); d.target = self; d.representedObject = mark; menu.addItem(d)
                let dn = NSMenuItem(title: L(.deleteNote), action: #selector(deleteLinkedNote(_:)), keyEquivalent: ""); dn.target = self; dn.representedObject = mark; menu.addItem(dn); menu.addItem(colorMenuItem); return menu
            } else {
                let a = NSMenuItem(title: L(.addNote), action: #selector(addNoteToMark(_:)), keyEquivalent: ""); a.target = self; a.representedObject = mark; menu.addItem(a)
                let delTitle = isHL ? L(.deleteHighlight) : L(.deleteUnderline); let d = NSMenuItem(title: delTitle, action: #selector(deleteAnn(_:)), keyEquivalent: ""); d.target = self; d.representedObject = mark; menu.addItem(d); menu.addItem(colorMenuItem); return menu
            }
        }

        let a1 = NSMenuItem(title: L(.addNote), action: #selector(addStandaloneNote), keyEquivalent: ""); a1.target = self; menu.addItem(a1)
        let a2 = NSMenuItem(title: L(.addText), action: #selector(addFreeText), keyEquivalent: ""); a2.target = self; menu.addItem(a2)
        let shapeSub = NSMenu(title: L(.addShape)); let items: [(String, ShapeTool)] = [(L(.shapeLine), .line), (L(.shapeArrow), .arrow), (L(.shapeRect), .rect), (L(.shapeEllipse), .ellipse)]
        for (title, tool) in items { let it = NSMenuItem(title: title, action: #selector(armShapeTool(_:)), keyEquivalent: ""); it.target = self; it.representedObject = tool.rawValue; it.image = shapeMenuIcon(for: tool); shapeSub.addItem(it) }
        let shapeRoot = NSMenuItem(title: L(.addShape), action: nil, keyEquivalent: ""); shapeRoot.submenu = shapeSub; menu.addItem(shapeRoot)
        
        // 添加分隔线和显示/隐藏所有批注选项
        menu.addItem(NSMenuItem.separator())
        let toggleTitle = hasVisibleCalloutOverlays() ? L(.hideAllAnnotations) : L(.showAllAnnotations)
        let toggleItem = NSMenuItem(title: toggleTitle, action: #selector(toggleAllAnnotations), keyEquivalent: ""); toggleItem.target = self; menu.addItem(toggleItem)
        
        return menu
    }
    
    @objc func toggleAllAnnotations() {
        toggleAllCalloutOverlays()
    }
    
    func forceRefresh() {
        DispatchQueue.main.async {
            self.layoutDocumentView()
            self.updateCalloutOverlayPositions()
            self.updateTextOverlays()
            self.setNeedsDisplay(self.bounds)
        }
    }
    
    // MARK: - 批注闪烁高亮效果
    func flashAnnotation(_ annotation: PDFAnnotation) {
        guard let page = annotation.page else { return }
        let bounds = annotation.bounds
        let viewRect = self.convert(bounds, from: page)
        
        // 创建高亮覆盖层
        let flashView = NSView(frame: viewRect)
        flashView.wantsLayer = true
        flashView.layer?.backgroundColor = NSColor.systemBlue.withAlphaComponent(0.3).cgColor
        flashView.layer?.cornerRadius = 4
        self.addSubview(flashView)
        
        // 动画闪烁
        NSAnimationContext.runAnimationGroup({ context in
            context.duration = 0.3
            flashView.animator().alphaValue = 0.8
        }, completionHandler: {
            NSAnimationContext.runAnimationGroup({ context in
                context.duration = 0.3
                flashView.animator().alphaValue = 0
            }, completionHandler: {
                flashView.removeFromSuperview()
            })
        })
    }
    
    @objc func addFreeText() {
        guard let p = lastContextPage else { return }
        let a = addDroppedText("", on: p, at: lastContextPagePoint)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { [weak self] in
            guard let self else { return }
            self.clearSelection()
            self.selectedAnnotation = a
            self.draggedAnnotation = nil
            self.beginInlineEdit(for: a)
            self.forceRefresh()
        }
    }

    @objc func armShapeTool(_ s: NSMenuItem) {
        guard let raw = s.representedObject as? String, let tool = ShapeTool(rawValue: raw) else { return }
        shapeTool = tool; window?.makeFirstResponder(self); window?.acceptsMouseMovedEvents = true; NSCursor.crosshair.set(); activeShapeTool = .none; shapeDraftAnnotation = nil; shapeDraftPage = nil; clearSelection(); selectedAnnotation = nil; forceRefresh()
    }
    @objc func addStandaloneNote() {
        guard let p = lastContextPage else { return }
        let n = PDFAnnotation(bounds: CGRect(x: lastContextPagePoint.x - noteIconHalf, y: lastContextPagePoint.y - noteIconHalf, width: noteIconSize, height: noteIconSize), forType: .text, withProperties: nil)
        n.iconType = .comment
        n.color = .systemYellow
        n.contents = ""
        p.addAnnotation(n)
        forceRefresh()
        NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
        coordinator?.showStandaloneNoteInput(for: n, in: self)
    }
    @objc func editNote(_ s: NSMenuItem) { guard let n = s.representedObject as? PDFAnnotation else { return }; coordinator?.showStandaloneNoteInput(for: n, in: self) }
    @objc func editFreeText(_ s: NSMenuItem) {
        guard let ft = s.representedObject as? PDFAnnotation else { return }
        clearSelection()
        selectedAnnotation = ft
        draggedAnnotation = nil
        beginInlineEdit(for: ft)
        forceRefresh()
    }
    @objc func deleteAnn(_ s: NSMenuItem) {
        guard let a = s.representedObject as? PDFAnnotation else { return }
        if let gid = smartGroupID(of: a), let doc = self.document {
            // 先清理overlay和连线layer
            removeConnectorLayer(gid)
            removeOverlay(groupID: gid)
            
            let deleteHighlights = isHighlight(a); let deleteUnderlines = isUnderline(a)
            if deleteHighlights || deleteUnderlines {
                for i in 0..<doc.pageCount {
                    guard let page = doc.page(at: i) else { continue }
                    let anns = page.annotations
                    for ann in anns {
                        guard ann.userName == gid else { continue }
                        if deleteHighlights, isHighlight(ann) { page.removeAnnotation(ann) }
                        else if deleteUnderlines, isUnderline(ann) { page.removeAnnotation(ann) }
                        else if isNote(ann) || isNoteCalloutText(ann) || isNoteConnectorLine(ann) { page.removeAnnotation(ann) }
                    }
                }
                clearSelection(); selectedAnnotation = nil; forceRefresh()
                NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
                return
            }
            
            if isShape(a) {
                for i in 0..<doc.pageCount {
                    guard let page = doc.page(at: i) else { continue }
                    for ann in page.annotations where ann.userName == gid {
                        if isShape(ann) || isNote(ann) || isNoteCalloutText(ann) || isNoteConnectorLine(ann) { page.removeAnnotation(ann) }
                    }
                }
                clearSelection(); selectedAnnotation = nil; forceRefresh()
                NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
                return
            }
            
            if isNote(a), let page = a.page {
                if let ft = findCalloutText(groupID: gid, on: page) { page.removeAnnotation(ft) }
                if let ln = findCalloutConnector(groupID: gid, on: page) { page.removeAnnotation(ln) }
                page.removeAnnotation(a)
                if a == selectedAnnotation { selectedAnnotation = nil }
                clearSelection(); forceRefresh()
                NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
                return
            }
        }
        guard let p = a.page else { return }
        p.removeAnnotation(a)
        if a == selectedAnnotation { selectedAnnotation = nil }
        clearSelection(); forceRefresh()
        NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
    }
    @objc func addNoteToHl(_ s: NSMenuItem) { guard let h = s.representedObject as? PDFAnnotation else { return }; coordinator?.showNoteInput(for: h, in: self) }
    @objc func addNoteToMark(_ s: NSMenuItem) { guard let mark = s.representedObject as? PDFAnnotation else { return }; _ = ensureGroupID(for: mark); coordinator?.showNoteInput(for: mark, in: self) }
    @objc func deleteLinkedNote(_ s: NSMenuItem) {
        guard let anchor = s.representedObject as? PDFAnnotation else { return }
        if let doc = self.document, let gid = smartGroupID(of: anchor) {
            // 先清理overlay和连线layer
            removeConnectorLayer(gid)
            removeOverlay(groupID: gid)
            
            for i in 0..<doc.pageCount {
                guard let p = doc.page(at: i) else { continue }
                for ann in p.annotations where ann.userName == gid {
                    if isNote(ann) || isNoteCalloutText(ann) || isNoteConnectorLine(ann) {
                        p.removeAnnotation(ann)
                    }
                }
            }
            clearSelection(); forceRefresh()
            NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
            return
        }
        if let n = findLinkedNote(for: anchor), let p = n.page {
            p.removeAnnotation(n); clearSelection(); forceRefresh()
            NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
        }
    }

    @objc func changeMarkColor(_ s: NSMenuItem) {
        guard let payload = s.representedObject as? MarkColorPayload else { return }; let mark = payload.annotation; let isHL = payload.isHighlight; let newColor = isHL ? payload.baseColor.withAlphaComponent(0.5) : payload.baseColor
        if let doc = self.document, let gid = smartGroupID(of: mark) {
            for i in 0..<doc.pageCount {
                guard let p = doc.page(at: i) else { continue }
                for ann in p.annotations where ann.userName == gid {
                    if isHL { if isHighlight(ann) || isNote(ann) { ann.color = newColor } } else { if isUnderline(ann) || isNote(ann) { ann.color = newColor } }
                }
            }
        } else { mark.color = newColor; if let n = findLinkedNote(for: mark) { n.color = newColor } }
        forceRefresh()
        // [新增] 发送通知刷新侧边栏
        NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
    }

    @objc func changeNoteColor(_ s: NSMenuItem) {
        guard let payload = s.representedObject as? NoteColorPayload else { return }; let note = payload.annotation; let base = payload.baseColor
        if let doc = self.document, let gid = smartGroupID(of: note) {
            var groupHasHighlight = false; var groupHasUnderline = false
            for i in 0..<doc.pageCount { guard let p = doc.page(at: i) else { continue }; for ann in p.annotations where ann.userName == gid { if isHighlight(ann) { groupHasHighlight = true }; if isUnderline(ann) { groupHasUnderline = true } } }
            let highlightColor = base.withAlphaComponent(0.5); let underlineColor = base
            for i in 0..<doc.pageCount {
                guard let p = doc.page(at: i) else { continue }
                for ann in p.annotations where ann.userName == gid {
                    if isNote(ann) { ann.color = groupHasHighlight ? highlightColor : (groupHasUnderline ? underlineColor : base) }
                    else if isHighlight(ann) { ann.color = highlightColor }
                    else if isUnderline(ann) { ann.color = underlineColor }
                    else if isNoteConnectorLine(ann) {
                        // Connector line follows note color but remains hidden for custom draw
                        ann.color = groupHasHighlight ? highlightColor : (groupHasUnderline ? underlineColor : base)
                    }
                }
            }
            forceRefresh()
            // [新增] 发送通知刷新侧边栏
            NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil); return
        }
        note.color = base
        if let gid = smartGroupID(of: note), let page = note.page {
            if let ln = findCalloutConnector(groupID: gid, on: page) { ln.color = base }
            refreshNoteCalloutConnector(groupID: gid, on: page)
        }
        forceRefresh()
        NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
    }
    @objc func changeFreeTextColor(_ s: NSMenuItem) { guard let payload = s.representedObject as? FreeTextColorPayload else { return }; let ft = payload.annotation; let base = payload.baseColor; ft.fontColor = base; ft.color = .clear; if ft.border == nil { ft.border = nil }; forceRefresh()
        // [新增] 发送通知刷新侧边栏
        NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)}
    @objc func setFontSize(_ s: NSMenuItem) { guard let (a, size) = s.representedObject as? (PDFAnnotation, CGFloat) else { return }; a.font = .systemFont(ofSize: size); a.bounds.size.height = size * 1.5; forceRefresh() }
    func addNoteAnnotation(page: PDFPage, highlightBounds: CGRect, color: NSColor, content: String, groupID: String?) -> PDFAnnotation {
        let n = PDFAnnotation(bounds: CGRect(x: highlightBounds.maxX - noteIconCornerInset, y: highlightBounds.maxY - noteIconCornerInset, width: noteIconSize, height: noteIconSize), forType: .text, withProperties: nil)
        n.color = color; n.contents = content; n.iconType = .comment; if let gid = groupID { n.userName = gid }; page.addAnnotation(n); forceRefresh()
        NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
        return n
    }
    
    // MARK: - Callout Overlay (renders outside page)
    private final class CalloutOverlayView: NSView, NSTextViewDelegate {
        let groupID: String
        weak var ownerPDFView: CustomPDFView?
        var savedOffsetX: CGFloat?, savedOffsetY: CGFloat?, savedWidth: CGFloat?, savedHeight: CGFloat?
        var savedPageOffsetX: CGFloat?, savedPageOffsetY: CGFloat?, savedPageWidth: CGFloat?, savedPageHeight: CGFloat?
        var offsetFromAnchor = CGPoint(x: 24, y: 24)
        var manualSizeOverride = false
        private var rawText = ""
        private var editing = false
        private var tint: NSColor = .systemPurple
        private let scroll = NSScrollView()
        private let textView = CardTextView()
        private let title = NSTextField(labelWithString: T("批注", "Note"))
        private let hint = NSTextField(labelWithString: T("拖动标题移动 · 双击正文编辑", "Drag title to move · Double-click text to edit"))
        private let editButton = NSButton()
        private let closeButton = NSButton()
        private var dragStart = CGPoint.zero
        private var startFrame = CGRect.zero
        private var resizing = false
        private var moving = false
        private var resizeRect: CGRect { CGRect(x: bounds.maxX - 18, y: 0, width: 18, height: 18) }

        private final class CardTextView: NSTextView {
            weak var card: CalloutOverlayView?
            override func mouseDown(with event: NSEvent) {
                if event.clickCount >= 2 && !isEditable { card?.beginEditing() }
                super.mouseDown(with: event)
            }
        }

        init(groupID: String, owner: CustomPDFView) {
            self.groupID = groupID
            ownerPDFView = owner
            super.init(frame: NSRect(x: 0, y: 0, width: 320, height: 180))
            identifier = NSUserInterfaceItemIdentifier("spdf.note-card." + groupID)
            setAccessibilityLabel(T("批注卡片", "Note card"))
            wantsLayer = true
            layer?.cornerRadius = 12
            layer?.borderWidth = 0.75
            layer?.shadowOpacity = 0.14
            layer?.shadowRadius = 12
            layer?.shadowOffset = CGSize(width: 0, height: -3)
            layer?.masksToBounds = false
            layer?.shouldRasterize = false
            title.font = .systemFont(ofSize: 13, weight: .semibold)
            hint.font = .systemFont(ofSize: 10)
            hint.textColor = .secondaryLabelColor
            hint.lineBreakMode = .byTruncatingTail
            addSubview(title); addSubview(hint)
            configureButton(editButton, symbol: "pencil", label: T("编辑批注", "Edit note"), action: #selector(toggleEditing))
            configureButton(closeButton, symbol: "xmark", label: T("收起批注", "Collapse note"), action: #selector(collapse))
            scroll.borderType = .noBorder
            scroll.hasVerticalScroller = true
            scroll.hasHorizontalScroller = false
            scroll.autohidesScrollers = true
            scroll.scrollerStyle = .overlay
            scroll.drawsBackground = false
            textView.card = self
            textView.delegate = self
            textView.isEditable = false
            textView.isSelectable = true
            textView.isRichText = false
            textView.importsGraphics = false
            textView.allowsUndo = true
            textView.drawsBackground = false
            textView.textContainerInset = .zero
            textView.isVerticallyResizable = true
            textView.isHorizontallyResizable = false
            textView.autoresizingMask = [.width]
            textView.textContainer?.lineFragmentPadding = 0
            scroll.documentView = textView
            addSubview(scroll)
            updateColors()
        }
        required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
        private func configureButton(_ button: NSButton, symbol: String, label: String, action: Selector) {
            button.image = NSImage(systemSymbolName: symbol, accessibilityDescription: label)
            button.imagePosition = .imageOnly
            button.bezelStyle = .inline
            button.isBordered = false
            button.toolTip = label
            button.setAccessibilityLabel(label)
            button.target = self; button.action = action
            addSubview(button)
        }
        private func updateColors() {
            effectiveAppearance.performAsCurrentDrawingAppearance {
                layer?.backgroundColor = NSColor.controlBackgroundColor.cgColor
                layer?.borderColor = tint.withAlphaComponent(0.32).cgColor
                layer?.shadowColor = NSColor.black.cgColor
                title.textColor = .labelColor
            }
            needsDisplay = true
        }
        override func viewDidChangeEffectiveAppearance() { super.viewDidChangeEffectiveAppearance(); updateColors() }
        override func viewDidMoveToWindow() { super.viewDidMoveToWindow(); updateBackingScale() }
        override func viewDidChangeBackingProperties() { super.viewDidChangeBackingProperties(); updateBackingScale() }
        private func updateBackingScale() {
            layer?.contentsScale = window?.backingScaleFactor ?? 2
            layer?.shouldRasterize = false
            textView.needsDisplay = true
        }
        func setBorderColor(_ color: NSColor) {
            tint = color.withAlphaComponent(1)
            updateColors()
        }
        override func layout() {
            super.layout()
            title.frame = NSRect(x: 16, y: bounds.height - 32, width: max(50, bounds.width - 100), height: 18)
            closeButton.frame = NSRect(x: bounds.width - 38, y: bounds.height - 35, width: 26, height: 26)
            editButton.frame = NSRect(x: bounds.width - 68, y: bounds.height - 35, width: 26, height: 26)
            hint.frame = NSRect(x: 14, y: 8, width: max(80, bounds.width - 42), height: 14)
            scroll.frame = NSRect(x: 14, y: 30, width: max(20, bounds.width - 28), height: max(30, bounds.height - 76))
            layoutText()
        }
        private func layoutText() {
            let width = max(20, scroll.contentSize.width)
            textView.setFrameSize(NSSize(width: width, height: max(30, scroll.contentSize.height)))
            textView.textContainer?.widthTracksTextView = true
            textView.textContainer?.containerSize = NSSize(width: width, height: .greatestFiniteMagnitude)
            if let lm = textView.layoutManager, let tc = textView.textContainer {
                lm.ensureLayout(for: tc)
                textView.setFrameSize(NSSize(width: width, height: max(scroll.contentSize.height, ceil(lm.usedRect(for: tc).height) + 4)))
            }
        }
        func idealHeight(width: CGFloat) -> CGFloat {
            let size = textView.attributedString().boundingRect(with: NSSize(width: max(30, width - 28), height: .greatestFiniteMagnitude),
                options: [.usesLineFragmentOrigin, .usesFontLeading]).size
            return min(420, max(150, ceil(size.height) + 84))
        }
        override func draw(_ dirtyRect: NSRect) {
            super.draw(dirtyRect)
            NSColor.separatorColor.withAlphaComponent(0.5).setStroke()
            let separator = NSBezierPath()
            separator.move(to: NSPoint(x: 14, y: bounds.height - 42))
            separator.line(to: NSPoint(x: bounds.width - 14, y: bounds.height - 42))
            separator.lineWidth = 0.5; separator.stroke()
            let grip = NSBezierPath()
            for offset in [CGFloat(5), 9] {
                grip.move(to: CGPoint(x: bounds.width - offset - 5, y: 5))
                grip.line(to: CGPoint(x: bounds.width - 5, y: offset + 5))
            }
            grip.lineWidth = 1; grip.stroke()
        }
        func setText(_ text: String, font: NSFont?) {
            guard !editing else { return }
            rawText = text
            textView.textStorage?.setAttributedString(renderMarkdown(text.isEmpty ? T("暂无内容，点击编辑添加批注。", "No content yet. Select Edit to add a note.") : text,
                font: .systemFont(ofSize: 14)))
            layoutText()
        }
        func currentText() -> String { rawText }
        func getTextView() -> NSTextView { textView }
        @objc private func toggleEditing() { editing ? finishEditing() : beginEditing() }
        fileprivate func beginEditing() {
            guard !editing else { return }
            editing = true
            textView.isEditable = true
            let paragraph = NSMutableParagraphStyle(); paragraph.lineSpacing = 4
            textView.textStorage?.setAttributedString(NSAttributedString(string: rawText, attributes: [
                .font: NSFont.systemFont(ofSize: 14), .foregroundColor: NSColor.labelColor, .paragraphStyle: paragraph]))
            editButton.image = NSImage(systemSymbolName: "checkmark", accessibilityDescription: T("完成编辑", "Finish editing"))
            editButton.setAccessibilityLabel(T("完成编辑", "Finish editing"))
            editButton.toolTip = T("完成编辑", "Finish editing")
            hint.stringValue = T("编辑中 · 点击 ✓ 完成", "Editing · Select ✓ to finish")
            layoutText()
            window?.makeFirstResponder(textView)
            ownerPDFView?.installOverlayEditDismissMonitor(excluding: self)
        }
        func finishEditing() {
            guard editing else { return }
            rawText = textView.string
            editing = false; textView.isEditable = false
            ownerPDFView?.syncCalloutText(groupID: groupID, text: rawText)
            setText(rawText, font: nil)
            editButton.image = NSImage(systemSymbolName: "pencil", accessibilityDescription: T("编辑批注", "Edit note"))
            editButton.setAccessibilityLabel(T("编辑批注", "Edit note"))
            editButton.toolTip = T("编辑批注", "Edit note")
            hint.stringValue = T("拖动标题移动 · 双击正文编辑", "Drag title to move · Double-click text to edit")
            if window?.firstResponder === textView { window?.makeFirstResponder(ownerPDFView) }
            saveGeometryToAnnotation()
            NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
        }
        func textDidEndEditing(_ notification: Notification) { finishEditing() }
        func textDidChange(_ notification: Notification) {
            guard editing else { return }
            rawText = textView.string
            ownerPDFView?.syncCalloutText(groupID: groupID, text: rawText)
            layoutText()
            NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
        }
        @objc private func collapse() {
            finishEditing()
            ownerPDFView?.hideOverlayForCallout(groupID: groupID)
            ownerPDFView?.forceRefresh()
            NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
        }
        override func hitTest(_ point: NSPoint) -> NSView? {
            guard !isHidden else { return nil }
            let local = convert(point, from: superview)
            guard bounds.contains(local) else { return nil }
            if resizeRect.contains(local) { return self }
            let hit = super.hitTest(point)
            if local.y >= bounds.height - 42,
               hit !== editButton, hit !== closeButton,
               hit?.isDescendant(of: editButton) != true, hit?.isDescendant(of: closeButton) != true { return self }
            return hit
        }
        override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }
        override func mouseDown(with event: NSEvent) {
            let local = convert(event.locationInWindow, from: nil)
            resizing = resizeRect.contains(local)
            moving = !resizing && local.y >= bounds.height - 42
            dragStart = superview?.convert(event.locationInWindow, from: nil) ?? .zero
            startFrame = frame
        }
        override func mouseDragged(with event: NSEvent) {
            let point = superview?.convert(event.locationInWindow, from: nil) ?? .zero
            let dx = point.x - dragStart.x, dy = point.y - dragStart.y
            if moving { frame.origin = CGPoint(x: startFrame.minX + dx, y: startFrame.minY + dy) }
            if resizing {
                let height = min(460, max(150, startFrame.height - dy))
                frame = CGRect(x: startFrame.minX, y: startFrame.maxY - height, width: min(520, max(260, startFrame.width + dx)), height: height)
                manualSizeOverride = true
                needsLayout = true
            }
            ownerPDFView?.recomputeOverlayOffset(self)
            ownerPDFView?.updateConnectorLayer(groupID)
        }
        override func mouseUp(with event: NSEvent) {
            if moving || resizing { saveGeometryToAnnotation() }
            moving = false; resizing = false
        }
        override func scrollWheel(with event: NSEvent) { scroll.scrollWheel(with: event) }
        func restoreSavedGeometry() {
            if let x = savedOffsetX, let y = savedOffsetY { offsetFromAnchor = CGPoint(x: x, y: y) }
            if let width = savedWidth, let height = savedHeight {
                setFrameSize(NSSize(width: min(520, max(260, width)), height: min(460, max(150, height))))
                manualSizeOverride = true; needsLayout = true
            }
        }
        func saveGeometryToAnnotation() {
            ownerPDFView?.recomputeOverlayOffset(self)
            savedOffsetX = offsetFromAnchor.x; savedOffsetY = offsetFromAnchor.y
            savedWidth = frame.width; savedHeight = frame.height
            ownerPDFView?.saveOverlayGeometry(groupID: groupID, offset: offsetFromAnchor, size: frame.size)
        }
        // 简单的Markdown渲染
        private func renderMarkdown(_ text: String, font: NSFont) -> NSAttributedString {
            let result = NSMutableAttributedString()
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 4
            
            let lines = text.components(separatedBy: "\n")
            
            for (index, line) in lines.enumerated() {
                var processedLine = line
                var attributes: [NSAttributedString.Key: Any] = [
                    .font: font,
                    .foregroundColor: NSColor.labelColor,
                    .paragraphStyle: paragraphStyle
                ]
                
                // 处理标题 (#, ##, ###)
                if line.hasPrefix("### ") {
                    processedLine = String(line.dropFirst(4))
                    attributes[.font] = NSFont.boldSystemFont(ofSize: font.pointSize + 2)
                } else if line.hasPrefix("## ") {
                    processedLine = String(line.dropFirst(3))
                    attributes[.font] = NSFont.boldSystemFont(ofSize: font.pointSize + 4)
                } else if line.hasPrefix("# ") {
                    processedLine = String(line.dropFirst(2))
                    attributes[.font] = NSFont.boldSystemFont(ofSize: font.pointSize + 6)
                }
                
                // 处理列表项
                if line.hasPrefix("- ") || line.hasPrefix("* ") {
                    processedLine = "• " + String(line.dropFirst(2))
                }
                
                // 处理粗体 **text**
                let boldPattern = try? NSRegularExpression(pattern: "\\*\\*(.+?)\\*\\*", options: [])
                if let matches = boldPattern?.matches(in: processedLine, options: [], range: NSRange(processedLine.startIndex..., in: processedLine)) {
                    let attrLine = NSMutableAttributedString(string: processedLine, attributes: attributes)
                    for match in matches.reversed() {
                        if let captureRange = Range(match.range(at: 1), in: processedLine) {
                            let boldText = String(processedLine[captureRange])
                            let boldAttr = NSAttributedString(string: boldText, attributes: [
                                .font: NSFont.boldSystemFont(ofSize: font.pointSize),
                                .foregroundColor: NSColor.labelColor
                            ])
                            attrLine.replaceCharacters(in: match.range, with: boldAttr)
                        }
                    }
                    result.append(attrLine)
                } else {
                    result.append(NSAttributedString(string: processedLine, attributes: attributes))
                }
                
                if index < lines.count - 1 {
                    result.append(NSAttributedString(string: "\n"))
                }
            }
            
            return result
        }

    }

    private var calloutOverlays: [String: CalloutOverlayView] = [:]
    private var calloutConnectorLayers: [String: CAShapeLayer] = [:]
    // Hosts that sit above PDFView's internal documentView (so lines are visible)
    private weak var calloutConnectorHostView: NSView?
    private weak var calloutOverlayHostView: NSView?

    // Host view that passes events through to PDFView unless a subview actually hits.
    private final class PassthroughHostView: NSView {
        override func hitTest(_ point: NSPoint) -> NSView? {
            guard !isHidden else { return nil }
            let local = convert(point, from: superview)
            guard bounds.contains(local) else { return nil }
            for sub in subviews.reversed() where !sub.isHidden {
                if let hit = sub.hitTest(local) { return hit }
            }
            return nil
        }
    }

    private func ensureCalloutHosts() {
        if calloutConnectorHostView != nil, calloutOverlayHostView != nil { return }

        let connectorHost = PassthroughHostView(frame: self.bounds)
        connectorHost.wantsLayer = true
        connectorHost.layer?.masksToBounds = true
        connectorHost.autoresizingMask = [.width, .height]

        let overlayHost = PassthroughHostView(frame: self.bounds)
        overlayHost.wantsLayer = true
        overlayHost.layer?.masksToBounds = true
        overlayHost.autoresizingMask = [.width, .height]

        if let docView = self.documentView {
            self.addSubview(connectorHost, positioned: .above, relativeTo: docView)
            self.addSubview(overlayHost, positioned: .above, relativeTo: connectorHost)
        } else {
            self.addSubview(connectorHost)
            self.addSubview(overlayHost)
        }

        calloutConnectorHostView = connectorHost
        calloutOverlayHostView = overlayHost

        // move existing overlays (if any)
        for (_, ov) in calloutOverlays {
            ov.removeFromSuperview()
            overlayHost.addSubview(ov)
        }

        // reparent existing connector layers (if any)
        for (_, layer) in calloutConnectorLayers {
            layer.removeFromSuperlayer()
            connectorHost.layer?.addSublayer(layer)
            layer.frame = connectorHost.bounds
        }
    }

    private func ensureConnectorLayer(_ gid: String) -> CAShapeLayer {
        ensureCalloutHosts()
        if let l = calloutConnectorLayers[gid] { return l }

        let l = CAShapeLayer()
        l.contentsScale = window?.backingScaleFactor ?? 2
        l.fillColor = NSColor.clear.cgColor
        l.lineWidth = 2.0
        l.lineCap = .round
        l.lineJoin = .round

        if let host = calloutConnectorHostView {
            host.layer?.addSublayer(l)
            l.frame = host.bounds
        } else {
            if self.layer == nil { self.wantsLayer = true }
            self.layer?.addSublayer(l)
            l.frame = self.bounds
        }

        calloutConnectorLayers[gid] = l
        return l
    }

    private func removeConnectorLayer(_ gid: String) {
        if let l = calloutConnectorLayers.removeValue(forKey: gid) {
            l.removeFromSuperlayer()
        }
    }

    func updateConnectorLayer(_ gid: String) {
        guard let ov = calloutOverlays[gid] else { return }
        guard let info = noteAndCallout(onAnyPageFor: gid) else { return }

        let start = anchorPointInView(for: info.note, on: info.page)
        let cardRect = ov.superview.map { convert(ov.frame, from: $0) } ?? ov.frame
        let end = nearestAnchorPoint(from: start, to: cardRect)

        let dx = end.x - start.x
        let dy = end.y - start.y
        let distance = sqrt(dx * dx + dy * dy)

        let path = CGMutablePath()
        path.move(to: start)
        
        // 使用简洁的贝塞尔曲线连接
        if distance > 50 {
            // 较长距离使用平滑的S形曲线
            let ctrl1: CGPoint
            let ctrl2: CGPoint
            
            if abs(dx) >= abs(dy) {
                // 水平方向为主
                ctrl1 = CGPoint(x: start.x + dx * 0.4, y: start.y)
                ctrl2 = CGPoint(x: start.x + dx * 0.6, y: end.y)
            } else {
                // 垂直方向为主
                ctrl1 = CGPoint(x: start.x, y: start.y + dy * 0.4)
                ctrl2 = CGPoint(x: end.x, y: start.y + dy * 0.6)
            }
            
            path.addCurve(to: end, control1: ctrl1, control2: ctrl2)
        } else {
            // 短距离直接使用二次曲线
            let ctrl = CGPoint(x: (start.x + end.x) / 2, y: (start.y + end.y) / 2)
            path.addQuadCurve(to: end, control: ctrl)
        }

        let layer = ensureConnectorLayer(gid)
        let noteColor = info.note.color
        
        // 设置渐变效果的线条
        layer.strokeColor = noteColor.withAlphaComponent(0.7).cgColor
        layer.lineWidth = 1.5
        layer.lineDashPattern = nil
        layer.lineCap = .round
        
        if let host = calloutConnectorHostView {
            layer.frame = host.bounds
        } else {
            layer.frame = self.bounds
        }
        layer.path = path
        
        // 添加起点小圆点
        addConnectorEndpoint(at: start, color: noteColor, toLayer: layer)
    }
    
    // 在连接点添加小圆点
    private func addConnectorEndpoint(at point: CGPoint, color: NSColor, toLayer parentLayer: CAShapeLayer) {
        // 移除旧的子层
        parentLayer.sublayers?.removeAll()
        
        let dotRadius: CGFloat = 3
        let dotLayer = CAShapeLayer()
        let dotPath = CGPath(ellipseIn: CGRect(x: point.x - dotRadius, y: point.y - dotRadius,
                                               width: dotRadius * 2, height: dotRadius * 2),
                            transform: nil)
        dotLayer.path = dotPath
        dotLayer.fillColor = color.withAlphaComponent(0.8).cgColor
        dotLayer.strokeColor = nil
        parentLayer.addSublayer(dotLayer)
    }

    private func ensureOverlay(groupID gid: String) -> CalloutOverlayView {
        if let existing = calloutOverlays[gid] { return existing }
        ensureCalloutHosts()
        let ov = CalloutOverlayView(groupID: gid, owner: self)
        if let host = calloutOverlayHostView {
            host.addSubview(ov)
        } else {
            addSubview(ov)
        }
        calloutOverlays[gid] = ov
        return ov
    }

    private func removeOverlay(groupID gid: String) {
        if let ov = calloutOverlays.removeValue(forKey: gid) {
            ov.removeFromSuperview()
        }
    }

    private func noteAndCallout(onAnyPageFor gid: String) -> (note: PDFAnnotation, ft: PDFAnnotation, page: PDFPage)? {
        guard let doc = self.document else { return nil }
        for i in 0..<doc.pageCount {
            guard let p = doc.page(at: i) else { continue }
            guard let note = p.annotations.first(where: { isNote($0) && $0.userName == gid }) else { continue }
            guard let ft = findCalloutText(groupID: gid, on: p) else { continue }
            return (note, ft, p)
        }
        return nil
    }

    private func anchorPointInView(for note: PDFAnnotation, on page: PDFPage) -> CGPoint {
        let r = self.convert(note.bounds, from: page)
        return CGPoint(x: r.maxX, y: r.maxY)
    }

    private func recomputeOverlayOffset(_ ov: CalloutOverlayView) {
        guard let info = noteAndCallout(onAnyPageFor: ov.groupID) else { return }
        let anchor = anchorPointInView(for: info.note, on: info.page)

        // Convert overlay origin to CustomPDFView coordinate space before computing offset.
        let originInSelf: CGPoint
        if let sv = ov.superview, sv !== self {
            originInSelf = self.convert(ov.frame.origin, from: sv)
        } else {
            originInSelf = ov.frame.origin
        }

        ov.offsetFromAnchor = CGPoint(x: originInSelf.x - anchor.x, y: originInSelf.y - anchor.y)
    }

    private func autoSizeOverlay(_ overlay: CalloutOverlayView) {
        guard !overlay.manualSizeOverride else { return }
        let width: CGFloat = 320
        overlay.setFrameSize(CGSize(width: width, height: overlay.idealHeight(width: width)))
        overlay.needsLayout = true
    }

    private func showOverlayForCallout(groupID gid: String) {
        guard let info = noteAndCallout(onAnyPageFor: gid) else { return }

        let ov = ensureOverlay(groupID: gid)
        ov.isHidden = false
        
        // 设置边框颜色与批注颜色相同
        ov.setBorderColor(info.note.color)
        
        // 从annotation恢复保存的位置和大小
        loadOverlayGeometry(overlay: ov, from: info.ft)
        ov.restoreSavedGeometry()

        ov.setText(info.ft.contents ?? "", font: info.ft.font)
        
        // 如果没有保存的大小，则自动调整
        if ov.savedWidth == nil {
            autoSizeOverlay(ov)
        }

        // Hide on-screen FreeText; keep it for persistence/printing if you want
        info.ft.shouldDisplay = false
        info.ft.shouldPrint = true

        if let ln = findCalloutConnector(groupID: gid, on: info.page) {
            ln.shouldDisplay = false
            ln.shouldPrint = true
        }

        updateCalloutOverlayPositions()
        if let superview = ov.superview {
            let visible = superview.convert(bounds.insetBy(dx: 12, dy: 12), from: self)
            var frame = ov.frame
            frame.origin.x = min(max(frame.minX, visible.minX), max(visible.minX, visible.maxX - frame.width))
            frame.origin.y = min(max(frame.minY, visible.minY), max(visible.minY, visible.maxY - frame.height))
            ov.frame = frame
            recomputeOverlayOffset(ov)
        }
        ov.layoutSubtreeIfNeeded()
        ov.saveGeometryToAnnotation()
        updateConnectorLayer(gid)
    }
    
    // 从annotation加载保存的overlay几何信息
    private func loadOverlayGeometry(overlay: CalloutOverlayView, from annotation: PDFAnnotation) {
        guard let page = annotation.page,
              let note = page.annotations.first(where: { isNote($0) && $0.userName == annotation.userName }) else { return }
        let rect = convert(annotation.bounds, from: page)
        let anchor = anchorPointInView(for: note, on: page)
        overlay.savedOffsetX = rect.minX - anchor.x
        overlay.savedOffsetY = rect.minY - anchor.y
        if let width = annotation.value(forAnnotationKey: PDFAnnotationKey(rawValue: "SPDFCardWidth")) as? NSNumber,
           let height = annotation.value(forAnnotationKey: PDFAnnotationKey(rawValue: "SPDFCardHeight")) as? NSNumber {
            overlay.savedWidth = CGFloat(truncating: width)
            overlay.savedHeight = CGFloat(truncating: height)
        }
    }

    fileprivate func saveOverlayGeometry(groupID gid: String, offset: CGPoint, size: CGSize) {
        guard let info = noteAndCallout(onAnyPageFor: gid) else { return }
        let anchor = anchorPointInView(for: info.note, on: info.page)
        let viewRect = CGRect(x: anchor.x + offset.x, y: anchor.y + offset.y, width: size.width, height: size.height)
        info.ft.bounds = convert(viewRect, to: info.page)
        info.ft.setValue(NSNumber(value: Double(size.width)), forAnnotationKey: PDFAnnotationKey(rawValue: "SPDFCardWidth"))
        info.ft.setValue(NSNumber(value: Double(size.height)), forAnnotationKey: PDFAnnotationKey(rawValue: "SPDFCardHeight"))
        info.ft.shouldPrint = true
        refreshNoteCalloutConnector(groupID: gid, on: info.page)
    }

    // 保存批注文本框的显示状态
    fileprivate func saveCalloutVisibility(groupID gid: String, isVisible: Bool) {
        guard let doc = self.document else { return }
        for i in 0..<doc.pageCount {
            guard let p = doc.page(at: i) else { continue }
            if let ft = findCalloutText(groupID: gid, on: p) {
                // 使用shouldPrint属性来标记显示状态
                ft.shouldPrint = isVisible
                return
            }
        }
    }

    private func hideOverlayForCallout(groupID gid: String) {
        calloutOverlays[gid]?.finishEditing()
        if let overlay = calloutOverlays[gid], let responder = window?.firstResponder as? NSView,
           responder.isDescendant(of: overlay) { window?.makeFirstResponder(self) }
        removeOverlayEditMonitor()
        removeConnectorLayer(gid)
        removeOverlay(groupID: gid)

        if let info = noteAndCallout(onAnyPageFor: gid) {
            // 标记为"隐藏状态"
            info.ft.shouldPrint = false
            if let ln = findCalloutConnector(groupID: gid, on: info.page) {
                ln.shouldPrint = false
            }
        }
    }
    
    // MARK: - 规范化注释（修复保存后重新加载导致的问题）
    func normalizeAnnotationsAfterLoad() {
        guard let doc = self.document else { return }
        
        for i in 0..<doc.pageCount {
            guard let page = doc.page(at: i) else { continue }
            
            for annotation in page.annotations {
                if isFreeText(annotation), !isNoteCalloutText(annotation),
                   !(annotation is ReadablePDFTextAnnotation) {
                    let replacement = ReadablePDFTextAnnotation(bounds: annotation.bounds, forType: .freeText, withProperties: nil)
                    replacement.font = annotation.font ?? .systemFont(ofSize: 14)
                    replacement.fontColor = annotation.fontColor ?? .black
                    replacement.color = annotation.color; replacement.border = annotation.border
                    replacement.contents = annotation.contents; replacement.userName = annotation.userName
                    replacement.alignment = annotation.alignment
                    replacement.shouldDisplay = annotation.shouldDisplay; replacement.shouldPrint = annotation.shouldPrint
                    setAnnotationSubject(replacement, ReadablePDFTextAnnotation.subject)
                    page.removeAnnotation(annotation); page.addAnnotation(replacement)
                }
                // 1. 规范化Note图标大小（修复图标变大的问题）
                if isNote(annotation) {
                    let currentBounds = annotation.bounds
                    // 检查是否需要规范化（如果尺寸不是我们期望的14x14）
                    if abs(currentBounds.width - noteIconSize) > 1 || abs(currentBounds.height - noteIconSize) > 1 {
                        // 保持中心点不变，重新设置为标准大小
                        let centerX = currentBounds.midX
                        let centerY = currentBounds.midY
                        let newBounds = CGRect(
                            x: centerX - noteIconHalf,
                            y: centerY - noteIconHalf,
                            width: noteIconSize,
                            height: noteIconSize
                        )
                        annotation.bounds = newBounds
                    }
                }
                
                // 2. 规范化Callout文本框（修复重叠问题）
                if isNoteCalloutText(annotation) {
                    // 获取关联的Note图标
                    if let gid = annotation.userName,
                       let note = page.annotations.first(where: { isNote($0) && $0.userName == gid }) {
                        
                        let noteRect = note.bounds
                        let ftRect = annotation.bounds
                        
                        // 检查文本框是否与Note图标重叠过多
                        let noteCenter = CGPoint(x: noteRect.midX, y: noteRect.midY)
                        let ftOrigin = CGPoint(x: ftRect.minX, y: ftRect.minY)
                        
                        // 计算当前偏移
                        let currentOffsetX = ftOrigin.x - noteCenter.x
                        let currentOffsetY = ftOrigin.y - noteCenter.y
                        
                        // 如果文本框与Note图标重叠（偏移太小），则调整位置
                        let minOffset: CGFloat = 20
                        if abs(currentOffsetX) < minOffset && abs(currentOffsetY) < minOffset {
                            // 将文本框移到Note图标的右上方
                            let newX = noteRect.maxX + 10
                            let newY = noteRect.maxY + 10
                            var newBounds = ftRect
                            newBounds.origin.x = newX
                            newBounds.origin.y = newY
                            annotation.bounds = newBounds
                            
                            // 同时更新连接线
                            refreshNoteCalloutConnector(groupID: gid, on: page)
                        }
                    }
                }
            }
        }
        
        forceRefresh()
    }
    
    // MARK: - 恢复批注文本框的显示状态
    func restoreCalloutVisibilityStates() {
        guard let doc = self.document else { return }
        
        for i in 0..<doc.pageCount {
            guard let page = doc.page(at: i) else { continue }
            
            for annotation in page.annotations {
                // 查找Note类型的批注
                if isNote(annotation) {
                    let gid = annotation.userName ?? ""
                    if gid.isEmpty { continue }
                    
                    // 查找对应的FreeText（callout文本框）
                    if let ft = findCalloutText(groupID: gid, on: page) {
                        // 如果shouldPrint为true，表示之前是显示状态，需要恢复显示
                        if ft.shouldPrint {
                            showOverlayForCallout(groupID: gid)
                        }
                    }
                }
            }
        }
    }
    
    // MARK: - 显示/隐藏所有批注文本框
    func toggleAllCalloutOverlays() {
        guard document != nil else { return }
        
        // 检查当前是否有任何显示的overlay
        let hasVisibleOverlays = !calloutOverlays.isEmpty
        
        if hasVisibleOverlays {
            // 隐藏所有
            hideAllCalloutOverlays()
        } else {
            // 显示所有
            showAllCalloutOverlays()
        }
        
        forceRefresh()
        NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
    }
    
    func showAllCalloutOverlays() {
        guard let doc = self.document else { return }
        
        for i in 0..<doc.pageCount {
            guard let page = doc.page(at: i) else { continue }
            
            for annotation in page.annotations {
                if isNote(annotation) {
                    let gid = annotation.userName ?? ""
                    if gid.isEmpty { continue }
                    
                    // 如果有对应的FreeText，则显示overlay
                    if findCalloutText(groupID: gid, on: page) != nil {
                        if calloutOverlays[gid] == nil {
                            showOverlayForCallout(groupID: gid)
                        }
                    }
                }
            }
        }
    }
    
    func hideAllCalloutOverlays() {
        // 获取所有当前显示的overlay的groupID
        let gids = Array(calloutOverlays.keys)
        
        for gid in gids {
            hideOverlayForCallout(groupID: gid)
        }
    }
    
    // 检查是否有显示的批注文本框
    func hasVisibleCalloutOverlays() -> Bool {
        return !calloutOverlays.isEmpty
    }

    private func updateCalloutOverlayPositions() {
        for (gid, ov) in Array(calloutOverlays) {
            guard let info = noteAndCallout(onAnyPageFor: gid) else { removeOverlay(groupID: gid); removeConnectorLayer(gid); continue }
            let anchor = anchorPointInView(for: info.note, on: info.page)

            // Desired origin in CustomPDFView coordinates.
            let originInSelf = CGPoint(x: anchor.x + ov.offsetFromAnchor.x, y: anchor.y + ov.offsetFromAnchor.y)

            // 不再限制overlay在bounds内，允许随页面滚动移出屏幕
            // Convert to overlay superview coordinates (overlayHost), then set.
            if let sv = ov.superview, sv !== self {
                let originInSuperview = sv.convert(originInSelf, from: self)
                ov.setFrameOrigin(originInSuperview)
            } else {
                ov.setFrameOrigin(originInSelf)
            }

            updateConnectorLayer(gid)
        }
    }
    
    // MARK: - 缩放时更新overlay大小
    func updateCalloutOverlaysForScaleChange() {
        for (gid, overlay) in calloutOverlays {
            guard let info = noteAndCallout(onAnyPageFor: gid) else { continue }
            loadOverlayGeometry(overlay: overlay, from: info.ft)
            if let x = overlay.savedOffsetX, let y = overlay.savedOffsetY { overlay.offsetFromAnchor = CGPoint(x: x, y: y) }
        }
        updateCalloutOverlayPositions()
        updateTextOverlays()
    }

    private func syncCalloutText(groupID gid: String, text: String) {
        guard let doc = self.document else { return }
        for i in 0..<doc.pageCount {
            guard let p = doc.page(at: i) else { continue }
            if let note = p.annotations.first(where: { isNote($0) && $0.userName == gid }) {
                note.contents = text
            }
            if let ft = findCalloutText(groupID: gid, on: p) {
                ft.contents = text
                if calloutOverlays[gid] == nil { autoSizeCalloutTextBox(ft, text: text) }
            }
            if findCalloutConnector(groupID: gid, on: p) != nil {
                refreshNoteCalloutConnector(groupID: gid, on: p)
            }
        }
    }
    
    // MARK: - 从Note同步文本到Callout Overlay（公开方法供Coordinator调用）
    func syncCalloutTextFromNote(groupID gid: String, text: String) {
        // 更新FreeText annotation
        guard let doc = self.document else { return }
        for i in 0..<doc.pageCount {
            guard let p = doc.page(at: i) else { continue }
            if let ft = findCalloutText(groupID: gid, on: p) {
                ft.contents = text
                if calloutOverlays[gid] == nil { autoSizeCalloutTextBox(ft, text: text) }
            }
            if findCalloutConnector(groupID: gid, on: p) != nil {
                refreshNoteCalloutConnector(groupID: gid, on: p)
            }
        }
        
        // 更新overlay（如果存在且显示）
        if let ov = calloutOverlays[gid] {
            if let info = noteAndCallout(onAnyPageFor: gid) {
                ov.setText(text, font: info.ft.font)
                if !ov.manualSizeOverride {
                    autoSizeOverlay(ov)
                }
                updateConnectorLayer(gid)
            }
        }
    }

    // Draw overlay connectors in view coordinates so they can extend outside page.
    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)
    }
    
    // MARK: - Note Callout implementation
    private func dist2(_ a: CGPoint, _ b: CGPoint) -> CGFloat { let dx = a.x - b.x; let dy = a.y - b.y; return dx * dx + dy * dy }
    private func nearestAnchorPoint(from p: CGPoint, to rect: CGRect) -> CGPoint {
        let candidates: [CGPoint] = [CGPoint(x: rect.minX, y: rect.midY), CGPoint(x: rect.maxX, y: rect.midY), CGPoint(x: rect.midX, y: rect.maxY), CGPoint(x: rect.midX, y: rect.minY)]
        return candidates.min(by: { dist2($0, p) < dist2($1, p) }) ?? CGPoint(x: rect.minX, y: rect.midY)
    }
    private func findCalloutText(groupID gid: String, on page: PDFPage) -> PDFAnnotation? { page.annotations.first(where: { isNoteCalloutText($0) && $0.userName == gid }) }
    private func findCalloutConnector(groupID gid: String, on page: PDFPage) -> PDFAnnotation? { page.annotations.first(where: { isNoteConnectorLine($0) && $0.userName == gid }) }

    // Auto-size the callout FreeText box based on its text.
    private func autoSizeCalloutTextBox(_ ft: PDFAnnotation, text: String) {
        let font = ft.font ?? NSFont.systemFont(ofSize: 14)
        let maxWidth: CGFloat = 360
        let minWidth: CGFloat = 180
        let minHeight: CGFloat = 60
        let maxHeight: CGFloat = 420
        let paddingX: CGFloat = 16
        let paddingY: CGFloat = 14

        let normalized = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let lines = normalized.isEmpty ? [""] : normalized.components(separatedBy: "\n")

        // Estimate width from the longest line (clamped), then compute wrapped height with boundingRect.
        var longest: CGFloat = 0
        let measureAttrs: [NSAttributedString.Key: Any] = [.font: font]
        for line in lines {
            let w = (line as NSString).size(withAttributes: measureAttrs).width
            if w > longest { longest = w }
        }

        let targetWidth = min(maxWidth, max(minWidth, longest + paddingX * 2))

        let paragraph = NSMutableParagraphStyle()
        paragraph.lineBreakMode = .byWordWrapping
        paragraph.alignment = .left

        let attrs: [NSAttributedString.Key: Any] = [
            .font: font,
            .paragraphStyle: paragraph
        ]

        let nsText = normalized.isEmpty ? " " : normalized
        let bounding = (nsText as NSString).boundingRect(
            with: NSSize(width: targetWidth - paddingX * 2, height: CGFloat.greatestFiniteMagnitude),
            options: [.usesLineFragmentOrigin, .usesFontLeading],
            attributes: attrs
        )

        var targetHeight = ceil(bounding.height + paddingY * 2)
        targetHeight = max(minHeight, min(maxHeight, targetHeight))

        // Keep origin stable; resize to the right/up.
        var b = ft.bounds
        b.size.width = targetWidth
        b.size.height = targetHeight
        ft.bounds = b
    }
    private func refreshNoteCalloutConnector(groupID gid: String, on page: PDFPage) {
        guard let note = page.annotations.first(where: { isNote($0) && $0.userName == gid }) else { return }
        guard let ft = findCalloutText(groupID: gid, on: page) else { return }
        guard let ln = findCalloutConnector(groupID: gid, on: page) else { return }
        let noteRect = note.bounds
        let boxRect = ft.bounds
        let noteC = CGPoint(x: noteRect.midX, y: noteRect.midY)
        let boxC = CGPoint(x: boxRect.midX, y: boxRect.midY)

        let dx = boxC.x - noteC.x
        let dy = boxC.y - noteC.y

        // keep line away from borders to look cleaner
        let standoff: CGFloat = 6
        let inset: CGFloat = 14

        var startEdge = noteC
        var startNormal = CGPoint(x: 0, y: 0)
        var endEdge = boxC
        var endNormal = CGPoint(x: 0, y: 0)

        if abs(dx) >= abs(dy) {
            // Mostly horizontal: connect from note left/right edge to callout left/right edge
            if dx >= 0 {
                startEdge = CGPoint(x: noteRect.maxX, y: noteRect.midY)
                startNormal = CGPoint(x: 1, y: 0)
                let y = max(boxRect.minY + inset, min(noteRect.midY, boxRect.maxY - inset))
                endEdge = CGPoint(x: boxRect.minX, y: y)
                endNormal = CGPoint(x: -1, y: 0)
            } else {
                startEdge = CGPoint(x: noteRect.minX, y: noteRect.midY)
                startNormal = CGPoint(x: -1, y: 0)
                let y = max(boxRect.minY + inset, min(noteRect.midY, boxRect.maxY - inset))
                endEdge = CGPoint(x: boxRect.maxX, y: y)
                endNormal = CGPoint(x: 1, y: 0)
            }
        } else {
            // Mostly vertical: connect from note top/bottom edge to callout top/bottom edge
            if dy >= 0 {
                startEdge = CGPoint(x: noteRect.midX, y: noteRect.maxY)
                startNormal = CGPoint(x: 0, y: 1)
                let x = max(boxRect.minX + inset, min(noteRect.midX, boxRect.maxX - inset))
                endEdge = CGPoint(x: x, y: boxRect.minY)
                endNormal = CGPoint(x: 0, y: -1)
            } else {
                startEdge = CGPoint(x: noteRect.midX, y: noteRect.minY)
                startNormal = CGPoint(x: 0, y: -1)
                let x = max(boxRect.minX + inset, min(noteRect.midX, boxRect.maxX - inset))
                endEdge = CGPoint(x: x, y: boxRect.maxY)
                endNormal = CGPoint(x: 0, y: 1)
            }
        }

        let start = CGPoint(x: startEdge.x + startNormal.x * standoff, y: startEdge.y + startNormal.y * standoff)
        let end = CGPoint(x: endEdge.x + endNormal.x * standoff, y: endEdge.y + endNormal.y * standoff)

        updateLineAnnotation(ln, start: start, end: end)
    }

    func upsertNoteCallout(for note: PDFAnnotation, text: String) {
        guard let page = note.page else { return }
        let gid = ensureGroupID(for: note)
        note.contents = text

        let ft: PDFAnnotation
        if let existing = findCalloutText(groupID: gid, on: page) { ft = existing } else {
            let nb = note.bounds; let b = CGRect(x: nb.maxX + 24, y: nb.maxY + 24, width: 220, height: 80)
            let created = PDFAnnotation(bounds: b, forType: .freeText, withProperties: nil)
            created.userName = gid; setAnnotationSubject(created, noteCalloutSubject); created.font = .systemFont(ofSize: 14); created.fontColor = .labelColor; created.color = NSColor.white.withAlphaComponent(0.9)
            let border = PDFBorder(); border.lineWidth = 1.0; created.border = border
            page.addAnnotation(created); ft = created
        }
        ft.contents = text; ft.shouldDisplay = true; ft.shouldPrint = true
        autoSizeCalloutTextBox(ft, text: text)

        let ln: PDFAnnotation
        if let existing = findCalloutConnector(groupID: gid, on: page) { ln = existing } else {
            let created = PDFAnnotation(bounds: CGRect(x: 0, y: 0, width: 2, height: 2), forType: .line, withProperties: nil)
            created.userName = gid; setAnnotationSubject(created, noteConnectorSubject)
            let border = PDFBorder(); border.lineWidth = 1.5; created.border = border; created.color = note.color; created.interiorColor = .clear
            page.addAnnotation(created); ln = created
        }
        // ✅ 关键：设置 shouldDisplay = false 以隐藏原生直线，我们将在 draw() 中自定义绘制曲线
        ln.shouldDisplay = false
        ln.shouldPrint = true
        ln.color = note.color

        refreshNoteCalloutConnector(groupID: gid, on: page)

        // ✅ On-screen: show an overlay textbox that can extend outside the page.
        showOverlayForCallout(groupID: gid)
        forceRefresh()
        NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
    }

    func handleNoteDoubleClick(_ note: PDFAnnotation) {
        guard let page = note.page else { return }
        draggedAnnotation = nil; selectedAnnotation = nil; clearSelection()
        let gid = ensureGroupID(for: note)

        // 若缺少 callout，则先创建（默认显示）
        if findCalloutText(groupID: gid, on: page) == nil || findCalloutConnector(groupID: gid, on: page) == nil {
            closeInlineEditor(commit: true)
            upsertNoteCallout(for: note, text: note.contents ?? "")
            return
        }

        guard findCalloutText(groupID: gid, on: page) != nil else { return }

        // 双击仅切换显示/隐藏（不再自动进入编辑）
        if calloutOverlays[gid] != nil {
            closeInlineEditor(commit: true)
            removeConnectorLayer(gid)
            hideOverlayForCallout(groupID: gid)
            forceRefresh()
        } else {
            showOverlayForCallout(groupID: gid)
            refreshNoteCalloutConnector(groupID: gid, on: page)
            forceRefresh()
        }
    }
    
    // Subclass NSSlider
    private final class ShapeWidthSlider: NSSlider { weak var shapeAnnotation: PDFAnnotation? }
    private func lineWidthSliderMenuItem(for shape: PDFAnnotation) -> NSMenuItem {
        let item = NSMenuItem(title: "", action: nil, keyEquivalent: ""); let current = Double(shape.border?.lineWidth ?? shapeLineWidth)
        let container = NSView(frame: NSRect(x: 0, y: 0, width: 200, height: 28))
        let slider = ShapeWidthSlider(value: current, minValue: 0.5, maxValue: 12.0, target: self, action: #selector(changeShapeLineWidth(_:))); slider.isContinuous = true; slider.frame = NSRect(x: 10, y: 4, width: 180, height: 20); slider.shapeAnnotation = shape; container.addSubview(slider)
        item.view = container; return item
    }

    @objc func addNoteToShape(_ s: NSMenuItem) { guard let shape = s.representedObject as? PDFAnnotation, let p = shape.page else { return }; let gid = ensureGroupID(for: shape); let c = shape.color; let n = addNoteAnnotation(page: p, highlightBounds: shape.bounds, color: c, content: shape.contents ?? "", groupID: gid); coordinator?.showStandaloneNoteInput(for: n, in: self) }
    @objc func changeShapeColor(_ s: NSMenuItem) {
        guard let payload = s.representedObject as? ShapeColorPayload else { return }; let shape = payload.annotation; let newColor = payload.baseColor
        if let doc = self.document, let gid = smartGroupID(of: shape) {
            for i in 0..<doc.pageCount { guard let p = doc.page(at: i) else { continue }; for ann in p.annotations where ann.userName == gid { if isShape(ann) || isNote(ann) { ann.color = newColor } } }
        } else { shape.color = newColor; if let n = findLinkedNote(for: shape) { n.color = newColor } }
        forceRefresh()
        NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
    }
    @objc func changeShapeLineWidth(_ sender: NSSlider) {
        guard let slider = sender as? ShapeWidthSlider, let shape = slider.shapeAnnotation else { return }
        let w = CGFloat(slider.doubleValue); let b = shape.border ?? PDFBorder(); b.lineWidth = w; shape.border = b
        let subtype = getSubtypeString(shape); if subtype == "/Line" || subtype == "Line" { let start = CGPoint(x: shape.bounds.minX + shape.startPoint.x, y: shape.bounds.minY + shape.startPoint.y); let end = CGPoint(x: shape.bounds.minX + shape.endPoint.x, y: shape.bounds.minY + shape.endPoint.y); updateLineAnnotation(shape, start: start, end: end) }
        forceRefresh()
    }
    
    // MARK: - Highlights & Underlines
    func addHighlight(color: NSColor) {
        guard let selection = currentSelection else { return }; let gid = newSmartGroupID()
        let lineSelections = selection.selectionsByLine()
        if !lineSelections.isEmpty {
            for lineSel in lineSelections { for p in lineSel.pages { let b = lineSel.bounds(for: p); guard !b.isEmpty else { continue }; let ann = PDFAnnotation(bounds: b, forType: .highlight, withProperties: nil); ann.color = color; ann.userName = gid; p.addAnnotation(ann) } }
        } else { for p in selection.pages { let b = selection.bounds(for: p); guard !b.isEmpty else { continue }; let ann = PDFAnnotation(bounds: b, forType: .highlight, withProperties: nil); ann.color = color; ann.userName = gid; p.addAnnotation(ann) } }
        clearSelection(); forceRefresh()
        NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
    }

    func addUnderline(color: NSColor) {
        guard let selection = currentSelection else { return }; let gid = newSmartGroupID()
        let lineSelections = selection.selectionsByLine()
        if !lineSelections.isEmpty {
            for lineSel in lineSelections { for p in lineSel.pages { let b = lineSel.bounds(for: p); guard !b.isEmpty else { continue }; let ann = PDFAnnotation(bounds: b, forType: .underline, withProperties: nil); ann.color = color; ann.userName = gid; p.addAnnotation(ann) } }
        } else { for p in selection.pages { let b = selection.bounds(for: p); guard !b.isEmpty else { continue }; let ann = PDFAnnotation(bounds: b, forType: .underline, withProperties: nil); ann.color = color; ann.userName = gid; p.addAnnotation(ann) } }
        clearSelection(); forceRefresh()
        NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
    }
    
    func addNoteToSelection(color: NSColor) -> PDFAnnotation? {
        return addNoteToSelection(color: color, content: "")
    }

    func addNoteToSelection(color: NSColor, content: String) -> PDFAnnotation? {
        guard let selection = currentSelection else { return nil }
        let gid = newSmartGroupID()
        let lineSelections = selection.selectionsByLine()
        var lastBounds: CGRect? = nil
        var lastPage: PDFPage? = nil

        if !lineSelections.isEmpty {
            for lineSel in lineSelections {
                for page in lineSel.pages {
                    let b = lineSel.bounds(for: page)
                    guard !b.isEmpty else { continue }
                    let hl = PDFAnnotation(bounds: b, forType: .highlight, withProperties: nil)
                    hl.color = color
                    hl.userName = gid
                    page.addAnnotation(hl)
                    lastBounds = b
                    lastPage = page
                }
            }
        } else {
            for page in selection.pages {
                let b = selection.bounds(for: page)
                guard !b.isEmpty else { continue }
                let hl = PDFAnnotation(bounds: b, forType: .highlight, withProperties: nil)
                hl.color = color
                hl.userName = gid
                page.addAnnotation(hl)
                lastBounds = b
                lastPage = page
            }
        }

        guard let p = lastPage ?? selection.pages.first else {
            clearSelection()
            forceRefresh()
            return nil
        }

        let anchor = lastBounds ?? selection.bounds(for: p)
        let noteRect = CGRect(
            x: anchor.maxX - noteIconCornerInset,
            y: anchor.maxY - noteIconCornerInset,
            width: noteIconSize,
            height: noteIconSize
        )

        let n = PDFAnnotation(bounds: noteRect, forType: .text, withProperties: nil)
        n.iconType = .comment
        n.color = color
        n.contents = content
        n.userName = gid
        p.addAnnotation(n)

        clearSelection()
        forceRefresh()
        NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
        return n
    }

    private func shapeMenuIcon(for tool: ShapeTool) -> NSImage? {
        let symbolName: String
        switch tool { case .line: symbolName = "line.diagonal"; case .arrow: symbolName = "arrow.up.right"; case .rect: symbolName = "rectangle"; case .ellipse: symbolName = "circle"; case .none: return nil }
        let config = NSImage.SymbolConfiguration(pointSize: 13, weight: .regular); let img = NSImage(systemSymbolName: symbolName, accessibilityDescription: nil)?.withSymbolConfiguration(config); img?.isTemplate = true; return img
    }
}

// MARK: - 3. SwiftUI 封装
struct PDFKitView: NSViewRepresentable {
    let url: URL
    @ObservedObject var aiService: ChatGPTService
    @Binding var pdfDocument: PDFDocument?
    
    func makeNSView(context: Context) -> PDFView {
        let v = CustomPDFView()
        v.coordinator = context.coordinator
        context.coordinator.currentFileURL = url
        let doc = PDFDocument(url: url)
        v.document = doc
        v.autoScales = true
        v.displayMode = .singlePageContinuous
        v.displayDirection = .vertical
        v.registerForDraggedTypes([.string, NSPasteboard.PasteboardType("com.smartpdf.isheart")])
        context.coordinator.pdfView = v
        
        // 设置当前文件URL用于保存
        context.coordinator.currentFileURL = url
        
        // 设置撤销/重做观察者
        v.setupUndoRedoObservers()
        
        // 更新绑定的 pdfDocument
        DispatchQueue.main.async {
            self.pdfDocument = doc
        }
        
        // 延迟恢复批注文本框的显示状态（等待视图完全加载）
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            // 先规范化注释（修复保存后图标变大和文本框重叠的问题）
            guard v.document === doc else { return }
            v.normalizeAnnotationsAfterLoad()
            // 然后恢复显示状态
            v.restoreCalloutVisibilityStates()
        }
        
        NotificationCenter.default.addObserver(context.coordinator, selector: #selector(Coordinator.selectionChanged(_:)), name: .PDFViewSelectionChanged, object: v)
        NotificationCenter.default.addObserver(context.coordinator, selector: #selector(Coordinator.pageChanged(_:)), name: .PDFViewVisiblePagesChanged, object: v)
        // 导航通知
        NotificationCenter.default.addObserver(context.coordinator, selector: #selector(Coordinator.handleNavigateToPage(_:)), name: .navigateToPage, object: nil)
        NotificationCenter.default.addObserver(context.coordinator, selector: #selector(Coordinator.handleNavigateToAnnotation(_:)), name: .navigateToAnnotation, object: nil)
        // 缩放变化通知 - 实时更新连接线
        NotificationCenter.default.addObserver(context.coordinator, selector: #selector(Coordinator.scaleChanged(_:)), name: .PDFViewScaleChanged, object: v)
        return v
    }
    
    func updateNSView(_ nsView: PDFView, context: Context) {
        if nsView.document?.documentURL != url {
            context.coordinator.currentFileURL = url
            let doc = PDFDocument(url: url)
            (nsView as? CustomPDFView)?.prepareForDocumentChange()
            nsView.document = doc
            context.coordinator.clearSearch()
            context.coordinator.currentFileURL = url
            DispatchQueue.main.async {
                self.pdfDocument = doc
            }
            // 延迟规范化和恢复注释状态
            if let customView = nsView as? CustomPDFView {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    guard customView.document === doc else { return }
                    customView.normalizeAnnotationsAfterLoad()
                    customView.restoreCalloutVisibilityStates()
                }
            }
        }
    }
    
    func makeCoordinator() -> Coordinator { Coordinator(aiService: aiService) }
    
    class Coordinator: NSObject, NSPopoverDelegate {
        var popover: NSPopover?
        var selectionPanel: NSPanel?
        var aiService: ChatGPTService
        weak var pdfView: PDFView?
        var searchResults: [PDFSelection] = []
        var currentResultIndex: Int = 0
        private var selectionPanelEventMonitor: Any?
        private var fileAccess: ScopedFileAccess?
        var currentFileURL: URL? {
            didSet { fileAccess = currentFileURL.map(ScopedFileAccess.init) }
        }
        
        init(aiService: ChatGPTService) {
            self.aiService = aiService
            super.init()
            NotificationCenter.default.addObserver(self, selector: #selector(handleFindNotification(_:)), name: .findInPDF, object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(handleSavePDF(_:)), name: .savePDF, object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(handleSaveAsPDF(_:)), name: .saveAsPDF, object: nil)
        }
        deinit { NotificationCenter.default.removeObserver(self); if let monitor = selectionPanelEventMonitor { NSEvent.removeMonitor(monitor) } }
        
        // MARK: - 保存功能
        @objc func handleSavePDF(_ n: Notification) {
            // 确保在主线程执行
            guard Thread.isMainThread else {
                DispatchQueue.main.async { [weak self] in
                    self?.handleSavePDF(n)
                }
                return
            }
            
            guard pdfView?.document != nil else {
                showSaveAlert(success: false, message: L(.fileSaveError))
                return
            }
            
            // 获取PDF数据
            guard let data = (pdfView as? CustomPDFView)?.serializedDocumentData() else {
                showSaveAlert(success: false, message: L(.fileSaveError))
                return
            }
            
            // 如果有原文件路径，直接保存到原文件
            if let originalURL = currentFileURL {
                do {
                    // 尝试直接写入原文件
                    try data.write(to: originalURL, options: .atomic)
                    showSaveAlert(success: true, message: L(.fileSaved))
                } catch {
                    // 如果直接保存失败（如沙盒限制），则回退到另存为
                    print("Direct save failed: \(error.localizedDescription), falling back to Save As")
                    handleSaveAsPDF(n)
                }
            } else {
                // 没有原文件路径，使用另存为
                handleSaveAsPDF(n)
            }
        }
        
        @objc func handleSaveAsPDF(_ n: Notification) {
            // 确保在主线程执行
            guard Thread.isMainThread else {
                DispatchQueue.main.async { [weak self] in
                    self?.handleSaveAsPDF(n)
                }
                return
            }
            
            guard pdfView?.document != nil else {
                showSaveAlert(success: false, message: L(.fileSaveError))
                return
            }
            
            // 获取PDF数据
            guard let data = (pdfView as? CustomPDFView)?.serializedDocumentData() else {
                showSaveAlert(success: false, message: L(.fileSaveError))
                return
            }
            
            // 创建保存面板
            let panel = NSSavePanel()
            panel.canCreateDirectories = true
            panel.showsTagField = false
            panel.allowsOtherFileTypes = false
            panel.isExtensionHidden = false
            
            // 设置文件类型 - 使用更安全的方式
            if #available(macOS 11.0, *) {
                panel.allowedContentTypes = [UTType.pdf]
            } else {
                panel.allowedFileTypes = ["pdf"]
            }
            
            // 设置默认文件名
            let defaultName = currentFileURL?.lastPathComponent ?? "Untitled.pdf"
            panel.nameFieldStringValue = defaultName
            
            // 设置默认目录：如果有原文件，使用原文件所在目录；否则使用桌面
            if let originalURL = currentFileURL {
                panel.directoryURL = originalURL.deletingLastPathComponent()
            } else if let desktopURL = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).first {
                panel.directoryURL = desktopURL
            }
            
            // 显示面板
            let response = panel.runModal()
            
            if response == .OK, let saveURL = panel.url {
                do {
                    try data.write(to: saveURL, options: .atomic)
                    currentFileURL = saveURL
                    showSaveAlert(success: true, message: L(.fileSaved))
                } catch {
                    print("Save error: \(error.localizedDescription)")
                    showSaveAlert(success: false, message: "\(L(.fileSaveError)): \(error.localizedDescription)")
                }
            }
        }
        
        private func showSaveAlert(success: Bool, message: String) {
            // 确保在主线程执行
            guard Thread.isMainThread else {
                DispatchQueue.main.async { [weak self] in
                    self?.showSaveAlert(success: success, message: message)
                }
                return
            }
            
            let alert = NSAlert()
            if success {
                alert.messageText = L(.saveSuccess)
                alert.informativeText = message
                alert.alertStyle = .informational
            } else {
                alert.messageText = L(.saveError)
                alert.informativeText = message
                alert.alertStyle = .warning
            }
            alert.addButton(withTitle: "OK")
            alert.runModal()
        }
        
        @objc func handleFindNotification(_ n: Notification) {
            guard let i = n.userInfo, let a = i["action"] as? String else { return }
            let t = i["text"] as? String ?? ""
            switch a { case "search": performSearch(text: t); case "next": navigateSearch(direction: 1); case "prev": navigateSearch(direction: -1); case "clear": clearSearch(); default: break }
        }
        
        // MARK: - 导航处理方法
        @objc func handleNavigateToPage(_ n: Notification) {
            guard let v = pdfView else { return }
            
            // 支持两种导航方式：destination 或 pageIndex
            if let dest = n.userInfo?["destination"] as? PDFDestination {
                v.go(to: dest)
            } else if let pageIndex = n.userInfo?["pageIndex"] as? Int,
                      let doc = v.document,
                      let page = doc.page(at: pageIndex) {
                // 通过pageIndex跳转到页面顶部
                let dest = PDFDestination(page: page, at: CGPoint(x: 0, y: page.bounds(for: .mediaBox).height))
                v.go(to: dest)
            }
        }
        
        @objc func handleNavigateToAnnotation(_ n: Notification) {
            guard let annotation = n.userInfo?["annotation"] as? PDFAnnotation,
                  let page = n.userInfo?["page"] as? PDFPage,
                  let v = pdfView else { return }
            // 跳转到批注所在位置
            let bounds = annotation.bounds
            let dest = PDFDestination(page: page, at: CGPoint(x: bounds.midX, y: bounds.maxY + 50))
            v.go(to: dest)
            
            // 高亮显示批注（短暂闪烁效果）
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                if let customView = v as? CustomPDFView {
                    customView.flashAnnotation(annotation)
                }
            }
            
            // 发送文档变更通知以刷新批注列表
            NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
        }
        
        func performSearch(text: String) { guard let v = pdfView, let d = v.document, !text.isEmpty else { return }; let r = d.findString(text, withOptions: [.caseInsensitive]); searchResults = r; currentResultIndex = 0; if !r.isEmpty { v.highlightedSelections = r; v.go(to: r[0]) } else { v.highlightedSelections = nil } }
        func navigateSearch(direction: Int) { guard !searchResults.isEmpty, let v = pdfView else { return }; currentResultIndex = (currentResultIndex + direction) % searchResults.count; if currentResultIndex < 0 { currentResultIndex = searchResults.count - 1 }; let s = searchResults[currentResultIndex]; v.go(to: s); v.setCurrentSelection(s, animate: true) }
        func clearSearch() { searchResults = []; currentResultIndex = 0; pdfView?.highlightedSelections = nil }

        private func closeSelectionMenu() { if let monitor = selectionPanelEventMonitor { NSEvent.removeMonitor(monitor); selectionPanelEventMonitor = nil }; selectionPanel?.orderOut(nil); selectionPanel = nil }
        private func installSelectionMenuDismissMonitor(excluding panel: NSPanel) {
            if selectionPanelEventMonitor != nil { return }
            selectionPanelEventMonitor = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown]) { [weak self, weak panel] event in guard let self, let panel else { return event }; if event.window === panel { return event }; self.closeSelectionMenu(); return event }
        }

        func showSelectionMenu(in pdfView: CustomPDFView) {
            guard let _ = pdfView.currentSelection, let window = pdfView.window, let event = pdfView.lastMouseUpEvent else { return }
            closeSelectionMenu()
            let menuView = SelectionMenuView(
                onCopy: { pdfView.copy(nil); self.closeSelectionMenu() },
                onHighlight: { c in pdfView.addHighlight(color: c); self.closeSelectionMenu() },
                onUnderline: { c in pdfView.addUnderline(color: c); self.closeSelectionMenu() },
                onNote: { if let n = pdfView.addNoteToSelection(color: .systemYellow.withAlphaComponent(0.5)) { self.closeSelectionMenu(); DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { self.showStandaloneNoteInput(for: n, in: pdfView) } } },
                onTranslate: { if let t = pdfView.currentSelection?.string { self.aiService.sendMessage("请翻译以下内容：\n\n\(t)"); self.closeSelectionMenu() } },
                onDismiss: { self.closeSelectionMenu() }
            )
            let hosting = NSHostingController(rootView: menuView); let hostingView = hosting.view; hostingView.wantsLayer = true; hostingView.layer?.cornerRadius = 12; hostingView.layer?.masksToBounds = true; hostingView.layoutSubtreeIfNeeded(); var size = hostingView.fittingSize; if size.width < 200 || size.height < 30 { size = NSSize(width: 360, height: 52) }
            let panel = NSPanel(contentRect: NSRect(x: 0, y: 0, width: size.width, height: size.height), styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: true); panel.isFloatingPanel = true; panel.level = .floating; panel.collectionBehavior = [.canJoinAllSpaces, .transient, .fullScreenAuxiliary]; panel.isOpaque = false; panel.backgroundColor = .clear; panel.hasShadow = true; panel.titleVisibility = .hidden; panel.titlebarAppearsTransparent = true; panel.standardWindowButton(.closeButton)?.isHidden = true; panel.standardWindowButton(.miniaturizeButton)?.isHidden = true; panel.standardWindowButton(.zoomButton)?.isHidden = true; panel.contentView = hostingView
            let windowPoint = event.locationInWindow; let screenPoint = window.convertPoint(toScreen: windowPoint); let screen = window.screen ?? NSScreen.main; let visible = screen?.visibleFrame ?? NSScreen.main?.visibleFrame ?? NSRect(x: 0, y: 0, width: 1440, height: 900)
            var originX = screenPoint.x - size.width / 2; var originY = screenPoint.y - size.height - 6; if originY < visible.minY { originY = screenPoint.y + 6 }; originX = max(visible.minX, min(originX, visible.maxX - size.width)); originY = max(visible.minY, min(originY, visible.maxY - size.height))
            panel.setFrameOrigin(NSPoint(x: originX, y: originY)); panel.orderFrontRegardless(); self.selectionPanel = panel; installSelectionMenuDismissMonitor(excluding: panel)
        }
        @objc func selectionChanged(_ n: Notification) { guard let v = n.object as? CustomPDFView, v === pdfView else { return }; if let s = v.currentSelection, let t = s.string, !t.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { DispatchQueue.main.async { self.aiService.currentSelection = t } } else { DispatchQueue.main.async { self.aiService.currentSelection = "" }; closeSelectionMenu() }; if v.currentSelection == nil { popover?.close() } }
        @objc func pageChanged(_ n: Notification) {
            popover?.close()
            closeSelectionMenu()
            
            // 发送当前页码变化通知
            if let pdfView = n.object as? PDFView,
               let currentPage = pdfView.currentPage,
               let pageIndex = pdfView.document?.index(for: currentPage) {
                NotificationCenter.default.post(
                    name: .currentPageChanged,
                    object: nil,
                    userInfo: ["pageIndex": pageIndex]
                )
            }
        }
        
        // MARK: - 缩放变化处理 - 实时更新overlay位置和连接线
        @objc func scaleChanged(_ n: Notification) {
            guard let v = n.object as? CustomPDFView else { return }
            // 在缩放变化时更新所有callout overlay的位置
            v.updateCalloutOverlaysForScaleChange()
            v.forceRefresh()
        }
        
        func showNoteInput(for hl: PDFAnnotation, in v: CustomPDFView) {
            guard let p = hl.page else { return }; let r = v.convert(hl.bounds, from: p); let np = NSPopover(); np.behavior = .transient; let iv = NoteInputView(onSave: { s in let gid: String; if let existing = hl.userName, existing.hasPrefix("SPDF-GRP:") { gid = existing } else { gid = "SPDF-GRP:" + UUID().uuidString; hl.userName = gid }; let c = hl.color; _ = v.addNoteAnnotation(page: p, highlightBounds: hl.bounds, color: c, content: s, groupID: gid); np.close() }, onCancel: { np.close() }); np.contentViewController = NSHostingController(rootView: iv); popover?.close(); np.show(relativeTo: r, of: v, preferredEdge: .maxY); popover = np
        }
        func showStandaloneNoteInput(for n: PDFAnnotation, in v: CustomPDFView) {
            guard let p = n.page else { return }
            let r = v.convert(n.bounds, from: p)
            let np = NSPopover()
            np.behavior = .transient
            // 获取当前的groupID
            let gid = n.userName
            let iv = NoteInputView(initialText: n.contents ?? "", onSave: { s in
                n.contents = s
                // 如果有关联的callout，同步更新
                if let groupID = gid, groupID.hasPrefix("SPDF-GRP:") {
                    v.syncCalloutTextFromNote(groupID: groupID, text: s)
                }
                v.forceRefresh()
                NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil)
                np.close()
            }, onCancel: { np.close() })
            np.contentViewController = NSHostingController(rootView: iv)
            popover?.close()
            np.show(relativeTo: r.insetBy(dx: -6, dy: -6), of: v, preferredEdge: .maxY)
            popover = np
        }
        func showNoteCalloutEditor(for note: PDFAnnotation, in v: CustomPDFView) {
            guard let p = note.page else { return }
            let r = v.convert(note.bounds, from: p)
            let np = NSPopover()
            np.behavior = .transient
            let iv = NoteInputView(initialText: note.contents ?? "", onSave: { s in
                let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
                v.upsertNoteCallout(for: note, text: t)
                np.close()
            }, onCancel: { np.close() })
            np.contentViewController = NSHostingController(rootView: iv)
            popover?.close()
            np.show(relativeTo: r.insetBy(dx: -6, dy: -6), of: v, preferredEdge: .maxY)
            popover = np
        }
        func showFreeTextEditor(for ft: PDFAnnotation, in v: CustomPDFView) {
            guard let p = ft.page else { return }; let r = v.convert(ft.bounds, from: p); let np = NSPopover(); np.behavior = .transient; let iv = FreeTextEditView(initialText: ft.contents ?? "", onSave: { s in ft.contents = s; if ft.fontColor == nil { ft.fontColor = .systemRed }; if let f = ft.font { let h = max(24, f.pointSize * 1.6); if ft.bounds.height < h { ft.bounds.size.height = h } }; v.forceRefresh(); NotificationCenter.default.post(name: .pdfDocumentDidChange, object: nil); np.close() }, onCancel: { np.close() }); np.contentViewController = NSHostingController(rootView: iv); popover?.close(); np.show(relativeTo: r.insetBy(dx: -6, dy: -6), of: v, preferredEdge: .maxY); popover = np
        }
    }
}


