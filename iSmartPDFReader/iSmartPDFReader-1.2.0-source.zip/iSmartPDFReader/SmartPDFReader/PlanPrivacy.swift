#if APP_STORE
import AppKit

enum PlanPrivacy {
    static let consentKey = "allowOpenAIContentSharing"
    static func requestConsent(defaults: UserDefaults = .standard) -> Bool {
        if defaults.bool(forKey: consentKey) { return true }
        let alert = NSAlert()
        alert.messageText = T("允许将问答内容发送给 OpenAI？", "Allow sending question content to OpenAI?")
        alert.informativeText = T(
            "发送问题时，应用会将问题、为当前问题选取的 PDF 文字、选区、附图及当前对话上下文发送给 OpenAI，以生成回答。打开和标注 PDF 无需发送内容。请仅发送您有权分享的资料。\n\n您可以在设置中撤回此许可。OpenAI 对所接收数据的处理受其隐私政策和您的账号设置约束。",
            "When you send a question, the app shares your question, PDF excerpts selected for that question, selections, attached images and current conversation context with OpenAI to generate an answer. Opening and annotating PDFs does not require sharing content. Send only material you may share.\n\nYou can withdraw this permission in Settings. OpenAI handles received data under its privacy policy and your account settings.")
        alert.addButton(withTitle: T("允许并继续", "Allow and continue"))
        alert.addButton(withTitle: T("取消", "Cancel"))
        let allowed = alert.runModal() == .alertFirstButtonReturn
        if allowed { defaults.set(true, forKey: consentKey) }
        return allowed
    }
}
#endif
