import SwiftUI
import AppKit
import Combine

#if !ANNOTATION_TESTS
@main
#endif
struct SmartPDFReaderApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @StateObject private var localization = LocalizationManager.shared
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(localization)
                .environmentObject(appDelegate.windowManager)
                .handlesExternalEvents(preferring: Set(arrayLiteral: "*"), allowing: Set(arrayLiteral: "*"))
        }
        .handlesExternalEvents(matching: Set(arrayLiteral: "*"))
        .commands {
            // 移除默认的新建窗口命令
            CommandGroup(replacing: .newItem) { }
            
            // 文件菜单 - 保存命令
            CommandGroup(after: .newItem) {
                Button(L(.open)) {
                    NotificationCenter.default.post(name: .openPDFFile, object: nil)
                }
                .keyboardShortcut("o", modifiers: .command)
                
                Divider()
                
                Button(L(.save)) {
                    NotificationCenter.default.post(name: .savePDF, object: nil)
                }
                .keyboardShortcut("s", modifiers: .command)
                
                Button(L(.saveAs)) {
                    NotificationCenter.default.post(name: .saveAsPDF, object: nil)
                }
                .keyboardShortcut("s", modifiers: [.command, .shift])
            }
            
            // 编辑菜单 - 查找命令
            CommandGroup(after: .pasteboard) {
                Divider()
                
                Button(L(.search)) {
                    NotificationCenter.default.post(name: .toggleSearchBar, object: nil)
                }
                .keyboardShortcut("f", modifiers: .command)
            }
            
            // 撤销/重做命令
            CommandGroup(replacing: .undoRedo) {
                Button(L(.undo)) {
                    NotificationCenter.default.post(name: .performUndo, object: nil)
                }
                .keyboardShortcut("z", modifiers: .command)
                
                Button(L(.redo)) {
                    NotificationCenter.default.post(name: .performRedo, object: nil)
                }
                .keyboardShortcut("y", modifiers: .command)
                
                Divider()
            }
            
            // 窗口菜单 - 显示主窗口命令
            CommandGroup(after: .windowList) {
                Divider()
                
                Button(L(.showMainWindow)) {
                    NotificationCenter.default.post(name: .showMainWindow, object: nil)
                }
                .keyboardShortcut("0", modifiers: .command)
            }
            
            // 设置菜单
            CommandGroup(replacing: .appSettings) {
                SettingsLink { Text(L(.settings)) }
                .keyboardShortcut(",", modifiers: .command)
            }
        }
        
        // 定义设置场景
        Settings {
            SettingsView()
        }
    }
    
    func showSettingsWindow() {
        if #available(macOS 14.0, *) {
            NSApp.sendAction(Selector(("showSettingsWindow:")), to: nil, from: nil)
        } else {
            NSApp.sendAction(Selector(("showPreferencesWindow:")), to: nil, from: nil)
        }
    }
}

// MARK: - Window Manager
class WindowManager: ObservableObject {
    /// 通过外部打开（双击PDF文件）传入的URL
    @Published var externalPDFURL: URL?
    /// 标记窗口是否被隐藏（临时关闭）
    @Published var isWindowHidden: Bool = false
    /// 标记当前是否有已打开的PDF
    @Published var hasPDFOpen: Bool = false
    /// 标记是否是通过点击Dock图标重新激活
    @Published var isReopeningFromDock: Bool = false
    /// 保存主窗口的引用，用于恢复
    weak var mainWindow: NSWindow?
}

// MARK: - AppDelegate
class AppDelegate: NSObject, NSApplicationDelegate {
    
    // MARK: - 系统菜单栏状态项
    private var statusItem: NSStatusItem?
    private var popover: NSPopover?
    private var eventMonitor: Any?
    
    // AI 服务实例（共享给弹出窗口使用）
    let chatGPTService = ChatGPTService()
    
    // 窗口管理器
    let windowManager = WindowManager()
    
    // 存储待打开的PDF URL（用于启动时传入的文件）
    private var pendingPDFURL: URL?
    
    func applicationDidFinishLaunching(_ notification: Notification) {
        // 初始化菜单 - 多次尝试以确保菜单完全加载
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.updateMenuBar()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.updateMenuBar()
        }
        
        // 监听语言变化
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(languageDidChange),
            name: .languageDidChange,
            object: nil
        )
        
        // 监听显示主窗口命令
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(showMainWindow),
            name: .showMainWindow,
            object: nil
        )
        
        // 设置系统菜单栏图标
        setupStatusBarItem()
        
        // 如果有待处理的PDF URL，延迟发送
        if let url = pendingPDFURL {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                self.windowManager.externalPDFURL = url
                self.pendingPDFURL = nil
            }
        }
    }
    
    // MARK: - 显示主窗口
    @objc func showMainWindow() {
        // 优先使用保存的主窗口引用
        if let window = windowManager.mainWindow {
            windowManager.isWindowHidden = false
            window.makeKeyAndOrderFront(nil)
            NSApp.activate(ignoringOtherApps: true)
        } else {
            // 备用：遍历所有窗口查找主窗口
            for window in NSApp.windows {
                if !(window is NSPanel) && window.contentView != nil {
                    windowManager.mainWindow = window
                    windowManager.isWindowHidden = false
                    window.makeKeyAndOrderFront(nil)
                    NSApp.activate(ignoringOtherApps: true)
                    break
                }
            }
        }
    }
    
    // MARK: - 处理通过双击PDF文件打开应用
    func application(_ application: NSApplication, open urls: [URL]) {
        // 过滤出PDF文件
        let pdfURLs = urls.filter { $0.pathExtension.lowercased() == "pdf" }
        guard let firstPDF = pdfURLs.first else { return }
        
        // 如果窗口已存在，直接更新
        if let window = NSApp.windows.first(where: { $0.isVisible || !$0.isMiniaturized }) {
            windowManager.externalPDFURL = firstPDF
            windowManager.hasPDFOpen = true
            window.makeKeyAndOrderFront(nil)
            NSApp.activate(ignoringOtherApps: true)
        } else if NSApp.windows.isEmpty {
            // 应用刚启动，保存URL以便稍后处理
            pendingPDFURL = firstPDF
        } else {
            // 窗口被隐藏，需要重新显示
            if let window = NSApp.windows.first {
                windowManager.externalPDFURL = firstPDF
                windowManager.hasPDFOpen = true
                windowManager.isWindowHidden = false
                window.makeKeyAndOrderFront(nil)
                NSApp.activate(ignoringOtherApps: true)
            }
        }
    }
    
    // MARK: - 处理点击Dock图标（当应用已在运行但窗口被隐藏时）
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        if !flag {
            // 没有可见窗口，需要重新显示已隐藏的窗口
            // 优先使用保存的主窗口引用
            if let window = windowManager.mainWindow {
                windowManager.isWindowHidden = false
                windowManager.isReopeningFromDock = true
                window.makeKeyAndOrderFront(nil)
                NSApp.activate(ignoringOtherApps: true)
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    self.windowManager.isReopeningFromDock = false
                }
            } else {
                // 备用：遍历所有窗口查找主窗口
                for window in NSApp.windows {
                    if !(window is NSPanel) && window.contentView != nil {
                        windowManager.mainWindow = window
                        windowManager.isWindowHidden = false
                        windowManager.isReopeningFromDock = true
                        window.makeKeyAndOrderFront(nil)
                        NSApp.activate(ignoringOtherApps: true)
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            self.windowManager.isReopeningFromDock = false
                        }
                        break
                    }
                }
            }
        }
        // 返回 false 阻止系统创建新窗口
        return false
    }
    
    // MARK: - 窗口关闭时的处理（隐藏而不是退出）
    func applicationShouldTerminateAfterLastWindowClosed(_ application: NSApplication) -> Bool {
        // 返回 false，这样关闭最后一个窗口时不会退出应用
        return false
    }
    
    // MARK: - 设置系统菜单栏图标
    private func setupStatusBarItem() {
        // 创建状态栏项目
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        
        if let button = statusItem?.button {
            // 设置图标
            if let image = NSImage(named: "AIToolbarIcon") {
                image.size = NSSize(width: 18, height: 18)
                image.isTemplate = true // 使图标适应系统主题（深色/浅色模式）
                button.image = image
            } else {
                // 备用：使用SF Symbol
                button.image = NSImage(systemSymbolName: "brain.head.profile", accessibilityDescription: "AI Assistant")
            }
            
            button.action = #selector(togglePopover(_:))
            button.target = self
        }
        
        // 创建弹出窗口
        popover = NSPopover()
        popover?.contentSize = NSSize(width: 420, height: 520)
        popover?.behavior = .transient
        popover?.animates = true
        
        // 设置弹出窗口内容
        let contentView = MenuBarPopoverView(
            service: chatGPTService,
            closeAction: { [weak self] in
                self?.closePopover()
            }
        )
        popover?.contentViewController = NSHostingController(rootView: contentView)
        
        // 添加事件监听器，点击其他地方时关闭弹出窗口
        eventMonitor = NSEvent.addGlobalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown]) { [weak self] _ in
            if self?.popover?.isShown == true {
                self?.closePopover()
            }
        }
    }
    
    @objc func togglePopover(_ sender: AnyObject?) {
        if let popover = popover {
            if popover.isShown {
                closePopover()
            } else {
                showPopover()
            }
        }
    }
    
    private func showPopover() {
        if let button = statusItem?.button {
            popover?.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
            
            // 确保弹出窗口获得焦点
            NSApp.activate(ignoringOtherApps: true)
        }
    }
    
    private func closePopover() {
        popover?.performClose(nil)
    }
    
    func applicationWillTerminate(_ notification: Notification) {
        ChatGPTClient.shared.disconnect()
        // 移除事件监听器
        if let monitor = eventMonitor {
            NSEvent.removeMonitor(monitor)
        }
    }
    
    @objc func languageDidChange() {
        DispatchQueue.main.async {
            self.updateMenuBar()
        }
        // 延迟再次更新，确保所有菜单项都已更新
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.updateMenuBar()
        }
    }
    
    func updateMenuBar() {
        guard let mainMenu = NSApp.mainMenu else { return }
        
        // 更新应用菜单（第一个菜单）
        if mainMenu.items.count > 0 {
            let appMenu = mainMenu.items[0]
            updateAppMenu(appMenu.submenu)
        }
        
        // 更新文件菜单
        if let fileMenu = findMenuItem(in: mainMenu, withTitles: ["File", "文件"]) {
            fileMenu.title = L(.menuFile)
            updateFileMenu(fileMenu.submenu)
        }
        
        // 更新编辑菜单
        if let editMenu = findMenuItem(in: mainMenu, withTitles: ["Edit", "编辑"]) {
            editMenu.title = L(.menuEdit)
            updateEditMenu(editMenu.submenu)
        }
        
        // 更新视图菜单
        if let viewMenu = findMenuItem(in: mainMenu, withTitles: ["View", "视图"]) {
            viewMenu.title = L(.menuView)
            updateViewMenu(viewMenu.submenu)
        }
        
        // 更新窗口菜单
        if let windowMenu = findMenuItem(in: mainMenu, withTitles: ["Window", "窗口"]) {
            windowMenu.title = L(.menuWindow)
            updateWindowMenu(windowMenu.submenu)
        }
        
        // 更新帮助菜单
        if let helpMenu = findMenuItem(in: mainMenu, withTitles: ["Help", "帮助"]) {
            helpMenu.title = L(.menuHelp)
        }
    }
    
    private func findMenuItem(in menu: NSMenu, withTitles titles: [String]) -> NSMenuItem? {
        for title in titles {
            if let item = menu.item(withTitle: title) {
                return item
            }
        }
        // 如果按标题找不到，尝试按位置查找常见菜单
        return nil
    }
    
    private func updateAppMenu(_ submenu: NSMenu?) {
        guard let submenu = submenu else { return }
        
        for item in submenu.items {
            let title = item.title.lowercased()
            let actionString = item.action.map { NSStringFromSelector($0) } ?? ""
            
            if actionString.contains("about") || title.contains("about") || title.contains("关于") {
                // 获取应用名称
                let appName = L(.appName)
                item.title = "\(L(.about)) \(appName)"
            } else if actionString.contains("Preferences") || actionString.contains("Settings") ||
                      title.contains("preferences") || title.contains("settings") ||
                      title.contains("偏好设置") || title.contains("设置") {
                item.title = L(.settings)
            } else if actionString.contains("hide") && !actionString.contains("Others") {
                if title.contains("hide") || title.contains("隐藏") {
                    let appName = L(.appName)
                    item.title = LocalizationManager.currentLanguage == .chinese ? "隐藏 \(appName)" : "Hide \(appName)"
                }
            } else if actionString.contains("hideOthers") || title.contains("others") || title.contains("其他") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "隐藏其他" : "Hide Others"
            } else if actionString.contains("unhide") || title.contains("show all") || title.contains("显示全部") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "显示全部" : "Show All"
            } else if actionString.contains("terminate") || title.contains("quit") || title.contains("退出") {
                let appName = L(.appName)
                item.title = LocalizationManager.currentLanguage == .chinese ? "退出 \(appName)" : "Quit \(appName)"
            } else if title.contains("services") || title.contains("服务") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "服务" : "Services"
            }
        }
    }
    
    private func updateFileMenu(_ submenu: NSMenu?) {
        guard let submenu = submenu else { return }
        
        for item in submenu.items {
            let actionString = item.action.map { NSStringFromSelector($0) } ?? ""
            let title = item.title.lowercased()
            
            if actionString.contains("newDocument") || title.contains("new") && !title.contains("window") {
                item.title = L(.menuNew)
            } else if actionString.contains("openDocument") || (title.contains("open") && !title.contains("recent")) {
                item.title = L(.menuOpen)
            } else if actionString.contains("Close") || actionString.contains("close") || title.contains("close") || title.contains("关闭") {
                item.title = L(.menuClose)
            } else if title.contains("save as") || title.contains("另存") {
                item.title = L(.saveAs)
            } else if title.contains("save") || title.contains("保存") {
                if !title.contains("as") && !title.contains("另存") {
                    item.title = L(.save)
                }
            } else if title.contains("open") || title.contains("打开") {
                if !title.contains("recent") && !title.contains("最近") {
                    item.title = L(.open)
                }
            }
        }
    }
    
    private func updateEditMenu(_ submenu: NSMenu?) {
        guard let submenu = submenu else { return }
        
        for item in submenu.items {
            let actionString = item.action.map { NSStringFromSelector($0) } ?? ""
            let title = item.title.lowercased()
            
            if actionString.contains("undo") || title.contains("undo") || title.contains("撤销") {
                item.title = L(.undo)
            } else if actionString.contains("redo") || title.contains("redo") || title.contains("重做") {
                item.title = L(.redo)
            } else if actionString.contains("cut") || title.contains("cut") || title.contains("剪切") {
                item.title = L(.menuCut)
            } else if actionString.contains("copy") || title.contains("copy") || title.contains("复制") {
                item.title = L(.copy)
            } else if actionString.contains("paste") || title.contains("paste") || title.contains("粘贴") {
                item.title = L(.menuPaste)
            } else if actionString.contains("selectAll") || title.contains("select all") || title.contains("全选") {
                item.title = L(.menuSelectAll)
            } else if actionString.contains("delete") || title.contains("delete") || title.contains("删除") {
                item.title = L(.delete)
            } else if title.contains("find") || title.contains("查找") {
                item.title = L(.search)
                // 更新子菜单
                if let findSubmenu = item.submenu {
                    updateFindMenu(findSubmenu)
                }
            } else if title.contains("spelling") || title.contains("拼写") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "拼写和语法" : "Spelling and Grammar"
            } else if title.contains("substitutions") || title.contains("替换") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "替换" : "Substitutions"
            } else if title.contains("transformations") || title.contains("转换") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "转换" : "Transformations"
            } else if title.contains("speech") || title.contains("语音") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "语音" : "Speech"
            }
        }
    }
    
    private func updateFindMenu(_ submenu: NSMenu) {
        for item in submenu.items {
            let title = item.title.lowercased()
            
            if title.contains("find...") || title.contains("查找...") || title == "find" || title == "查找" {
                item.title = LocalizationManager.currentLanguage == .chinese ? "查找..." : "Find..."
            } else if title.contains("find and replace") || title.contains("查找和替换") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "查找和替换..." : "Find and Replace..."
            } else if title.contains("find next") || title.contains("查找下一个") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "查找下一个" : "Find Next"
            } else if title.contains("find previous") || title.contains("查找上一个") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "查找上一个" : "Find Previous"
            } else if title.contains("use selection") || title.contains("使用所选内容查找") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "使用所选内容查找" : "Use Selection for Find"
            } else if title.contains("jump to selection") || title.contains("跳转到所选内容") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "跳转到所选内容" : "Jump to Selection"
            }
        }
    }
    
    private func updateViewMenu(_ submenu: NSMenu?) {
        guard let submenu = submenu else { return }
        
        for item in submenu.items {
            let title = item.title.lowercased()
            let actionString = item.action.map { NSStringFromSelector($0) } ?? ""
            
            if title.contains("show toolbar") || title.contains("显示工具栏") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "显示工具栏" : "Show Toolbar"
            } else if title.contains("hide toolbar") || title.contains("隐藏工具栏") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "隐藏工具栏" : "Hide Toolbar"
            } else if title.contains("customize toolbar") || title.contains("自定义工具栏") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "自定义工具栏..." : "Customize Toolbar..."
            } else if title.contains("show sidebar") || title.contains("显示边栏") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "显示边栏" : "Show Sidebar"
            } else if title.contains("hide sidebar") || title.contains("隐藏边栏") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "隐藏边栏" : "Hide Sidebar"
            } else if actionString.contains("toggleFullScreen") || title.contains("full screen") || title.contains("全屏") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "进入全屏幕" : "Enter Full Screen"
            }
        }
    }
    
    private func updateWindowMenu(_ submenu: NSMenu?) {
        guard let submenu = submenu else { return }
        
        for item in submenu.items {
            let actionString = item.action.map { NSStringFromSelector($0) } ?? ""
            let title = item.title.lowercased()
            
            if actionString.contains("Miniaturize") || actionString.contains("miniaturize") ||
               title.contains("minimize") || title.contains("最小化") {
                item.title = L(.menuMinimize)
            } else if actionString.contains("Zoom") || actionString.contains("zoom") ||
                      title.contains("zoom") || title.contains("缩放") {
                item.title = L(.menuZoom)
            } else if actionString.contains("arrangeInFront") || title.contains("bring all to front") || title.contains("前置") {
                item.title = L(.menuBringAllToFront)
            } else if title.contains("tile window to left") || title.contains("将窗口拼贴到屏幕左侧") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "将窗口拼贴到屏幕左侧" : "Tile Window to Left of Screen"
            } else if title.contains("tile window to right") || title.contains("将窗口拼贴到屏幕右侧") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "将窗口拼贴到屏幕右侧" : "Tile Window to Right of Screen"
            } else if title.contains("replace tiled window") || title.contains("替换拼贴窗口") {
                item.title = LocalizationManager.currentLanguage == .chinese ? "替换拼贴窗口" : "Replace Tiled Window"
            } else if title.contains("move window to") || title.contains("将窗口移到") {
                // 这些项目可能有子菜单，保持原样或更新
            }
        }
    }
}

// MARK: - 新增通知名称
extension Notification.Name {
    static let performUndo = Notification.Name("performUndo")
    static let performRedo = Notification.Name("performRedo")
    static let languageDidChange = Notification.Name("languageDidChange")
    static let openPDFFile = Notification.Name("openPDFFile")
    static let showMainWindow = Notification.Name("showMainWindow")
}

// MARK: - LocalizationManager 扩展
extension LocalizationManager {
    static var currentLanguage: AppLanguage {
        return shared.currentLanguage
    }
}
