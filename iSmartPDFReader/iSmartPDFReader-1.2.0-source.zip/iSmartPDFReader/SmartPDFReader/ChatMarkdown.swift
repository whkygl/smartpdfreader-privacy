import Foundation

enum ChatMarkdown {
    struct Part: Identifiable {
        let id: Int
        let text: String
        let isCode: Bool
    }

    static func parts(_ text: String) -> [Part] {
        let lines = text.components(separatedBy: "\n")
        var result: [Part] = [], buffer: [String] = []
        var fence: String?
        func flush(_ code: Bool) {
            let body = buffer.joined(separator: "\n")
            if !body.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                result.append(Part(id: result.count, text: body, isCode: code))
            }
            buffer.removeAll()
        }
        for line in lines {
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            if let active = fence {
                if trimmed.hasPrefix(active) { flush(true); fence = nil }
                else { buffer.append(line) }
            } else if trimmed.hasPrefix("```") || trimmed.hasPrefix("~~~") {
                flush(false); fence = String(trimmed.prefix(3))
            } else { buffer.append(line) }
        }
        flush(fence != nil)
        return result
    }

    static func attributed(_ text: String) -> AttributedString {
        // Some responses escape BOTH ends of emphasis. Recover paired delimiters only;
        // preserve literal operators, underscores, backslashes and inline code.
        let segments = text.components(separatedBy: "`")
        var normalized = segments.enumerated().map { i, segment -> String in
            guard i % 2 == 0 else { return segment }
            return segment.replacingOccurrences(of: #"\\\*\\\*(.+?)\\\*\\\*"#, with: "**$1**", options: .regularExpression)
                .replacingOccurrences(of: #"\\_\\_(.+?)\\_\\_"#, with: "__$1__", options: .regularExpression)
        }.joined(separator: "`")
        normalized = normalized.replacingOccurrences(of: #"(?m)^#{1,6}\s+(.+)$"#, with: "**$1**", options: .regularExpression)
        normalized = normalized.replacingOccurrences(of: #"(?m)^([ \t]*)[-*+]\s+"#, with: "$1• ", options: .regularExpression)
        normalized = normalized.replacingOccurrences(of: #"(?m)^>\s?"#, with: "│ ", options: .regularExpression)
        normalized = normalized.replacingOccurrences(of: #"(?m)^\s*(?:[-*_]\s*){3,}$"#, with: "────────", options: .regularExpression)
        return (try? AttributedString(markdown: normalized, options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace))) ?? AttributedString(normalized)
    }

    static func plainText(_ text: String) -> String {
        parts(text).map { $0.isCode ? $0.text : String(attributed($0.text).characters) }.joined(separator: "\n\n")
    }
}
