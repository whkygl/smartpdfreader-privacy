#if APP_STORE
import Foundation
import AppKit
import CryptoKit
import Security
@preconcurrency import Network

enum PlanAuthError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let value) = self { return value }; return nil }
}

struct PlanCredentials: Codable {
    let clientID: String
    let subject: String
    let issuer: String
    let email: String
    let idToken: String
    let accessToken: String
    let refreshToken: String
    let scopes: [String]
    let expiresAt: Date
}

enum PlanOAuth {
    static let issuer = "https://auth.openai.com"
    static let resource = "https://api.openai.com/v1"
    static let scopes = "openid profile email offline_access resource.invoke chatgpt.tokens.use.direct"

    static func random() throws -> String {
        var bytes = [UInt8](repeating: 0, count: 32)
        guard SecRandomCopyBytes(kSecRandomDefault, bytes.count, &bytes) == errSecSuccess else {
            throw PlanAuthError.message(T("无法生成安全的登录请求。", "Could not create a secure sign-in request."))
        }
        return Data(bytes).base64URL
    }

    static func authorizationURL(hostID: String, redirect: String, state: String, nonce: String, verifier: String, previous: PlanCredentials?) -> URL {
        var values = ["client_id": previous?.clientID ?? "dynamic_agent_client", "ext_agent_host_id": hostID,
            "response_type": "code", "redirect_uri": redirect, "scope": scopes, "resource": resource,
            "state": state, "nonce": nonce, "code_challenge_method": "S256",
            "code_challenge": Data(SHA256.hash(data: Data(verifier.utf8))).base64URL]
        if let previous { values["id_token_hint"] = previous.idToken }
        else { values["agent_name_hint"] = "iSmartPDFReader" }
        var url = URLComponents(string: issuer + "/api/accounts/authorize")!
        url.queryItems = values.sorted { $0.key < $1.key }.map { URLQueryItem(name: $0.key, value: $0.value) }
        return url.url!
    }

    static func callback(_ url: URL, state: String, previous: PlanCredentials?) throws -> (code: String, clientID: String) {
        guard url.scheme == "http", url.host == "127.0.0.1", url.path == "/auth/callback",
              let items = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems else {
            throw PlanAuthError.message(T("登录回调无效。", "Invalid sign-in callback."))
        }
        // Reject duplicate parameters instead of silently choosing a conflicting value.
        var values: [String: String] = [:]
        for item in items {
            guard values[item.name] == nil else { throw PlanAuthError.message("Duplicate OAuth callback parameter") }
            values[item.name] = item.value ?? ""
        }
        guard values["state"] == state else { throw PlanAuthError.message(T("登录请求不匹配，请重试。", "Sign-in request did not match. Please retry.")) }
        guard values["error"] == nil else { throw PlanAuthError.message(T("未完成 ChatGPT 授权。", "ChatGPT authorization was not completed.")) }
        let clientID = values["client_id"] ?? previous?.clientID ?? ""
        guard clientID.hasPrefix("oaiapp_"), previous == nil || clientID == previous?.clientID,
              let code = values["code"], !code.isEmpty else {
            throw PlanAuthError.message(T("未收到有效的客户端授权，请重新登录。", "No valid client authorization was returned. Sign in again."))
        }
        return (code, clientID)
    }

    static func formRequest(path: String, values: [String: String]) -> URLRequest {
        var request = URLRequest(url: URL(string: issuer + path)!)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~")
        request.httpBody = values.sorted { $0.key < $1.key }.map {
            $0.key.addingPercentEncoding(withAllowedCharacters: allowed)! + "=" + $0.value.addingPercentEncoding(withAllowedCharacters: allowed)!
        }.joined(separator: "&").data(using: .utf8)
        return request
    }

    static func validateIDToken(_ token: String, clientID: String, nonce: String?, jwks: [String: Any], now: Date = Date()) throws -> [String: Any] {
        let parts = token.split(separator: ".", omittingEmptySubsequences: false).map(String.init)
        guard parts.count == 3,
              let headerData = Data(base64URL: parts[0]), let payload = Data(base64URL: parts[1]),
              let signature = Data(base64URL: parts[2]),
              let header = try JSONSerialization.jsonObject(with: headerData) as? [String: Any],
              let claims = try JSONSerialization.jsonObject(with: payload) as? [String: Any],
              header["alg"] as? String == "RS256", let keyID = header["kid"] as? String,
              let jwk = (jwks["keys"] as? [[String: Any]])?.first(where: { $0["kid"] as? String == keyID && $0["kty"] as? String == "RSA" }),
              jwk["alg"] == nil || jwk["alg"] as? String == "RS256",
              let n = jwk["n"] as? String, let e = jwk["e"] as? String,
              let modulus = Data(base64URL: n), let exponent = Data(base64URL: e) else {
            throw PlanAuthError.message(T("无法验证登录身份。", "Could not verify sign-in identity."))
        }
        let publicBytes = der(tag: 0x30, body: derInteger(modulus) + derInteger(exponent))
        guard let publicKey = SecKeyCreateWithData(publicBytes as CFData,
            [kSecAttrKeyType: kSecAttrKeyTypeRSA, kSecAttrKeyClass: kSecAttrKeyClassPublic] as CFDictionary, nil),
            SecKeyVerifySignature(publicKey, .rsaSignatureMessagePKCS1v15SHA256,
                Data((parts[0] + "." + parts[1]).utf8) as CFData, signature as CFData, nil) else {
            throw PlanAuthError.message(T("登录身份签名无效。", "Invalid sign-in identity signature."))
        }
        let audience = (claims["aud"] as? [String]) ?? (claims["aud"] as? String).map { [$0] } ?? []
        guard claims["iss"] as? String == issuer, audience.contains(clientID),
              audience.count == 1 || claims["azp"] as? String == clientID,
              let expiry = claims["exp"] as? TimeInterval, expiry > now.timeIntervalSince1970 - 30,
              let issued = claims["iat"] as? TimeInterval, issued <= now.timeIntervalSince1970 + 30,
              (claims["nbf"] as? TimeInterval ?? 0) <= now.timeIntervalSince1970 + 30,
              let subject = claims["sub"] as? String, !subject.isEmpty,
              nonce == nil || claims["nonce"] as? String == nonce else {
            throw PlanAuthError.message(T("登录身份已过期或与本次请求不匹配。", "Sign-in identity expired or did not match this request."))
        }
        return claims
    }

    private static func derInteger(_ input: Data) -> Data {
        var value = Data(input.drop(while: { $0 == 0 }))
        if value.isEmpty { value = Data([0]) }
        if let first = value.first, first & 0x80 != 0 { value.insert(0, at: 0) }
        return der(tag: 0x02, body: value)
    }
    private static func der(tag: UInt8, body: Data) -> Data {
        var length = body.count, bytes: [UInt8] = []
        if length < 128 { bytes = [UInt8(length)] }
        else {
            while length > 0 { bytes.insert(UInt8(length & 255), at: 0); length >>= 8 }
            bytes.insert(0x80 | UInt8(bytes.count), at: 0)
        }
        return Data([tag] + bytes) + body
    }
}

extension Data {
    var base64URL: String { base64EncodedString().replacingOccurrences(of: "+", with: "-").replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: "=", with: "") }
    init?(base64URL: String) {
        let base = base64URL.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        self.init(base64Encoded: base + String(repeating: "=", count: (4 - base.count % 4) % 4))
    }
}

/// A callback listener bound to IPv4 loopback only; it never exposes a local service to the LAN.
@MainActor final class PlanLoopbackListener {
    private let expectedState: String
    private var listener: NWListener?
    private var startWaiter: CheckedContinuation<UInt16, Error>?
    private var callbackWaiter: CheckedContinuation<URL, Error>?
    private var returnedURL: URL?
    private var stopped = false
    private var connections: [NWConnection] = []
    init(state: String) { expectedState = state }

    func start() async throws -> UInt16 {
        let parameters = NWParameters.tcp
        parameters.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: .any)
        let listener = try NWListener(using: parameters)
        self.listener = listener
        return try await withCheckedThrowingContinuation { continuation in
            startWaiter = continuation
            listener.stateUpdateHandler = { [weak self] state in
                Task { @MainActor in
                    guard let self else { return }
                    if case .ready = state, let port = listener.port {
                        self.startWaiter?.resume(returning: port.rawValue); self.startWaiter = nil
                    } else if case .failed(let error) = state { self.stop(error) }
                }
            }
            listener.newConnectionHandler = { [weak self] connection in
                Task { @MainActor in self?.accept(connection) }
            }
            listener.start(queue: .main)
        }
    }

    func callback() async throws -> URL {
        if let returnedURL { return returnedURL }
        if stopped { throw CancellationError() }
        return try await withCheckedThrowingContinuation { callbackWaiter = $0 }
    }

    func stop(_ error: Error = CancellationError()) {
        stopped = true
        listener?.cancel(); listener = nil
        for connection in connections { connection.cancel() }
        connections.removeAll()
        startWaiter?.resume(throwing: error); startWaiter = nil
        callbackWaiter?.resume(throwing: error); callbackWaiter = nil
    }

    private func accept(_ connection: NWConnection) {
        guard !stopped, connections.count < 8 else { connection.cancel(); return }
        connections.append(connection)
        connection.stateUpdateHandler = { [weak self, weak connection] state in
            Task { @MainActor in
                switch state {
                case .cancelled, .failed:
                    self?.connections.removeAll { $0 === connection }
                default: break
                }
            }
        }
        connection.start(queue: .main)
        Task { [weak connection] in
            try? await Task.sleep(nanoseconds: 10_000_000_000)
            connection?.cancel()
        }
        read(connection, bytes: Data())
    }

    private func read(_ connection: NWConnection, bytes: Data) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 8192) { [weak self] data, _, complete, error in
            Task { @MainActor in
                guard let self, !self.stopped else { return }
                let buffer = bytes + (data ?? Data())
                guard buffer.count <= 16_384, error == nil else { connection.cancel(); return }
                guard let headers = String(data: buffer, encoding: .utf8), headers.contains("\r\n\r\n") else {
                    if !complete { self.read(connection, bytes: buffer) } else { connection.cancel() }
                    return
                }
                let first = headers.components(separatedBy: "\r\n")[0].components(separatedBy: " ")
                guard first.count == 3, first[0] == "GET", first[1].hasPrefix("/auth/callback?"),
                      let port = self.listener?.port,
                      let url = URL(string: "http://127.0.0.1:\(port.rawValue)" + first[1]) else {
                    self.send(connection, status: "404 Not Found", body: "Not found", finished: nil); return
                }
                let items = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems ?? []
                guard self.returnedURL == nil, items.filter({ $0.name == "state" }).count == 1,
                      items.first(where: { $0.name == "state" })?.value == self.expectedState else {
                    self.send(connection, status: "400 Bad Request", body: "Invalid sign-in request", finished: nil); return
                }
                self.returnedURL = url
                let html = "<!doctype html><meta charset=utf-8><title>iSmartPDFReader</title><script>history.replaceState(null,'','/success')</script><h2>授权信息已返回阅读器</h2><p>请返回 iSmartPDFReader 查看登录结果。You may return to iSmartPDFReader.</p>"
                self.send(connection, status: "200 OK", body: html) { [weak self] in
                    guard let self else { return }
                    self.callbackWaiter?.resume(returning: url); self.callbackWaiter = nil
                }
            }
        }
    }

    private func send(_ connection: NWConnection, status: String, body: String, finished: (() -> Void)?) {
        let data = Data(body.utf8)
        let header = "HTTP/1.1 \(status)\r\nContent-Type: text/html; charset=utf-8\r\nCache-Control: no-store\r\nContent-Security-Policy: default-src 'none'; script-src 'unsafe-inline'\r\nContent-Length: \(data.count)\r\nConnection: close\r\n\r\n"
        connection.send(content: Data(header.utf8) + data, completion: .contentProcessed { [weak self] _ in
            Task { @MainActor in
                connection.cancel()
                self?.connections.removeAll { $0 === connection }
                finished?()
            }
        })
    }
}
#endif
