import SwiftUI
import PDFKit
import UniformTypeIdentifiers
import ObjectiveC

// MARK: - 📢 Notification Names
extension Notification.Name {
    static let toggleSearchBar = Notification.Name("toggleSearchBar")
    static let currentPageChanged = Notification.Name("currentPageChanged")
    static let savePDF = Notification.Name("savePDF")
    static let saveAsPDF = Notification.Name("saveAsPDF")
}

// MARK: - 🏠 Main Content View
struct ContentView: View {
    @State private var pdfURL: URL?
    @State private var pdfDocument: PDFDocument?
    @State private var documentAccess: ScopedFileAccess?
    @State private var extractionID = UUID()
    @StateObject private var aiService = ChatGPTService()
    @State private var showSidebar: Bool = false
    @ObservedObject private var localization = LocalizationManager.shared
    @EnvironmentObject var windowManager: WindowManager
    
    // MARK: - Left Sidebar State
    @State private var leftSidebarType: LeftSidebarType = .none
    
    // MARK: - Search State
    @State private var showSearchBar: Bool = false
    @State private var searchText: String = ""
    @FocusState private var isSearchFocused: Bool
    @State private var searchResultCount: Int = 0
    @State private var currentSearchIndex: Int = 0
    
    // MARK: - Page State
    @State private var currentPageIndex: Int = 0
    @State private var totalPages: Int = 0
    
    // MARK: - Animation State
    @State private var isHoveringOpenButton: Bool = false
    @State private var showWelcomeAnimation: Bool = false
    
    var body: some View {
        HSplitView {
            // 左侧区域
            HStack(spacing: 0) {
                // 左侧工具栏
                if pdfURL != nil {
                    LeftToolbarView(
                        selectedType: $leftSidebarType,
                        currentPage: currentPageIndex + 1,
                        totalPages: totalPages
                    )
                    .transition(.move(edge: .leading).combined(with: .opacity))
                    
                    // 左侧边栏内容
                    if leftSidebarType != .none {
                        LeftSidebarContainer(
                            pdfDocument: pdfDocument,
                            selectedType: $leftSidebarType
                        )
                        .transition(.asymmetric(
                            insertion: .move(edge: .leading).combined(with: .opacity),
                            removal: .move(edge: .leading).combined(with: .opacity)
                        ))
                        
                        // 分隔线
                        Rectangle()
                            .fill(
                                LinearGradient(
                                    colors: [Theme.Colors.borderSubtle, Theme.Colors.border.opacity(0.4), Theme.Colors.borderSubtle],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            )
                            .frame(width: 1)
                    }
                }
                
                // PDF视图区域
                ZStack(alignment: .topTrailing) {
                    if let url = pdfURL {
                        PDFKitView(url: url, aiService: aiService, pdfDocument: $pdfDocument)
                            .transition(.opacity)
                    } else {
                        WelcomeView(onOpenPDF: openPDF)
                            .transition(.opacity)
                    }
                    
                    // 搜索栏
                    if showSearchBar && pdfURL != nil {
                        SearchBarView(
                            searchText: $searchText,
                            isSearchFocused: _isSearchFocused,
                            resultCount: searchResultCount,
                            currentIndex: currentSearchIndex,
                            onPrevious: { triggerSearchAction(action: "prev") },
                            onNext: { triggerSearchAction(action: "next") },
                            onClose: closeSearchBar,
                            onSearch: { text in
                                triggerSearchAction(action: "search", text: text)
                            }
                        )
                        .padding(.top, 14)
                        .padding(.trailing, 18)
                        .transition(.asymmetric(
                            insertion: .move(edge: .top).combined(with: .opacity),
                            removal: .move(edge: .top).combined(with: .opacity)
                        ))
                    }
                }
                .frame(minWidth: 400, maxWidth: .infinity, maxHeight: .infinity)
            }
            .animation(Theme.Animation.spring, value: leftSidebarType)
            
            // ChatGPT 侧边栏
            if showSidebar {
                AIChatSidebar(aiService: aiService)
                    .frame(minWidth: 300, maxWidth: 480)
                    .transition(.move(edge: .trailing).combined(with: .opacity))
            }
            

        }
        .toolbar {
            ToolbarItem(placement: .automatic) {
                HStack(spacing: 14) {
                    // ChatGPT 阅读助手
                    ToolbarAIButton(isActive: showSidebar, isDisabled: false, provider: .chatgpt) {
                        withAnimation(Theme.Animation.spring) { showSidebar.toggle() }
                    }
                    
                    // 打开文件按钮
                    ToolbarOpenButton(action: openPDF)
                }
            }
        }
        .frame(minWidth: 900, minHeight: 600)
        .onChange(of: aiService.messages) {
            if !aiService.messages.isEmpty && !showSidebar {
                withAnimation(Theme.Animation.spring) {
                    showSidebar = true
                }
            }
        }
        .onChange(of: aiService.errorMessage) {
            if aiService.errorMessage != nil { showSidebar = true }
        }
        // 监听外部传入的PDF URL
        .onChange(of: windowManager.externalPDFURL) { oldValue, newValue in
            if let url = newValue {
                openPDFFromURL(url)
                // 清除，避免重复打开
                DispatchQueue.main.async {
                    windowManager.externalPDFURL = nil
                }
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .toggleSearchBar)) { _ in
            if pdfURL != nil {
                withAnimation(Theme.Animation.spring) {
                    showSearchBar = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        isSearchFocused = true
                    }
                }
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .currentPageChanged)) { notification in
            if let pageIndex = notification.userInfo?["pageIndex"] as? Int {
                currentPageIndex = pageIndex
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .openPDFFile)) { _ in
            openPDF()
        }
        .onAppear {
            withAnimation(Theme.Animation.smooth.delay(0.3)) {
                showWelcomeAnimation = true
            }
            // 设置窗口代理以拦截关闭事件
            setupWindowCloseHandler()
        }
        // 更新窗口管理器的状态
        .onChange(of: pdfURL) { oldValue, newValue in
            windowManager.hasPDFOpen = newValue != nil
        }
    }
    
    // MARK: - Setup Window Close Handler
    private func setupWindowCloseHandler() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            // 查找主窗口（排除 NSPanel、设置窗口等）
            if let window = NSApp.windows.first(where: { 
                $0.contentView != nil && 
                !($0 is NSPanel)
            }) {
                // 保存窗口引用到 WindowManager
                windowManager.mainWindow = window
                
                // 确保窗口关闭时不会被自动释放
                window.isReleasedWhenClosed = false
                
                // 设置窗口代理
                let delegate = WindowCloseDelegate(windowManager: windowManager)
                // 使用 UnsafeRawPointer 作为 key 保存代理引用防止被释放
                let key = UnsafeRawPointer(bitPattern: "windowDelegate".hashValue)!
                objc_setAssociatedObject(window, key, delegate, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
                window.delegate = delegate
            }
        }
    }
    
    // MARK: - Logic Methods
    
    /// 从URL直接打开PDF（用于外部传入）
    func openPDFFromURL(_ url: URL) {
        documentAccess = ScopedFileAccess(url)
        withAnimation(Theme.Animation.smooth) {
            self.pdfURL = url
            let doc = PDFDocument(url: url)
            self.pdfDocument = doc
            self.totalPages = doc?.pageCount ?? 0
            self.currentPageIndex = 0
            self.showSidebar = true
            self.leftSidebarType = .none
        }
        self.extractPDFContent(url: url)
        self.closeSearchBar()
    }
    
    func openPDF() {
        DispatchQueue.main.async {
            let panel = NSOpenPanel()
            panel.allowedContentTypes = [.pdf]
            panel.allowsMultipleSelection = false
            panel.canChooseDirectories = false
            panel.begin { response in
                if response == .OK, let url = panel.url {
                    self.openPDFFromURL(url)
                }
            }
        }
    }
    
    func extractPDFContent(url: URL) {
        let requestID = UUID()
        extractionID = requestID
        aiService.resetDocument()
        aiService.documentName = url.lastPathComponent
        aiService.isExtractingPDF = true
        let extractionAccess = ScopedFileAccess(url)
        DispatchQueue.global(qos: .userInitiated).async {
            defer { withExtendedLifetime(extractionAccess) {} }
            let document = PDFDocument(url: url)
            var fullText = ""
            if let document {
                for i in 0..<document.pageCount {
                    fullText += "\n[第 \(i + 1) 页 / Page \(i + 1)]\n" + (document.page(at: i)?.string ?? "")
                }
            }
            // Empty scanned PDFs should not look as though text extraction succeeded.
            let hasText = document?.string?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false
            DispatchQueue.main.async {
                guard extractionID == requestID else { return }
                aiService.pdfFullContent = hasText ? fullText : ""
                aiService.isExtractingPDF = false
                Task { try? await aiService.prepareConversation() }
                if document == nil { aiService.errorMessage = T("无法读取 PDF 文件。", "Could not read the PDF file.") }
            }
        }
    }

    func triggerSearchAction(action: String, text: String? = nil) {
        let searchTextToUse = text ?? self.searchText
        NotificationCenter.default.post(
            name: .findInPDF,
            object: nil,
            userInfo: ["action": action, "text": searchTextToUse]
        )
    }
    
    func closeSearchBar() {
        withAnimation(Theme.Animation.spring) {
            showSearchBar = false
        }
        searchText = ""
        triggerSearchAction(action: "clear", text: "")
    }
}

// MARK: - AI Provider Enum
enum AIProvider {
    case chatgpt
    var name: String { "ChatGPT" }
    var activeIcon: String { "bubble.left.and.bubble.right.fill" }
    var inactiveIcon: String { "bubble.left.and.bubble.right" }
    var color: Color { Theme.Colors.primary }
}

// MARK: - 🔧 Toolbar AI Button
struct ToolbarAIButton: View {
    let isActive: Bool
    let isDisabled: Bool
    var provider: AIProvider = .chatgpt
    let action: () -> Void
    @State private var isHovered = false
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 7) {
                ZStack {
                    if isActive {
                        Circle()
                            .fill(provider.color.opacity(0.15))
                            .frame(width: 22, height: 22)
                    }
                    
                    Image(systemName: isActive ? provider.activeIcon : provider.inactiveIcon)
                        .font(.system(size: 14, weight: isActive ? .semibold : .regular))
                        .foregroundStyle(isActive ? LinearGradient(colors: [provider.color, provider.color.opacity(0.7)], startPoint: .topLeading, endPoint: .bottomTrailing) : LinearGradient(colors: [.primary], startPoint: .leading, endPoint: .trailing))
                }
                
                Text(provider.name)
                    .font(Theme.Typography.captionMedium)
                    .foregroundColor(isActive ? provider.color : .primary)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(
                RoundedRectangle(cornerRadius: Theme.Radius.button)
                    .fill(isActive ? provider.color.opacity(0.1) : (isHovered ? Theme.Colors.surface : Color.clear))
            )
            .overlay(
                RoundedRectangle(cornerRadius: Theme.Radius.button)
                    .stroke(isActive ? provider.color.opacity(0.25) : (isHovered ? Theme.Colors.borderLight : Color.clear), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .disabled(isDisabled)
        .opacity(isDisabled ? 0.5 : 1)
        .help(L(.openCloseSidebar))
        .onHover { isHovered = $0 }
        .scaleEffect(isHovered && !isDisabled ? 1.02 : 1.0)
        .animation(Theme.Animation.springQuick, value: isHovered)
    }
}

// MARK: - 🔧 Toolbar Open Button
struct ToolbarOpenButton: View {
    let action: () -> Void
    @State private var isHovered = false
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 7) {
                Image(systemName: "folder.badge.plus")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(isHovered ? Theme.Colors.gradientPrimary : LinearGradient(colors: [.primary], startPoint: .leading, endPoint: .trailing))
                
                Text(L(.open))
                    .font(Theme.Typography.captionMedium)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(
                RoundedRectangle(cornerRadius: Theme.Radius.button)
                    .fill(isHovered ? Theme.Colors.surface : Theme.Colors.surface.opacity(0.5))
            )
            .overlay(
                RoundedRectangle(cornerRadius: Theme.Radius.button)
                    .stroke(isHovered ? Theme.Colors.borderLight : Theme.Colors.borderSubtle, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .help(L(.open))
        .onHover { isHovered = $0 }
        .scaleEffect(isHovered ? 1.02 : 1.0)
        .animation(Theme.Animation.springQuick, value: isHovered)
    }
}

// MARK: - 🔍 Premium Search Bar
struct SearchBarView: View {
    @Binding var searchText: String
    @FocusState var isSearchFocused: Bool
    var resultCount: Int
    var currentIndex: Int
    var onPrevious: () -> Void
    var onNext: () -> Void
    var onClose: () -> Void
    var onSearch: (String) -> Void
    
    @State private var isHovered: Bool = false
    
    var body: some View {
        HStack(spacing: 12) {
            // 搜索图标
            Image(systemName: "magnifyingglass")
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(Theme.Colors.gradientPrimary)
            
            // 输入框
            TextField(L(.searchPlaceholder), text: $searchText)
                .textFieldStyle(.plain)
                .font(Theme.Typography.body)
                .frame(width: 180)
                .focused($isSearchFocused)
                .onSubmit { onNext() }
                .onChange(of: searchText) { _, newValue in
                    onSearch(newValue)
                }
            
            // 结果计数
            if resultCount > 0 {
                Text("\(currentIndex)/\(resultCount)")
                    .font(Theme.Typography.captionMedium)
                    .foregroundColor(Theme.Colors.primary)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(
                        Capsule()
                            .fill(Theme.Colors.primary.opacity(0.12))
                    )
            }
            
            // 分隔线
            Capsule()
                .fill(Theme.Colors.borderLight)
                .frame(width: 1, height: 20)
            
            // 导航按钮
            HStack(spacing: 6) {
                SearchNavButton(icon: "chevron.up", action: onPrevious)
                SearchNavButton(icon: "chevron.down", action: onNext)
            }
            
            // 分隔线
            Capsule()
                .fill(Theme.Colors.borderLight)
                .frame(width: 1, height: 20)
            
            // 关闭按钮
            Button(action: onClose) {
                Image(systemName: "xmark")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(Theme.Colors.textSecondary)
                    .frame(width: 24, height: 24)
                    .background(
                        Circle()
                            .fill(Theme.Colors.surface)
                    )
            }
            .buttonStyle(.plain)
            .help(L(.done))
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(
            ZStack {
                RoundedRectangle(cornerRadius: Theme.Radius.xl)
                    .fill(.ultraThinMaterial)
                RoundedRectangle(cornerRadius: Theme.Radius.xl)
                    .fill(Color.white.opacity(0.7))
            }
        )
        .overlay(
            RoundedRectangle(cornerRadius: Theme.Radius.xl)
                .stroke(
                    LinearGradient(
                        colors: [Color.white.opacity(0.6), Color.white.opacity(0.2)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: 1
                )
        )
        .shadow(color: .black.opacity(0.08), radius: 16, x: 0, y: 6)
        .shadow(color: Theme.Colors.primary.opacity(0.05), radius: 24, x: 0, y: 10)
        .scaleEffect(isHovered ? 1.01 : 1.0)
        .animation(Theme.Animation.springQuick, value: isHovered)
        .onHover { isHovered = $0 }
    }
}

// MARK: - Search Nav Button
struct SearchNavButton: View {
    let icon: String
    let action: () -> Void
    @State private var isHovered = false
    
    var body: some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 11, weight: .bold))
                .foregroundColor(isHovered ? Theme.Colors.primary : Theme.Colors.textSecondary)
                .frame(width: 26, height: 26)
                .background(
                    Circle()
                        .fill(isHovered ? Theme.Colors.primary.opacity(0.12) : Theme.Colors.surface)
                )
        }
        .buttonStyle(.plain)
        .onHover { isHovered = $0 }
        .scaleEffect(isHovered ? 1.08 : 1.0)
        .animation(Theme.Animation.springQuick, value: isHovered)
    }
}

// MARK: - 🎉 Premium Welcome View
struct WelcomeView: View {
    var onOpenPDF: () -> Void
    @State private var isAnimating: Bool = false
    @State private var isHoveringButton: Bool = false
    @State private var pulseAnimation: Bool = false
    @ObservedObject private var localization = LocalizationManager.shared
    
    var body: some View {
        ZStack {
            // 动态背景
            AnimatedMeshGradient(intensity: 0.5)
                .ignoresSafeArea()
            
            // 装饰性光球
            FloatingOrb(color: Theme.Colors.accent, size: 120)
                .offset(x: 200, y: -150)
                .opacity(0.6)
            
            FloatingOrb(color: Theme.Colors.secondary, size: 80)
                .offset(x: -180, y: 180)
                .opacity(0.5)
            
            VStack(spacing: Theme.Spacing.xxl) {
                Spacer()
                
                // 图标区域
                ZStack {
                    // 外圈脉冲
                    Circle()
                        .stroke(Theme.Colors.primary.opacity(0.15), lineWidth: 2)
                        .frame(width: 180, height: 180)
                        .scaleEffect(pulseAnimation ? 1.15 : 1.0)
                        .opacity(pulseAnimation ? 0 : 0.4)
                    
                    // 中圈光晕
                    Circle()
                        .fill(
                            RadialGradient(
                                colors: [Theme.Colors.primary.opacity(0.12), Theme.Colors.primary.opacity(0)],
                                center: .center,
                                startRadius: 40,
                                endRadius: 100
                            )
                        )
                        .frame(width: 200, height: 200)
                        .scaleEffect(isAnimating ? 1.1 : 0.95)
                    
                    // 主图标容器
                    ZStack {
                        Circle()
                            .fill(
                                LinearGradient(
                                    colors: [
                                        Theme.Colors.primary.opacity(0.12),
                                        Theme.Colors.secondary.opacity(0.06)
                                    ],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .frame(width: 130, height: 130)
                            .overlay(
                                Circle()
                                    .stroke(Theme.Colors.primary.opacity(0.15), lineWidth: 1)
                            )
                        
                        Image(systemName: "doc.text.viewfinder")
                            .font(.system(size: 52, weight: .light))
                            .foregroundStyle(Theme.Colors.gradientPrimary)
                            .shadow(color: Theme.Colors.primary.opacity(0.25), radius: 12, x: 0, y: 6)
                    }
                    .scaleEffect(isAnimating ? 1.0 : 0.96)
                }
                
                // 标题区域
                VStack(spacing: Theme.Spacing.md) {
                    Text(L(.pdfSmartReader))
                        .font(Theme.Typography.largeTitle)
                        .foregroundStyle(Theme.Colors.gradientPrimary)
                    
                    Text(L(.welcomeSubtitle))
                        .font(Theme.Typography.body)
                        .foregroundColor(Theme.Colors.textSecondary)
                        .multilineTextAlignment(.center)
                        .lineLimit(2)
                }
                .padding(.horizontal, Theme.Spacing.xxxl)
                
                // 打开按钮
                Button(action: onOpenPDF) {
                    HStack(spacing: Theme.Spacing.sm) {
                        Image(systemName: "folder.badge.plus")
                            .font(.system(size: 17, weight: .semibold))
                        Text(L(.openPDFFile))
                            .font(Theme.Typography.headline)
                    }
                    .foregroundColor(.white)
                    .padding(.horizontal, Theme.Spacing.xxl)
                    .padding(.vertical, Theme.Spacing.md)
                    .background(
                        ZStack {
                            Capsule()
                                .fill(Theme.Colors.gradientPrimary)
                            
                            Capsule()
                                .fill(
                                    LinearGradient(
                                        colors: [Color.white.opacity(0.2), Color.clear],
                                        startPoint: .top,
                                        endPoint: .center
                                    )
                                )
                        }
                        .shadow(
                            color: Theme.Colors.primary.opacity(isHoveringButton ? 0.5 : 0.3),
                            radius: isHoveringButton ? 18 : 12,
                            x: 0,
                            y: isHoveringButton ? 8 : 5
                        )
                    )
                    .overlay(
                        Capsule()
                            .stroke(Color.white.opacity(0.25), lineWidth: 1)
                    )
                    .scaleEffect(isHoveringButton ? 1.04 : 1.0)
                }
                .buttonStyle(.plain)
                .onHover { hovering in
                    withAnimation(Theme.Animation.springQuick) {
                        isHoveringButton = hovering
                    }
                }
                .padding(.top, Theme.Spacing.lg)
                
                // 快捷键提示
                HStack(spacing: Theme.Spacing.xs) {
                    KeyboardShortcutBadge(keys: ["⌘", "O"])
                    Text(L(.quickOpenHint))
                        .font(Theme.Typography.caption)
                        .foregroundColor(Theme.Colors.textTertiary)
                }
                .padding(.top, Theme.Spacing.sm)
                
                Spacer()
                
                // 底部功能提示
                HStack(spacing: Theme.Spacing.xxxxl) {
                    FeatureHintView(icon: "highlighter", title: L(.featureHighlight), color: Theme.Colors.accent)
                    FeatureHintView(icon: "sparkles", title: L(.featureAI), color: Theme.Colors.primary)
                    FeatureHintView(icon: "bubble.left.and.bubble.right", title: L(.featureNote), color: Theme.Colors.secondary)
                }
                .padding(.bottom, Theme.Spacing.xxxl)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onAppear {
            withAnimation(Animation.easeInOut(duration: 3).repeatForever(autoreverses: true)) {
                isAnimating = true
            }
            withAnimation(Animation.easeOut(duration: 2).repeatForever(autoreverses: false)) {
                pulseAnimation = true
            }
        }
    }
}

// MARK: - ⌨️ Keyboard Shortcut Badge
struct KeyboardShortcutBadge: View {
    var keys: [String]
    
    var body: some View {
        HStack(spacing: 4) {
            ForEach(keys, id: \.self) { key in
                Text(key)
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .foregroundColor(Theme.Colors.textSecondary)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 3)
                    .background(
                        RoundedRectangle(cornerRadius: 5)
                            .fill(Theme.Colors.surface)
                            .overlay(
                                RoundedRectangle(cornerRadius: 5)
                                    .stroke(Theme.Colors.borderLight, lineWidth: 1)
                            )
                            .shadow(color: .black.opacity(0.04), radius: 2, x: 0, y: 1)
                    )
            }
        }
    }
}

// MARK: - 🎯 Feature Hint View
struct FeatureHintView: View {
    var icon: String
    var title: String
    var color: Color = Theme.Colors.primary
    @State private var isHovered: Bool = false
    
    var body: some View {
        VStack(spacing: Theme.Spacing.sm) {
            ZStack {
                Circle()
                    .fill(color.opacity(0.1))
                    .frame(width: 52, height: 52)
                    .overlay(
                        Circle()
                            .stroke(color.opacity(0.15), lineWidth: 1)
                    )
                
                Image(systemName: icon)
                    .font(.system(size: 20, weight: .medium))
                    .foregroundColor(color)
            }
            .scaleEffect(isHovered ? 1.12 : 1.0)
            .shadow(color: isHovered ? color.opacity(0.2) : .clear, radius: 8, x: 0, y: 4)
            
            Text(title)
                .font(Theme.Typography.caption)
                .foregroundColor(Theme.Colors.textSecondary)
        }
        .onHover { hovering in
            withAnimation(Theme.Animation.springQuick) {
                isHovered = hovering
            }
        }
    }
}

// MARK: - 🪟 Window Close Delegate
class WindowCloseDelegate: NSObject, NSWindowDelegate {
    weak var windowManager: WindowManager?
    private var isExitingFullScreen: Bool = false
    
    init(windowManager: WindowManager) {
        self.windowManager = windowManager
        super.init()
    }
    
    func windowShouldClose(_ sender: NSWindow) -> Bool {
        // 确保窗口关闭时不会被释放
        sender.isReleasedWhenClosed = false
        
        // 检查是否处于全屏状态
        let isFullScreen = sender.styleMask.contains(.fullScreen)
        
        if isFullScreen && !isExitingFullScreen {
            // 如果在全屏状态，先退出全屏再隐藏窗口
            isExitingFullScreen = true
            sender.toggleFullScreen(nil)
            // 延迟隐藏窗口，等待退出全屏动画完成
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { [weak self] in
                self?.windowManager?.isWindowHidden = true
                sender.orderOut(nil)
                self?.isExitingFullScreen = false
            }
        } else if !isExitingFullScreen {
            // 非全屏状态，直接隐藏
            windowManager?.isWindowHidden = true
            sender.orderOut(nil)
        }
        
        return false // 返回 false 阻止窗口真正关闭
    }
    
    func windowWillClose(_ notification: Notification) {
        // 窗口即将关闭时的处理（仅在真正退出时调用）
    }
    
    func windowDidExitFullScreen(_ notification: Notification) {
        // 退出全屏完成后的回调
        if isExitingFullScreen, let window = notification.object as? NSWindow {
            windowManager?.isWindowHidden = true
            window.orderOut(nil)
            isExitingFullScreen = false
        }
    }
}
