
import SwiftUI
import Combine

// MARK: - 语言类型
enum AppLanguage: String, CaseIterable {
    case chinese = "zh"
    case english = "en"
    
    var displayName: String {
        switch self {
        case .chinese: return "中文"
        case .english: return "English"
        }
    }
}

// MARK: - 本地化管理器
@MainActor
final class LocalizationManager: ObservableObject {
    static let shared = LocalizationManager()
    
    @AppStorage("appLanguage") private var storedLanguage: String = "zh"
    
    @Published var currentLanguage: AppLanguage = .chinese
    
    private init() {
        currentLanguage = AppLanguage(rawValue: storedLanguage) ?? .chinese
    }
    
    func setLanguage(_ language: AppLanguage) {
        storedLanguage = language.rawValue
        currentLanguage = language
        objectWillChange.send()
        
        // 发送语言变化通知，用于更新菜单栏
        NotificationCenter.default.post(name: .languageDidChange, object: nil)
    }
    
    // MARK: - 本地化字符串
    func localized(_ key: LocalizedKey) -> String {
        return key.text(for: currentLanguage)
    }
}

// MARK: - 本地化键值
enum LocalizedKey: String {
    // 通用
    case appName
    case save
    case saveAs
    case cancel
    case delete
    case edit
    case settings
    case search
    case done
    case refresh
    case copy
    case copied
    case noContent
    
    // 页码相关
    case pageIndicator // "页 %d / %d"
    
    // 左侧边栏
    case outline
    case thumbnail
    case annotation
    case noOutline
    case noThumbnail
    case noAnnotation
    case page
    case annotationCount
    case unnamed
    
    // 批注类型
    case highlight
    case underline
    case strikeout
    case note
    case text
    case freeText
    case ink
    case rectangle
    case ellipse
    case line
    case selectedArea
    
    // PDF 相关
    case pdfSmartReader
    case welcomeSubtitle
    case openPDFFile
    case quickOpenHint
    case featureHighlight
    case featureAI
    case featureNote
    case aiAssistant
    case open
    case find
    case previous
    case next
    case previewMode
    
    // 设置
    case languageSettings
    case selectLanguage
    
    // 菜单项
    case editText
    case changeColor
    case fontSize
    case deleteText
    case deleteShape
    case deleteNote
    case addNoteToShape
    case addNote
    case addText
    case addShape
    case editNote
    case deleteHighlight
    case deleteUnderline
    
    // 形状
    case shapeLine
    case shapeArrow
    case shapeRect
    case shapeEllipse
    
    // AI
    case pdfLoaded
    case pdfLoadedMessage
    case translate
    
    // 颜色
    case colorYellow
    case colorGreen
    case colorBlue
    case colorRed
    case colorPurple
    case colorOrange
    case colorCyan
    
    // 字号
    case fontExtraSmall
    case fontSmall
    case fontSlightlySmall
    case fontMedium
    case fontStandard
    case fontSlightlyLarge
    case fontLarge
    case fontExtraLarge
    case fontHuge
    
    // 保存相关
    case fileSaved
    case fileSaveError
    case saveSuccess
    case saveError
    case saveAsPrompt
    case cancelButton
    
    // 撤销/重做
    case undo
    case redo
    
    // 浮动菜单和右键菜单
    case copyTooltip
    case highlightTooltip
    case underlineTooltip
    case addNoteTooltip
    case translateTooltip
    case openCloseSidebar
    
    // 搜索栏
    case searchPlaceholder
    case previousResult
    case nextResult
    
    // 粗细
    case lineWidth
    
    // AI 聊天侧边栏
    case aiSmartAssistant
    case clearHistory
    case modelLabel
    case geminiAssistant
    case aiWelcomeMessage
    case selectedPDFContext
    case inputPlaceholder
    case pasteImageFromClipboard
    case pasteImageTooltip
    case unsupportedPasteFormat
    case you
    case assistant
    
    // 菜单栏
    case menuFile
    case menuEdit
    case menuView
    case menuWindow
    case menuHelp
    case menuNew
    case menuOpen
    case menuClose
    case menuCut
    case menuPaste
    case menuSelectAll
    case menuMinimize
    case menuZoom
    case menuBringAllToFront
    
    // 关于
    case about
    
    // 批注显示/隐藏
    case showAllAnnotations
    case hideAllAnnotations
    case toggleAllAnnotations
    
    // 账号相关
    
    // 窗口相关
    case showMainWindow
    
    func text(for language: AppLanguage) -> String {
        switch language {
        case .chinese:
            return chineseText
        case .english:
            return englishText
        }
    }
    
    private var chineseText: String {
        switch self {
        case .appName: return "PDF 智能阅读器"
        case .save: return "保存"
        case .saveAs: return "另存为..."
        case .cancel: return "取消"
        case .delete: return "删除"
        case .edit: return "编辑"
        case .settings: return "偏好设置..."
        case .search: return "查找..."
        case .done: return "完成"
        case .refresh: return "刷新"
        case .copy: return "复制"
        case .copied: return "已复制"
        case .noContent: return "无内容"
        case .pageIndicator: return "页"
        case .outline: return "大纲"
        case .thumbnail: return "缩略图"
        case .annotation: return "批注"
        case .noOutline: return "无大纲"
        case .noThumbnail: return "暂无缩略图"
        case .noAnnotation: return "无批注"
        case .page: return "第 %d 页"
        case .annotationCount: return "%d 条"
        case .unnamed: return "未命名"
        case .highlight: return "高亮"
        case .underline: return "下划线"
        case .strikeout: return "删除线"
        case .note: return "批注"
        case .text: return "批注"
        case .freeText: return "文本"
        case .ink: return "手写"
        case .rectangle: return "矩形"
        case .ellipse: return "椭圆"
        case .line: return "线条"
        case .selectedArea: return "选中区域"
        case .pdfSmartReader: return "PDF 智能阅读器"
        case .welcomeSubtitle: return "高效阅读与批注，支持 AI 提问"
        case .openPDFFile: return "打开 PDF 文件"
        case .quickOpenHint: return "快速打开：拖入 PDF 或按 ⌘O"
        case .featureHighlight: return "支持高亮/下划线/图形批注，并可与 AI 联动提问"
        case .featureAI: return "支持基于选中文本/批注/图片的 AI 多模态问答"
        case .featureNote: return "支持为高亮/下划线/图形添加批注并快速检索"
        case .aiAssistant: return "AI 助手"
        case .open: return "打开"
        case .find: return "查找..."
        case .previous: return "上一个"
        case .next: return "下一个"
        case .previewMode: return "预览模式"
        case .languageSettings: return "语言设置"
        case .selectLanguage: return "选择语言"
        case .editText: return "✏️ 编辑文本"
        case .changeColor: return "🎨 更改配色"
        case .fontSize: return "🔠 字号"
        case .deleteText: return "🗑️ 删除文本"
        case .deleteShape: return "🗑️ 删除图形"
        case .deleteNote: return "🗑️ 删除批注"
        case .addNoteToShape: return "📝 为图形添加批注"
        case .addNote: return "📝 添加批注"
        case .addText: return "T  添加文本"
        case .addShape: return "⬚ 添加图形"
        case .editNote: return "✏️ 编辑批注"
        case .deleteHighlight: return "🗑️ 删除高亮"
        case .deleteUnderline: return "🗑️ 删除下划线"
        case .shapeLine: return "线条"
        case .shapeArrow: return "箭头"
        case .shapeRect: return "矩形"
        case .shapeEllipse: return "椭圆形"
        case .pdfLoaded: return "已加载 PDF 内容，您可以向我提问了！"
        case .pdfLoadedMessage: return "PDF已加载，可以开始提问。"
        case .translate: return "请翻译以下内容：\n\n"
        case .colorYellow: return "黄色"
        case .colorGreen: return "绿色"
        case .colorBlue: return "蓝色"
        case .colorRed: return "红色"
        case .colorPurple: return "紫色"
        case .colorOrange: return "橙色"
        case .colorCyan: return "青色"
        case .fontExtraSmall: return "特小 10"
        case .fontSmall: return "小 12"
        case .fontSlightlySmall: return "偏小 14"
        case .fontMedium: return "中 16"
        case .fontStandard: return "标准 18"
        case .fontSlightlyLarge: return "偏大 20"
        case .fontLarge: return "大 24"
        case .fontExtraLarge: return "特大 28"
        case .fontHuge: return "超大 32"
        case .fileSaved: return "文件已保存"
        case .fileSaveError: return "保存失败"
        case .saveSuccess: return "保存成功"
        case .saveError: return "保存出错"
        case .saveAsPrompt: return "请尝试使用“另存为”保存到其他位置。"
        case .cancelButton: return "取消"
        case .undo: return "撤销"
        case .redo: return "重做"
        case .copyTooltip: return "复制"
        case .highlightTooltip: return "高亮"
        case .underlineTooltip: return "下划线"
        case .addNoteTooltip: return "添加批注"
        case .translateTooltip: return "翻译"
        case .openCloseSidebar: return "打开/关闭 AI 助手"
        case .searchPlaceholder: return "查找..."
        case .previousResult: return "上一个"
        case .nextResult: return "下一个"
        case .lineWidth: return "🖊 更改粗细"
        case .aiSmartAssistant: return "AI 智能助手"
        case .clearHistory: return "清空对话历史"
        case .modelLabel: return "模型:"
        case .geminiAssistant: return "ChatGPT 阅读助手"
        case .aiWelcomeMessage: return "您可以：\n1. 选中 PDF 文字进行提问\n2. 粘贴或拖入图片进行分析"
        case .selectedPDFContext: return "已选中 PDF 上下文"
        case .inputPlaceholder: return "输入问题 (支持拖入图片)..."
        case .pasteImageFromClipboard: return "从剪贴板粘贴图片"
        case .pasteImageTooltip: return "粘贴图片"
        case .unsupportedPasteFormat: return "粘贴格式不支持，请直接粘贴图片"
        case .you: return "你"
        case .assistant: return "助手"
        case .menuFile: return "文件"
        case .menuEdit: return "编辑"
        case .menuView: return "视图"
        case .menuWindow: return "窗口"
        case .menuHelp: return "帮助"
        case .menuNew: return "新建"
        case .menuOpen: return "打开..."
        case .menuClose: return "关闭"
        case .menuCut: return "剪切"
        case .menuPaste: return "粘贴"
        case .menuSelectAll: return "全选"
        case .menuMinimize: return "最小化"
        case .menuZoom: return "缩放"
        case .menuBringAllToFront: return "前置全部窗口"
        case .about: return "关于"
        case .showAllAnnotations: return "📝 显示所有批注"
        case .hideAllAnnotations: return "📝 隐藏所有批注"
        case .toggleAllAnnotations: return "📝 显示/隐藏所有批注"
        case .showMainWindow: return "显示主窗口"
        }
    }
    
    private var englishText: String {
        switch self {
        case .appName: return "Smart PDF Reader"
        case .save: return "Save"
        case .saveAs: return "Save As..."
        case .cancel: return "Cancel"
        case .delete: return "Delete"
        case .edit: return "Edit"
        case .settings: return "Preferences..."
        case .search: return "Find..."
        case .done: return "Done"
        case .refresh: return "Refresh"
        case .copy: return "Copy"
        case .copied: return "Copied"
        case .noContent: return "No Content"
        case .pageIndicator: return "Page"
        case .outline: return "Outline"
        case .thumbnail: return "Thumbnails"
        case .annotation: return "Annotations"
        case .noOutline: return "No Outline"
        case .noThumbnail: return "No thumbnails"
        case .noAnnotation: return "No Annotations"
        case .page: return "Page %d"
        case .annotationCount: return "%d items"
        case .unnamed: return "Unnamed"
        case .highlight: return "Highlight"
        case .underline: return "Underline"
        case .strikeout: return "Strikeout"
        case .note: return "Note"
        case .text: return "Note"
        case .freeText: return "Text"
        case .ink: return "Ink"
        case .rectangle: return "Rectangle"
        case .ellipse: return "Ellipse"
        case .line: return "Line"
        case .selectedArea: return "Selected Area"
        case .pdfSmartReader: return "Smart PDF Reader"
        case .welcomeSubtitle: return "Read, annotate, and ask AI questions"
        case .openPDFFile: return "Open PDF File"
        case .quickOpenHint: return "Quick open: drag a PDF here or press ⌘O"
        case .featureHighlight: return "Highlight, underline, and draw shapes—then ask AI with context"
        case .featureAI: return "Ask AI with selected text, annotations, and images (multimodal)"
        case .featureNote: return "Add notes to highlights/shapes and quickly find them"
        case .aiAssistant: return "AI Assistant"
        case .open: return "Open"
        case .find: return "Find..."
        case .previous: return "Previous"
        case .next: return "Next"
        case .previewMode: return "Preview Mode"
        case .languageSettings: return "Language Settings"
        case .selectLanguage: return "Select Language"
        case .editText: return "✏️ Edit Text"
        case .changeColor: return "🎨 Change Color"
        case .fontSize: return "🔠 Font Size"
        case .deleteText: return "🗑️ Delete Text"
        case .deleteShape: return "🗑️ Delete Shape"
        case .deleteNote: return "🗑️ Delete Note"
        case .addNoteToShape: return "📝 Add Note to Shape"
        case .addNote: return "📝 Add Note"
        case .addText: return "T  Add Text"
        case .addShape: return "⬚ Add Shape"
        case .editNote: return "✏️ Edit Note"
        case .deleteHighlight: return "🗑️ Delete Highlight"
        case .deleteUnderline: return "🗑️ Delete Underline"
        case .shapeLine: return "Line"
        case .shapeArrow: return "Arrow"
        case .shapeRect: return "Rectangle"
        case .shapeEllipse: return "Ellipse"
        case .pdfLoaded: return "PDF loaded. You can ask me questions now!"
        case .pdfLoadedMessage: return "PDF loaded. You can start asking questions."
        case .translate: return "Please translate the following:\n\n"
        case .colorYellow: return "Yellow"
        case .colorGreen: return "Green"
        case .colorBlue: return "Blue"
        case .colorRed: return "Red"
        case .colorPurple: return "Purple"
        case .colorOrange: return "Orange"
        case .colorCyan: return "Cyan"
        case .fontExtraSmall: return "Extra Small 10"
        case .fontSmall: return "Small 12"
        case .fontSlightlySmall: return "Slightly Small 14"
        case .fontMedium: return "Medium 16"
        case .fontStandard: return "Standard 18"
        case .fontSlightlyLarge: return "Slightly Large 20"
        case .fontLarge: return "Large 24"
        case .fontExtraLarge: return "Extra Large 28"
        case .fontHuge: return "Huge 32"
        case .fileSaved: return "File Saved"
        case .fileSaveError: return "Save Failed"
        case .saveSuccess: return "Save Successful"
        case .saveError: return "Save Error"
        case .saveAsPrompt: return "Please try using 'Save As' to save to another location."
        case .cancelButton: return "Cancel"
        case .undo: return "Undo"
        case .redo: return "Redo"
        case .copyTooltip: return "Copy"
        case .highlightTooltip: return "Highlight"
        case .underlineTooltip: return "Underline"
        case .addNoteTooltip: return "Add Note"
        case .translateTooltip: return "Translate"
        case .openCloseSidebar: return "Open/Close AI Assistant"
        case .searchPlaceholder: return "Find..."
        case .previousResult: return "Previous"
        case .nextResult: return "Next"
        case .lineWidth: return "🖊 Line Width"
        case .aiSmartAssistant: return "AI Smart Assistant"
        case .clearHistory: return "Clear Conversation History"
        case .modelLabel: return "Model:"
        case .geminiAssistant: return "ChatGPT reading assistant"
        case .aiWelcomeMessage: return "You can:\n1. Select PDF text to ask questions\n2. Paste or drag images for analysis"
        case .selectedPDFContext: return "Selected PDF Context"
        case .inputPlaceholder: return "Enter question (supports dragging images)..."
        case .pasteImageFromClipboard: return "Paste Image from Clipboard"
        case .pasteImageTooltip: return "Paste image"
        case .unsupportedPasteFormat: return "Unsupported paste format, please paste image directly"
        case .you: return "You"
        case .assistant: return "Assistant"
        case .menuFile: return "File"
        case .menuEdit: return "Edit"
        case .menuView: return "View"
        case .menuWindow: return "Window"
        case .menuHelp: return "Help"
        case .menuNew: return "New"
        case .menuOpen: return "Open..."
        case .menuClose: return "Close"
        case .menuCut: return "Cut"
        case .menuPaste: return "Paste"
        case .menuSelectAll: return "Select All"
        case .menuMinimize: return "Minimize"
        case .menuZoom: return "Zoom"
        case .menuBringAllToFront: return "Bring All to Front"
        case .about: return "About"
        case .showAllAnnotations: return "📝 Show All Annotations"
        case .hideAllAnnotations: return "📝 Hide All Annotations"
        case .toggleAllAnnotations: return "📝 Show/Hide All Annotations"
        case .showMainWindow: return "Show Main Window"
        }
    }
}

// MARK: - 便捷方法
func L(_ key: LocalizedKey) -> String {
    return LocalizationManager.shared.localized(key)
}
