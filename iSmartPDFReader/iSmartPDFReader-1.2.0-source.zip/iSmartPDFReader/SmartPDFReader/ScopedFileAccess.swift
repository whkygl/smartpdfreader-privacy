import Foundation

/// Keeps a user-selected file available for the lifetime of a reader or extraction operation.
final class ScopedFileAccess {
    let url: URL
    private let active: Bool
    init(_ url: URL) { self.url = url; active = url.startAccessingSecurityScopedResource() }
    deinit { if active { url.stopAccessingSecurityScopedResource() } }
}
