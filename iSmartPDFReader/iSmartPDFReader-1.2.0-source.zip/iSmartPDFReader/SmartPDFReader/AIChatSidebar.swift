import SwiftUI
import UniformTypeIdentifiers

// MARK: - 💬 AI聊天侧边栏 - Premium Design
struct AIChatSidebar: View {
    @ObservedObject var aiService: ChatGPTService
    @ObservedObject private var account = ChatGPTClient.shared
    @State private var inputText: String = ""
    @State private var selectedImage: NSImage? = nil
    @State private var isTargeted: Bool = false
    @ObservedObject private var localization = LocalizationManager.shared
    
    @State private var clearHover = false
    @State private var headerHover = false
    
    var body: some View {
        VStack(spacing: 0) {
            // MARK: - ✨ Premium Header
            headerView
            
            // MARK: - 💬 Chat Messages
            chatMessagesView
            
            // MARK: - 📋 Selection Preview
            if !aiService.currentSelection.isEmpty {
                SelectionPreview(
                    text: aiService.currentSelection,
                    onDismiss: { aiService.currentSelection = "" }
                )
                .transition(.asymmetric(
                    insertion: .move(edge: .bottom).combined(with: .opacity),
                    removal: .opacity
                ))
            }
            
            // MARK: - 🖼️ Image Preview
            if let img = selectedImage {
                ImagePreview(
                    image: img,
                    onRemove: { withAnimation(Theme.Animation.spring) { selectedImage = nil } }
                )
                .transition(.scale.combined(with: .opacity))
            }
            
            if let error = aiService.errorMessage {
                HStack(alignment: .top) {
                    Text(error).font(.caption).textSelection(.enabled)
                    Spacer(minLength: 4)
                    Button { aiService.errorMessage = nil } label: { Image(systemName: "xmark") }
                        .buttonStyle(.plain)
                }
                .foregroundStyle(Theme.Colors.error).padding(12)
            }
            if aiService.isLoading {
                Button(action: aiService.stop) {
                    Label(T("停止回答", "Stop response"), systemImage: "stop.circle.fill")
                }.padding(.vertical, 8)
            }
            // MARK: - ⌨️ Input Area
            InputArea(
                inputText: $inputText,
                selectedImage: $selectedImage,
                isTargeted: $isTargeted,
                isLoading: aiService.isLoading || aiService.isExtractingPDF || !account.isSignedIn,
                onPaste: pasteImageFromClipboard,
                onSubmit: submit
            )
        }
        .frame(minWidth: 280, maxWidth: 450)
        .background(
            ZStack {
                Color(nsColor: .windowBackgroundColor)
                
                // 微妙的渐变装饰
                VStack {
                    LinearGradient(
                        colors: [Theme.Colors.primary.opacity(0.03), Color.clear],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                    .frame(height: 200)
                    Spacer()
                }
            }
        )
        .task { try? await aiService.prepareConversation() }
        .animation(Theme.Animation.spring, value: aiService.currentSelection.isEmpty)
        .animation(Theme.Animation.spring, value: selectedImage != nil)
    }
    
    // MARK: - Header View
    private var headerView: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top, spacing: 8) {
                VStack(alignment: .leading, spacing: 6) {
                    HStack(spacing: 8) {
                        Label("ChatGPT", systemImage: "bubble.left.and.bubble.right.fill")
                            .font(.headline).lineLimit(1)
                        Spacer(minLength: 4)
                        Button(action: { aiService.clearContext(); Task { try? await aiService.prepareConversation() } }) { Image(systemName: "square.and.pencil") }
                            .help(T("新对话", "New conversation"))
                        SettingsLink { Image(systemName: "gearshape") }
                            .help(L(.settings))
                    }
                    ChatGPTAccountView(compact: true)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                SidebarPet().frame(width: 78, height: 60)
            }
            if account.isSignedIn && !account.models.isEmpty {
                Picker(T("模型", "Model"), selection: $account.selectedModel) {
                    ForEach(account.models) { model in Text(model.name).tag(model.id) }
                }
                .controlSize(.small)
                .disabled(aiService.isLoading)
                if !account.availableReasoningEfforts.isEmpty {
                    Picker(T("推理强度", "Reasoning effort"), selection: Binding(
                        get: { account.selectedReasoningEffort },
                        set: { account.selectedReasoningEffort = $0 }
                    )) {
                        ForEach(account.availableReasoningEfforts, id: \.self) { effort in
                            Text(account.reasoningLabel(effort)).tag(effort)
                        }
                    }
                    .controlSize(.small)
                    .disabled(aiService.isLoading)
                }
            }
            if !aiService.documentName.isEmpty {
                HStack(spacing: 6) {
                    Label(aiService.documentName, systemImage: "doc.text")
                        .lineLimit(1).truncationMode(.middle)
                    Spacer(minLength: 0)
                    if aiService.isExtractingPDF {
                        ProgressView().controlSize(.mini)
                            .help(T("正在提取 PDF 文字…", "Extracting PDF text…"))
                    } else if aiService.pdfFullContent.isEmpty {
                        Image(systemName: "info.circle")
                            .help(T("此 PDF 没有可提取文字，可粘贴页面截图提问。", "No extractable text. Paste a page screenshot to ask about it."))
                    }
                }
                .font(.caption).foregroundStyle(.secondary)
            }
        }
        .padding(12)
        .background(Color(nsColor: .controlBackgroundColor))
    }

    // MARK: - Chat Messages View
    private var chatMessagesView: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 18) {
                    // 空状态欢迎语
                    if aiService.messages.isEmpty {
                        AIChatWelcomeView()
                            .transition(.opacity.combined(with: .scale(scale: 0.95)))
                    }
                    
                    // 消息气泡
                    ForEach(aiService.messages) { msg in
                        ChatBubble(message: msg)
                            .id(msg.id)
                            .transition(.asymmetric(
                                insertion: .opacity.combined(with: .move(edge: .bottom)),
                                removal: .opacity
                            ))
                    }
                    
                    // Loading 状态
                    if aiService.isLoading {
                        LoadingIndicator()
                            .padding(.vertical, 8)
                            .transition(.opacity)
                    }
                }
                .padding(18)
            }
            .onChange(of: aiService.messages) {
                if let lastId = aiService.messages.last?.id {
                    proxy.scrollTo(lastId, anchor: .bottom)
                }
            }
        }
        .background(Color(nsColor: .textBackgroundColor))
    }
    
    // MARK: - Helper Methods
    
    func submit() {
        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty && selectedImage == nil { return }
        if aiService.sendMessage(trimmed, image: selectedImage) {
            inputText = ""
            selectedImage = nil
        }
    }
    
    func pasteImageFromClipboard() {
        let pasteboard = NSPasteboard.general
        if pasteboard.canReadObject(forClasses: [NSImage.self], options: nil),
           let images = pasteboard.readObjects(forClasses: [NSImage.self], options: nil) as? [NSImage],
           let firstImage = images.first {
            withAnimation(Theme.Animation.spring) { self.selectedImage = firstImage }
            return
        }
        if let urls = pasteboard.readObjects(forClasses: [NSURL.self], options: nil) as? [URL] {
            for url in urls {
                if let type = try? url.resourceValues(forKeys: [.contentTypeKey]).contentType,
                   type.conforms(to: .image),
                   let image = NSImage(contentsOf: url) {
                    withAnimation(Theme.Animation.spring) { self.selectedImage = image }
                    return
                }
            }
        }
    }
}

// MARK: - 🎉 Premium Welcome View
struct AIChatWelcomeView: View {
    var body: some View {
        Label(T("选中文字，或直接提问", "Select text or ask a question"), systemImage: "text.bubble")
            .font(.callout).foregroundStyle(.secondary)
            .frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 12)
    }
}

// MARK: - Quick Tip Card
struct QuickTipCard: View {
    let icon: String
    let text: String
    let color: Color
    @State private var isHovered = false
    
    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 8)
                    .fill(color.opacity(0.12))
                    .frame(width: 32, height: 32)
                
                Image(systemName: icon)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(color)
            }
            
            Text(text)
                .font(Theme.Typography.body)
                .foregroundColor(Theme.Colors.textSecondary)
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .font(.system(size: 10, weight: .semibold))
                .foregroundColor(Theme.Colors.textTertiary)
                .opacity(isHovered ? 1 : 0.5)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(isHovered ? Theme.Colors.surface : Theme.Colors.surface.opacity(0.5))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(isHovered ? color.opacity(0.2) : Theme.Colors.borderSubtle, lineWidth: 1)
                )
        )
        .scaleEffect(isHovered ? 1.01 : 1.0)
        .onHover { isHovered = $0 }
        .animation(Theme.Animation.springQuick, value: isHovered)
    }
}

// MARK: - ⏳ Premium Loading Indicator
struct LoadingIndicator: View {
    @State private var animating = false
    
    var body: some View {
        HStack(spacing: 10) {
            // ChatGPT 头像图标
            ZStack {
                Circle()
                    .fill(Theme.Colors.primary.opacity(0.1))
                    .frame(width: 32, height: 32)
                
                Image(systemName: "sparkles")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(Theme.Colors.primary)
            }
            
            // 打字动画
            HStack(spacing: 5) {
                ForEach(0..<3, id: \.self) { index in
                    Circle()
                        .fill(Theme.Colors.gradientPrimary)
                        .frame(width: 8, height: 8)
                        .scaleEffect(animating ? 1.0 : 0.5)
                        .opacity(animating ? 1.0 : 0.3)
                        .animation(
                            Theme.Animation.smooth
                                .repeatForever(autoreverses: true)
                                .delay(Double(index) * 0.15),
                            value: animating
                        )
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(.ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .stroke(Theme.Colors.borderLight, lineWidth: 0.5)
                    )
            )
            
            Spacer()
        }
        .padding(.horizontal, 4)
        .onAppear { animating = true }
    }
}

// MARK: - 📋 Selection Preview
struct SelectionPreview: View {
    let text: String
    var onDismiss: () -> Void
    @State private var dismissHover = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                HStack(spacing: 6) {
                    Image(systemName: "text.cursor")
                        .font(.system(size: 11, weight: .medium))
                    Text(L(.selectedPDFContext))
                        .font(Theme.Typography.captionMedium)
                }
                .foregroundColor(Theme.Colors.primary)
                
                Spacer()
                
                Button(action: onDismiss) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 16))
                        .foregroundColor(dismissHover ? Theme.Colors.error : Theme.Colors.textTertiary)
                        .scaleEffect(dismissHover ? 1.1 : 1.0)
                }
                .buttonStyle(.plain)
                .onHover { dismissHover = $0 }
                .animation(Theme.Animation.springQuick, value: dismissHover)
            }
            
            Text(text)
                .font(Theme.Typography.caption)
                .foregroundColor(Theme.Colors.textSecondary)
                .lineLimit(2)
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Theme.Colors.primary.opacity(0.06))
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Theme.Colors.primary.opacity(0.12), lineWidth: 1)
                        )
                )
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 12)
        .background(
            Rectangle()
                .fill(Color(nsColor: .controlBackgroundColor).opacity(0.8))
        )
    }
}

// MARK: - 🖼️ Image Preview
struct ImagePreview: View {
    let image: NSImage
    var onRemove: () -> Void
    @State private var removeHover = false
    
    var body: some View {
        HStack(alignment: .top) {
            ZStack(alignment: .topTrailing) {
                Image(nsImage: image)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 90)
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(
                                LinearGradient(
                                    colors: [Color.white.opacity(0.3), Color.white.opacity(0.1)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                ),
                                lineWidth: 1
                            )
                    )
                    .shadow(color: .black.opacity(0.15), radius: 12, x: 0, y: 6)
                
                Button(action: onRemove) {
                    ZStack {
                        Circle()
                            .fill(removeHover ? Theme.Colors.error : Color.black.opacity(0.7))
                            .frame(width: 24, height: 24)
                        
                        Image(systemName: "xmark")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundColor(.white)
                    }
                    .shadow(color: .black.opacity(0.2), radius: 4, x: 0, y: 2)
                }
                .buttonStyle(.plain)
                .onHover { removeHover = $0 }
                .offset(x: 8, y: -8)
                .scaleEffect(removeHover ? 1.1 : 1.0)
                .animation(Theme.Animation.springQuick, value: removeHover)
            }
            
            Spacer()
        }
        .padding(.horizontal, 18)
        .padding(.top, 12)
    }
}

// MARK: - ⌨️ Premium Input Area
struct InputArea: View {
    @Binding var inputText: String
    @Binding var selectedImage: NSImage?
    @Binding var isTargeted: Bool
    var isLoading: Bool
    var onPaste: () -> Void
    var onSubmit: () -> Void
    
    @State private var pasteHover = false
    @State private var sendHover = false
    @FocusState private var isFocused: Bool
    
    private var canSend: Bool {
        !inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || selectedImage != nil
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // 分隔线
            Rectangle()
                .fill(Theme.Colors.borderLight)
                .frame(height: 1)
            
            HStack(alignment: .bottom, spacing: 12) {
                // 粘贴图片按钮
                Button(action: onPaste) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .fill(pasteHover ? Theme.Colors.primary.opacity(0.1) : Color.clear)
                            .frame(width: 40, height: 40)
                        
                        Image(systemName: "photo.on.rectangle.angled")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(pasteHover ? Theme.Colors.primary : Theme.Colors.textSecondary)
                    }
                }
                .buttonStyle(.plain)
                .onHover { pasteHover = $0 }
                .help(L(.pasteImageFromClipboard))
                .scaleEffect(pasteHover ? 1.05 : 1.0)
                .animation(Theme.Animation.springQuick, value: pasteHover)
                
                // 输入框 - 使用 TextEditor 使回车键换行
                ZStack(alignment: .leading) {
                    if inputText.isEmpty {
                        Text(L(.inputPlaceholder))
                            .font(Theme.Typography.body)
                            .foregroundColor(Theme.Colors.textTertiary)
                            .padding(.leading, 4)
                    }
                    
                    TextEditor(text: $inputText)
                        .font(Theme.Typography.body)
                        .scrollContentBackground(.hidden)
                        .background(Color.clear)
                        .frame(minHeight: 22, maxHeight: 100)
                        .fixedSize(horizontal: false, vertical: true)
                        .focused($isFocused)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(
                    RoundedRectangle(cornerRadius: 14)
                        .fill(Color(nsColor: .textBackgroundColor))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(
                                    isFocused ? Theme.Colors.primary.opacity(0.4) : Theme.Colors.borderLight,
                                    lineWidth: isFocused ? 1.5 : 1
                                )
                        )
                        .shadow(color: isFocused ? Theme.Colors.primary.opacity(0.08) : .clear, radius: 8, x: 0, y: 2)
                )
                .animation(Theme.Animation.quick, value: isFocused)
                
                // 发送按钮
                Button(action: onSubmit) {
                    ZStack {
                        Circle()
                            .fill(canSend && !isLoading ? Theme.Colors.gradientPrimary : LinearGradient(colors: [Color.gray.opacity(0.25)], startPoint: .top, endPoint: .bottom))
                            .frame(width: 40, height: 40)
                            .overlay(
                                Circle()
                                    .stroke(
                                        canSend && !isLoading
                                            ? LinearGradient(colors: [Color.white.opacity(0.3), Color.clear], startPoint: .top, endPoint: .bottom)
                                            : LinearGradient(colors: [Color.clear], startPoint: .top, endPoint: .bottom),
                                        lineWidth: 1
                                    )
                            )
                            .shadow(
                                color: canSend && !isLoading ? Theme.Colors.primary.opacity(sendHover ? 0.45 : 0.25) : .clear,
                                radius: sendHover ? 12 : 6,
                                x: 0,
                                y: sendHover ? 4 : 2
                            )
                        
                        Image(systemName: "arrow.up")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(.white)
                    }
                    .scaleEffect(sendHover && canSend ? 1.08 : 1.0)
                }
                .buttonStyle(.plain)
                .onHover { sendHover = $0 }
                .disabled(!canSend || isLoading)
                .animation(Theme.Animation.springQuick, value: sendHover)
            }
            .padding(16)
            
            // 拖拽提示
            if isTargeted {
                HStack(spacing: 8) {
                    Image(systemName: "photo.badge.plus")
                        .font(.system(size: 13, weight: .medium))
                    Text(L(.pasteImageFromClipboard))
                        .font(Theme.Typography.captionMedium)
                }
                .foregroundColor(Theme.Colors.primary)
                .padding(.vertical, 10)
                .frame(maxWidth: .infinity)
                .background(
                    Rectangle()
                        .fill(Theme.Colors.primary.opacity(0.08))
                        .overlay(
                            Rectangle()
                                .stroke(Theme.Colors.primary.opacity(0.2), lineWidth: 1)
                        )
                )
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .background(Color(nsColor: .controlBackgroundColor))
        .onDrop(of: [.image, .fileURL], isTargeted: $isTargeted) { providers in
            handleDrop(providers)
            return true
        }
        .animation(Theme.Animation.quick, value: isTargeted)
    }
    
    private func handleDrop(_ providers: [NSItemProvider]) {
        for provider in providers {
            if provider.canLoadObject(ofClass: NSImage.self) {
                provider.loadObject(ofClass: NSImage.self) { image, _ in
                    if let nsImage = image as? NSImage {
                        DispatchQueue.main.async {
                            withAnimation(Theme.Animation.spring) { self.selectedImage = nsImage }
                        }
                    }
                }
                return
            }
            if provider.hasItemConformingToTypeIdentifier(UTType.fileURL.identifier) {
                provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { (item, _) in
                    if let data = item as? Data,
                       let url = URL(dataRepresentation: data, relativeTo: nil),
                       let image = NSImage(contentsOf: url) {
                        DispatchQueue.main.async {
                            withAnimation(Theme.Animation.spring) { self.selectedImage = image }
                        }
                    }
                }
                return
            }
        }
    }
}

// MARK: - 💬 Premium Chat Bubble
struct ChatBubble: View {
    let message: ChatMessage
    var isUser: Bool { message.role == "user" }
    @State private var heartHover = false
    @State private var isHovered = false
    
    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            if isUser { Spacer(minLength: 50) }
            
            VStack(alignment: isUser ? .trailing : .leading, spacing: 8) {
                // 图片内容
                if let data = message.imageData, let nsImg = NSImage(data: data) {
                    Image(nsImage: nsImg)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(maxWidth: 240, maxHeight: 240)
                        .cornerRadius(16)
                        .overlay(
                            RoundedRectangle(cornerRadius: 16)
                                .stroke(Color.white.opacity(0.2), lineWidth: 1)
                        )
                        .shadow(color: .black.opacity(0.12), radius: 10, x: 0, y: 5)
                }
                
                // 文字内容
                if !message.content.isEmpty || message.imageData == nil {
                    if isUser {
                        // 用户消息
                        Text(message.content)
                            .font(.system(size: 13.5))
                            .foregroundColor(.white)
                            .textSelection(.enabled)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(
                                ZStack {
                                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                                        .fill(Theme.Colors.gradientPrimary)
                                    
                                    // 顶部高光
                                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                                        .fill(
                                            LinearGradient(
                                                colors: [Color.white.opacity(0.15), Color.clear],
                                                startPoint: .top,
                                                endPoint: .center
                                            )
                                        )
                                }
                                .shadow(color: Theme.Colors.primary.opacity(0.25), radius: 8, x: 0, y: 4)
                            )
                            .fixedSize(horizontal: false, vertical: true)
                    } else {
                        // AI消息
                        HStack(alignment: .bottom, spacing: 10) {
                            MarkdownContentView(content: message.content)
                                .padding(16)
                                .background(
                                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                                        .fill(.ultraThinMaterial)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 18, style: .continuous)
                                                .stroke(
                                                    LinearGradient(
                                                        colors: [Color.gray.opacity(0.2), Color.gray.opacity(0.1)],
                                                        startPoint: .topLeading,
                                                        endPoint: .bottomTrailing
                                                    ),
                                                    lineWidth: 1
                                                )
                                        )
                                        .shadow(color: .black.opacity(0.04), radius: 8, x: 0, y: 4)
                                )
                            
                            // 收藏/拖拽按钮
                            Image(systemName: heartHover ? "heart.fill" : "heart")
                                .font(.system(size: 15, weight: .medium))
                                .foregroundStyle(heartHover ? Theme.Colors.gradientWarm : LinearGradient(colors: [Color.pink.opacity(0.5)], startPoint: .top, endPoint: .bottom))
                                .frame(width: 34, height: 34)
                                .background(
                                    Circle()
                                        .fill(Color(nsColor: .controlBackgroundColor))
                                        .overlay(
                                            Circle()
                                                .stroke(heartHover ? Color.pink.opacity(0.3) : Theme.Colors.borderLight, lineWidth: 1)
                                        )
                                        .shadow(color: heartHover ? Color.pink.opacity(0.25) : .black.opacity(0.06), radius: heartHover ? 10 : 4, x: 0, y: 2)
                                )
                                .scaleEffect(heartHover ? 1.12 : 1.0)
                                .onHover { heartHover = $0 }
                                .animation(Theme.Animation.spring, value: heartHover)
                                .onDrag {
                                    let provider = NSItemProvider(object: ChatMarkdown.plainText(message.content) as NSString)
                                    provider.registerDataRepresentation(forTypeIdentifier: "com.smartpdf.isheart", visibility: .all) { completion in
                                        completion(Data(), nil)
                                        return nil
                                    }
                                    return provider
                                }
                        }
                    }
                }
            }
            
            if !isUser { Spacer(minLength: 50) }
        }
    }
}

// MARK: - Markdown 内容视图
struct MarkdownContentView: View {
    let content: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            ForEach(ChatMarkdown.parts(content)) { part in
                if part.isCode {
                    CodeBlockView(code: part.text)
                } else {
                    Text(ChatMarkdown.attributed(part.text))
                        .font(.system(size: 13.5))
                        .textSelection(.enabled)
                        .fixedSize(horizontal: false, vertical: true)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
    }
    
}

// MARK: - 💻 Premium Code Block View
struct CodeBlockView: View {
    let code: String
    @State private var isHovering = false
    @State private var copied = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // 顶部栏 - macOS风格
            HStack {
                // 三色圆点
                HStack(spacing: 7) {
                    Circle().fill(Color(hex: "FF5F57")).frame(width: 11, height: 11)
                    Circle().fill(Color(hex: "FFBD2E")).frame(width: 11, height: 11)
                    Circle().fill(Color(hex: "28C840")).frame(width: 11, height: 11)
                }
                
                Spacer()
                
                // 复制按钮
                if isHovering {
                    Button(action: {
                        NSPasteboard.general.clearContents()
                        NSPasteboard.general.setString(code, forType: .string)
                        copied = true
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            copied = false
                        }
                    }) {
                        HStack(spacing: 5) {
                            Image(systemName: copied ? "checkmark" : "doc.on.doc")
                                .font(.system(size: 10, weight: .medium))
                            Text(copied ? L(.copied) : L(.copy))
                                .font(.system(size: 10, weight: .semibold))
                        }
                        .foregroundColor(copied ? Theme.Colors.success : Theme.Colors.textSecondary)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(
                            Capsule()
                                .fill(copied ? Theme.Colors.success.opacity(0.12) : Color(nsColor: .controlBackgroundColor))
                        )
                    }
                    .buttonStyle(.plain)
                    .transition(.opacity.combined(with: .scale(scale: 0.9)))
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(Color(nsColor: .windowBackgroundColor).opacity(0.6))
            
            // 代码内容
            ScrollView(.horizontal, showsIndicators: false) {
                Text(code)
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundColor(.primary)
                    .textSelection(.enabled)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(14)
            }
            .background(Color(nsColor: .textBackgroundColor))
        }
        .background(Color(nsColor: .textBackgroundColor))
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Theme.Colors.borderLight, lineWidth: 1)
        )
        .shadow(color: .black.opacity(0.04), radius: 6, x: 0, y: 3)
        .onHover { isHovering = $0 }
        .animation(Theme.Animation.quick, value: isHovering)
    }
}
