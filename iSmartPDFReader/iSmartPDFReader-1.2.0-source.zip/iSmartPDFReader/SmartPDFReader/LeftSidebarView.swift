import SwiftUI
import PDFKit
import AppKit

// MARK: - 左侧工具栏类型
enum LeftSidebarType: String, CaseIterable {
    case none
    case outline     // 大纲
    case thumbnail   // 缩略图
    case annotation  // 批注
    
    var icon: String {
        switch self {
        case .none: return ""
        case .outline: return "list.bullet.indent"
        case .thumbnail: return "square.grid.2x2"
        case .annotation: return "text.bubble"
        }
    }
    
    var selectedIcon: String {
        switch self {
        case .none: return ""
        case .outline: return "list.bullet.indent"
        case .thumbnail: return "square.grid.2x2.fill"
        case .annotation: return "text.bubble.fill"
        }
    }
    
    var title: String {
        switch self {
        case .none: return ""
        case .outline: return L(.outline)
        case .thumbnail: return L(.thumbnail)
        case .annotation: return L(.annotation)
        }
    }
    
    var localizedTitle: String {
        return title
    }
}

// MARK: - 导航通知
extension Notification.Name {
    static let navigateToPage = Notification.Name("navigateToPage")
    static let navigateToAnnotation = Notification.Name("navigateToAnnotation")
    static let pdfDocumentDidChange = Notification.Name("pdfDocumentDidChange")
}

// MARK: - 左侧工具栏视图
struct LeftToolbarView: View {
    @Binding var selectedType: LeftSidebarType
    var currentPage: Int
    var totalPages: Int
    @ObservedObject private var localization = LocalizationManager.shared
    @State private var hoveredType: LeftSidebarType? = nil
    
    var body: some View {
        VStack(spacing: Theme.Spacing.sm) {
            // 页码显示（顶部）
            if totalPages > 0 {
                VStack(spacing: Theme.Spacing.xxs) {
                    Text("\(currentPage)")
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                        .foregroundStyle(Theme.Colors.gradientPrimary)
                    
                    Rectangle()
                        .fill(Theme.Colors.borderLight)
                        .frame(width: 20, height: 1)
                    
                    Text("\(totalPages)")
                        .font(.system(size: 12, weight: .medium, design: .monospaced))
                        .foregroundColor(Theme.Colors.textSecondary)
                }
                .frame(width: 40)
                .padding(.vertical, Theme.Spacing.sm)
                .background(
                    RoundedRectangle(cornerRadius: Theme.Radius.md)
                        .fill(Theme.Colors.surface.opacity(0.6))
                        .overlay(
                            RoundedRectangle(cornerRadius: Theme.Radius.md)
                                .stroke(Theme.Colors.borderLight, lineWidth: 0.5)
                        )
                )
                .padding(.bottom, Theme.Spacing.sm)
                
                // 分隔线
                GradientDivider()
                    .frame(width: 28)
                    .padding(.bottom, Theme.Spacing.xs)
            }
            
            // 工具按钮
            ForEach([LeftSidebarType.outline, .thumbnail, .annotation], id: \.self) { type in
                ToolbarButton(
                    type: type,
                    isSelected: selectedType == type,
                    isHovered: hoveredType == type,
                    action: {
                        withAnimation(Theme.Animation.spring) {
                            if selectedType == type {
                                selectedType = .none
                            } else {
                                selectedType = type
                            }
                        }
                    }
                )
                .onHover { hovering in
                    withAnimation(Theme.Animation.quick) {
                        hoveredType = hovering ? type : nil
                    }
                }
            }
            
            Spacer()
        }
        .padding(.vertical, Theme.Spacing.md)
        .frame(width: 52)
        .background(
            ZStack {
                Theme.Colors.surface.opacity(0.95)
                
                // 微妙的渐变覆盖
                LinearGradient(
                    colors: [
                        Theme.Colors.primary.opacity(0.02),
                        Color.clear
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )
            }
        )
    }
}

// MARK: - 工具栏按钮
struct ToolbarButton: View {
    let type: LeftSidebarType
    let isSelected: Bool
    let isHovered: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            ZStack {
                // 背景
                RoundedRectangle(cornerRadius: Theme.Radius.md)
                    .fill(
                        isSelected
                        ? Theme.Colors.primary.opacity(0.15)
                        : (isHovered ? Theme.Colors.surface : Color.clear)
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: Theme.Radius.md)
                            .stroke(
                                isSelected ? Theme.Colors.primary.opacity(0.3) : Color.clear,
                                lineWidth: 1
                            )
                    )
                
                // 图标
                Image(systemName: isSelected ? type.selectedIcon : type.icon)
                    .font(.system(size: 16, weight: isSelected ? .semibold : .regular))
                    .foregroundStyle(
                        isSelected
                        ? Theme.Colors.gradientPrimary
                        : LinearGradient(colors: [Theme.Colors.textSecondary], startPoint: .leading, endPoint: .trailing)
                    )
            }
            .frame(width: 36, height: 36)
        }
        .buttonStyle(.plain)
        .help(type.localizedTitle)
        .scaleEffect(isHovered && !isSelected ? 1.05 : 1.0)
    }
}

// MARK: - 左侧边栏容器
struct LeftSidebarContainer: View {
    let pdfDocument: PDFDocument?
    @Binding var selectedType: LeftSidebarType
    
    var body: some View {
        Group {
            switch selectedType {
            case .none:
                EmptyView()
            case .outline:
                OutlineSidebarView(pdfDocument: pdfDocument)
            case .thumbnail:
                ThumbnailSidebarView(pdfDocument: pdfDocument)
            case .annotation:
                AnnotationSidebarView(pdfDocument: pdfDocument)
            }
        }
        .frame(width: selectedType == .none ? 0 : 240)
        .background(Theme.Colors.background)
    }
}

// MARK: - 侧边栏头部
struct SidebarHeader: View {
    let title: String
    var count: Int? = nil
    var onRefresh: (() -> Void)? = nil
    
    var body: some View {
        HStack {
            Text(title)
                .font(Theme.Typography.headline)
                .foregroundColor(Theme.Colors.textPrimary)
            
            Spacer()
            
            if let count = count {
                Text("\(count)")
                    .font(Theme.Typography.captionMedium)
                    .foregroundColor(Theme.Colors.primary)
                    .padding(.horizontal, Theme.Spacing.sm)
                    .padding(.vertical, Theme.Spacing.xxs)
                    .background(
                        Capsule()
                            .fill(Theme.Colors.primary.opacity(0.1))
                    )
            }
            
            if let onRefresh = onRefresh {
                Button(action: onRefresh) {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(Theme.Colors.textSecondary)
                        .frame(width: 24, height: 24)
                        .background(
                            Circle()
                                .fill(Theme.Colors.surface.opacity(0.8))
                        )
                }
                .buttonStyle(.plain)
                .help(L(.refresh))
            }
        }
        .padding(.horizontal, Theme.Spacing.lg)
        .padding(.vertical, Theme.Spacing.md)
        .background(
            ZStack {
                Theme.Colors.surface.opacity(0.5)
                LinearGradient(
                    colors: [Theme.Colors.primary.opacity(0.03), Color.clear],
                    startPoint: .leading,
                    endPoint: .trailing
                )
            }
        )
    }
}

// MARK: - 大纲侧边栏
struct OutlineSidebarView: View {
    let pdfDocument: PDFDocument?
    @State private var outlineItems: [OutlineItem] = []
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SidebarHeader(title: L(.outline))
            
            GradientDivider()
            
            if outlineItems.isEmpty {
                EmptyStateSmall(
                    icon: "doc.text",
                    message: L(.noOutline)
                )
            } else {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: Theme.Spacing.xxs) {
                        ForEach(outlineItems) { item in
                            OutlineRowView(item: item)
                        }
                    }
                    .padding(.vertical, Theme.Spacing.sm)
                    .padding(.horizontal, Theme.Spacing.sm)
                }
            }
        }
        .background(Theme.Colors.background)
        .onAppear { loadOutline() }
        .onChange(of: pdfDocument) { _, _ in loadOutline() }
    }
    
    private func loadOutline() {
        guard let doc = pdfDocument, let root = doc.outlineRoot else {
            outlineItems = []
            return
        }
        outlineItems = parseOutline(root, level: 0)
    }
    
    private func parseOutline(_ outline: PDFOutline, level: Int) -> [OutlineItem] {
        var items: [OutlineItem] = []
        for i in 0..<outline.numberOfChildren {
            if let child = outline.child(at: i) {
                let item = OutlineItem(
                    id: UUID(),
                    title: child.label ?? L(.unnamed),
                    destination: child.destination,
                    level: level,
                    children: parseOutline(child, level: level + 1)
                )
                items.append(item)
            }
        }
        return items
    }
}

// MARK: - 大纲项数据模型
struct OutlineItem: Identifiable {
    let id: UUID
    let title: String
    let destination: PDFDestination?
    let level: Int
    var children: [OutlineItem]
}

// MARK: - 大纲行视图
struct OutlineRowView: View {
    let item: OutlineItem
    @State private var isExpanded: Bool = true
    @State private var isHovered: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: Theme.Spacing.xs) {
                // 缩进
                ForEach(0..<item.level, id: \.self) { _ in
                    Spacer().frame(width: 12)
                }
                
                // 展开/折叠按钮
                if !item.children.isEmpty {
                    Button(action: { withAnimation(Theme.Animation.springQuick) { isExpanded.toggle() } }) {
                        Image(systemName: isExpanded ? "chevron.down" : "chevron.right")
                            .font(.system(size: 9, weight: .semibold))
                            .foregroundColor(Theme.Colors.textTertiary)
                            .frame(width: 16, height: 16)
                            .background(
                                Circle()
                                    .fill(Theme.Colors.surface.opacity(isHovered ? 1 : 0))
                            )
                    }
                    .buttonStyle(.plain)
                } else {
                    Circle()
                        .fill(Theme.Colors.primary.opacity(0.3))
                        .frame(width: 4, height: 4)
                        .padding(.horizontal, 6)
                }
                
                // 标题
                Text(item.title)
                    .font(Theme.Typography.callout)
                    .lineLimit(2)
                    .foregroundColor(isHovered ? Theme.Colors.primary : Theme.Colors.textPrimary)
                
                Spacer()
            }
            .padding(.horizontal, Theme.Spacing.sm)
            .padding(.vertical, Theme.Spacing.sm)
            .background(
                RoundedRectangle(cornerRadius: Theme.Radius.sm)
                    .fill(isHovered ? Theme.Colors.primary.opacity(0.08) : Color.clear)
            )
            .contentShape(Rectangle())
            .onTapGesture {
                if let dest = item.destination {
                    NotificationCenter.default.post(
                        name: .navigateToPage,
                        object: nil,
                        userInfo: ["destination": dest]
                    )
                }
            }
            .onHover { hovering in
                withAnimation(Theme.Animation.quick) {
                    isHovered = hovering
                }
            }
            
            // 子项
            if isExpanded && !item.children.isEmpty {
                ForEach(item.children) { child in
                    OutlineRowView(item: child)
                }
            }
        }
    }
}

// MARK: - 缩略图侧边栏
struct ThumbnailSidebarView: View {
    let pdfDocument: PDFDocument?
    @State private var selectedPageIndex: Int = 0
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SidebarHeader(title: L(.thumbnail))
            
            GradientDivider()
            
            if let doc = pdfDocument {
                ScrollView {
                    LazyVGrid(columns: [GridItem(.flexible())], spacing: Theme.Spacing.md) {
                        ForEach(0..<doc.pageCount, id: \.self) { index in
                            if let page = doc.page(at: index) {
                                ThumbnailCard(
                                    page: page,
                                    pageNumber: index + 1,
                                    isSelected: selectedPageIndex == index
                                )
                                .onTapGesture {
                                    selectedPageIndex = index
                                    NotificationCenter.default.post(
                                        name: .navigateToPage,
                                        object: nil,
                                        userInfo: ["pageIndex": index]
                                    )
                                }
                            }
                        }
                    }
                    .padding(Theme.Spacing.md)
                }
            } else {
                EmptyStateSmall(icon: "photo.on.rectangle", message: L(.noThumbnail))
            }
        }
        .background(Theme.Colors.background)
        .onReceive(NotificationCenter.default.publisher(for: .currentPageChanged)) { notification in
            if let pageIndex = notification.userInfo?["pageIndex"] as? Int {
                selectedPageIndex = pageIndex
            }
        }
    }
}

// MARK: - 缩略图卡片
struct ThumbnailCard: View {
    let page: PDFPage
    let pageNumber: Int
    let isSelected: Bool
    @State private var isHovered: Bool = false
    
    // 计算缩略图的宽高比
    private var aspectRatio: CGFloat {
        let bounds = page.bounds(for: .mediaBox)
        return bounds.width / bounds.height
    }
    
    var body: some View {
        VStack(spacing: Theme.Spacing.sm) {
            // 缩略图 - 使用固定宽度和自适应高度保持完整比例
            ThumbnailImageView(page: page)
                .frame(width: 200, height: 200 / aspectRatio)
                .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.sm))
                .overlay(
                    RoundedRectangle(cornerRadius: Theme.Radius.sm)
                        .stroke(
                            isSelected ? Theme.Colors.primary : Theme.Colors.borderLight,
                            lineWidth: isSelected ? 2 : 0.5
                        )
                )
                .shadow(
                    color: isSelected ? Theme.Colors.primary.opacity(0.2) : .black.opacity(0.05),
                    radius: isSelected ? 8 : 4,
                    x: 0,
                    y: 2
                )
            
            // 页码
            Text("\(pageNumber)")
                .font(Theme.Typography.captionMedium)
                .foregroundColor(isSelected ? Theme.Colors.primary : Theme.Colors.textSecondary)
                .padding(.horizontal, Theme.Spacing.sm)
                .padding(.vertical, Theme.Spacing.xxs)
                .background(
                    Capsule()
                        .fill(isSelected ? Theme.Colors.primary.opacity(0.1) : Theme.Colors.surface.opacity(0.8))
                )
        }
        .padding(Theme.Spacing.xs)
        .background(
            RoundedRectangle(cornerRadius: Theme.Radius.md)
                .fill(isHovered ? Theme.Colors.surface.opacity(0.8) : Color.clear)
        )
        .scaleEffect(isHovered ? 1.02 : 1.0)
        .animation(Theme.Animation.springQuick, value: isHovered)
        .onHover { hovering in
            isHovered = hovering
        }
    }
}

// MARK: - 缩略图图像视图
struct ThumbnailImageView: NSViewRepresentable {
    let page: PDFPage
    
    func makeNSView(context: Context) -> NSImageView {
        let imageView = NSImageView()
        imageView.imageScaling = .scaleProportionallyUpOrDown
        imageView.image = generateThumbnail()
        return imageView
    }
    
    func updateNSView(_ nsView: NSImageView, context: Context) {
        nsView.image = generateThumbnail()
    }
    
    private func generateThumbnail() -> NSImage {
        let bounds = page.bounds(for: .mediaBox)
        // 提高缩略图清晰度：使用3x分辨率渲染以获得更清晰的图像
        let displayScale: CGFloat = max(NSScreen.main?.backingScaleFactor ?? 2.0, 3.0)
        let targetWidth: CGFloat = 200 // 目标显示宽度
        
        // 计算缩放比例，保持完整的页面宽高比
        let scale: CGFloat = (targetWidth * displayScale) / bounds.width
        
        // 按比例计算渲染尺寸（包含完整页面）
        let renderSize = NSSize(
            width: bounds.width * scale,
            height: bounds.height * scale
        )
        
        // 使用高分辨率渲染完整页面
        let thumbnail = page.thumbnail(of: renderSize, for: .mediaBox)
        
        // 设置图片的实际显示尺寸（Retina支持）
        // 保持与页面相同的宽高比
        let aspectRatio = bounds.width / bounds.height
        let displaySize = NSSize(
            width: targetWidth,
            height: targetWidth / aspectRatio
        )
        thumbnail.size = displaySize
        
        return thumbnail
    }
}

// MARK: - 批注侧边栏
struct AnnotationSidebarView: View {
    let pdfDocument: PDFDocument?
    @State private var annotations: [AnnotationItem] = []
    @State private var refreshID = UUID()
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SidebarHeader(
                title: L(.annotation),
                count: annotations.count,
                onRefresh: loadAnnotations
            )
            
            GradientDivider()
            
            if annotations.isEmpty {
                EmptyStateSmall(icon: "text.bubble", message: L(.noAnnotation))
            } else {
                ScrollView {
                    LazyVStack(spacing: Theme.Spacing.sm) {
                        ForEach(annotations) { item in
                            AnnotationRowView(item: item)
                                .onTapGesture {
                                    navigateToAnnotation(item)
                                }
                        }
                    }
                    .padding(Theme.Spacing.md)
                }
            }
        }
        .background(Theme.Colors.background)
        .id(refreshID)
        .onAppear { loadAnnotations() }
        .onChange(of: pdfDocument) { _, _ in loadAnnotations() }
        .onReceive(NotificationCenter.default.publisher(for: .pdfDocumentDidChange)) { _ in
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                loadAnnotations()
            }
        }
    }
    
    private func loadAnnotations() {
        guard let doc = pdfDocument else {
            annotations = []
            return
        }
        
        var items: [AnnotationItem] = []
        let annotationTypes: Set<String> = [
            "/Highlight", "Highlight",
            "/Underline", "Underline",
            "/StrikeOut", "StrikeOut",
            "/Text", "Text",
            "/FreeText", "FreeText",
            "/Ink", "Ink",
            "/Square", "Square",
            "/Circle", "Circle",
            "/Line", "Line"
        ]
        
        // 用于跟踪已处理的groupID，避免重复显示
        var processedGroupIDs: Set<String> = []
        // 跟踪FreeText中的callout类型（需要排除）
        let calloutSubject = "SPDF_NOTE_CALLOUT"
        let connectorSubject = "SPDF_NOTE_CONNECTOR"
        
        for i in 0..<doc.pageCount {
            if let page = doc.page(at: i) {
                for annotation in page.annotations {
                    let subtype = annotation.type ?? ""
                    
                    // 跳过不在列表中的类型
                    guard annotationTypes.contains(subtype) || annotationTypes.contains("/" + subtype) else { continue }
                    
                    // 跳过callout文本框和连接线（它们是批注的附属部分）
                    if let subject = annotation.value(forAnnotationKey: PDFAnnotationKey(rawValue: "Subj")) as? String {
                        if subject == calloutSubject || subject == connectorSubject {
                            continue
                        }
                    }
                    
                    // 获取groupID
                    let groupID = annotation.userName
                    
                    // 对于有groupID的高亮和下划线，只添加第一个遇到的
                    if let gid = groupID, gid.hasPrefix("SPDF-GRP:") {
                        let typeStr = subtype.replacingOccurrences(of: "/", with: "")
                        if typeStr == "Highlight" || typeStr == "Underline" {
                            let uniqueKey = "\(gid)_\(typeStr)"
                            if processedGroupIDs.contains(uniqueKey) {
                                continue // 跳过同组的后续批注
                            }
                            processedGroupIDs.insert(uniqueKey)
                        }
                    }
                    
                    let item = AnnotationItem(
                        id: UUID(),
                        annotation: annotation,
                        pageIndex: i,
                        page: page
                    )
                    items.append(item)
                }
            }
        }
        annotations = items
        refreshID = UUID()
    }
    
    private func navigateToAnnotation(_ item: AnnotationItem) {
        NotificationCenter.default.post(
            name: .navigateToAnnotation,
            object: nil,
            userInfo: ["annotation": item.annotation, "page": item.page]
        )
    }
}

// MARK: - 批注数据模型
struct AnnotationItem: Identifiable {
    let id: UUID
    let annotation: PDFAnnotation
    let pageIndex: Int
    let page: PDFPage
    
    var displayType: String {
        let subtype = annotation.type ?? "Unknown"
        switch subtype {
        case "/Highlight", "Highlight": return L(.highlight)
        case "/Underline", "Underline": return L(.underline)
        case "/StrikeOut", "StrikeOut": return L(.strikeout)
        case "/Text", "Text": return L(.note)
        case "/FreeText", "FreeText": return L(.freeText)
        case "/Ink", "Ink": return L(.ink)
        case "/Square", "Square": return L(.rectangle)
        case "/Circle", "Circle": return L(.ellipse)
        case "/Line", "Line":
            if annotation.endLineStyle == .closedArrow || annotation.endLineStyle == .openArrow {
                return L(.shapeArrow)
            }
            return L(.line)
        default: return subtype.replacingOccurrences(of: "/", with: "")
        }
    }
    
    var displayIcon: String {
        let subtype = annotation.type ?? "Unknown"
        switch subtype {
        case "/Highlight", "Highlight": return "highlighter"
        case "/Underline", "Underline": return "underline"
        case "/StrikeOut", "StrikeOut": return "strikethrough"
        case "/Text", "Text": return "text.bubble"
        case "/FreeText", "FreeText": return "t.square" // 文本框使用此图标
        case "/Ink", "Ink": return "pencil.tip"
        case "/Square", "Square": return "rectangle"
        case "/Circle", "Circle": return "circle"
        case "/Line", "Line":
            if annotation.endLineStyle == .closedArrow || annotation.endLineStyle == .openArrow {
                return "arrow.right"
            }
            return "line.diagonal"
        default: return "tag"
        }
    }
    
    var displayContent: String {
            // 1. 如果有显式的笔记内容（如FreeText或Text Note），优先显示
            if let contents = annotation.contents, !contents.isEmpty {
                return contents
            }
            
            // 2. 如果是高亮、下划线或删除线，尝试从页面提取对应的文本
            let subtype = annotation.type ?? ""
            if subtype == "/Highlight" || subtype == "Highlight" ||
               subtype == "/Underline" || subtype == "Underline" ||
               subtype == "/StrikeOut" || subtype == "StrikeOut" {
                
                // 使用 bounds 获取页面上的选区
                if let selection = page.selection(for: annotation.bounds) {
                    let text = selection.string?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
                    if !text.isEmpty {
                        return text
                    }
                }
            }
            
            // 3. 兜底显示
            if annotation.value(forAnnotationKey: .quadPoints) != nil {
                return L(.selectedArea)
            }
            return L(.noContent)
        }
    
    // 修复：处理透明颜色的情况
    var annotationColor: Color {
        // 1. 对于 FreeText (文本)，如果背景是透明的，优先使用字体颜色
        let subtype = annotation.type ?? ""
        if (subtype == "/FreeText" || subtype == "FreeText") {
            // 如果背景色透明 (alpha == 0)，则尝试获取 fontColor
            if annotation.color.alphaComponent == 0, let fontColor = annotation.fontColor {
                return Color(nsColor: fontColor)
            }
        }
        
        // 2. 如果颜色完全透明（且未在上一步处理），给一个默认可见颜色（如灰色），防止图标隐形
        if annotation.color.alphaComponent == 0 {
            return Color.gray
        }
        
        // 3. 默认情况：使用批注的颜色
        let nsColor = annotation.color
        return Color(nsColor: nsColor)
    }
}

// MARK: - 批注行视图
struct AnnotationRowView: View {
    let item: AnnotationItem
    @State private var isHovered: Bool = false
    
    var body: some View {
        HStack(alignment: .top, spacing: Theme.Spacing.sm) {
            // 美化后的小图标
            ZStack {
                Circle()
                    .fill(item.annotationColor.opacity(0.12))
                    .frame(width: 26, height: 26)
                
                Image(systemName: item.displayIcon)
                    .font(.system(size: 11, weight: .medium))
                    .foregroundColor(item.annotationColor)
            }
            
            VStack(alignment: .leading, spacing: Theme.Spacing.xxs) {
                // 类型和页码
                HStack {
                    Text(item.displayType)
                        .font(Theme.Typography.caption)
                        .foregroundColor(Theme.Colors.textPrimary)
                    
                    Spacer()
                    
                    Text(String(format: L(.page), item.pageIndex + 1))
                        .font(.system(size: 10, weight: .medium))
                        .foregroundColor(Theme.Colors.textTertiary)
                        .padding(.horizontal, Theme.Spacing.xs)
                        .padding(.vertical, 2)
                        .background(
                            Capsule()
                                .fill(Theme.Colors.surface.opacity(0.8))
                        )
                }
                
                // 内容预览
                if !item.displayContent.isEmpty && item.displayContent != L(.noContent) {
                    Text(item.displayContent)
                        .font(.system(size: 11))
                        .foregroundColor(Theme.Colors.textSecondary)
                        .lineLimit(2)
                }
            }
        }
        .padding(Theme.Spacing.sm)
        .background(
            RoundedRectangle(cornerRadius: Theme.Radius.md)
                .fill(isHovered ? Theme.Colors.surface : Theme.Colors.surface.opacity(0.4))
                .overlay(
                    RoundedRectangle(cornerRadius: Theme.Radius.md)
                        .stroke(isHovered ? item.annotationColor.opacity(0.25) : Theme.Colors.borderLight.opacity(0.5), lineWidth: 0.5)
                )
        )
        .shadow(
            color: isHovered ? item.annotationColor.opacity(0.08) : .clear,
            radius: 4,
            x: 0,
            y: 1
        )
        .scaleEffect(isHovered ? 1.01 : 1.0)
        .animation(Theme.Animation.springQuick, value: isHovered)
        .onHover { hovering in
            isHovered = hovering
        }
        .contentShape(Rectangle())
    }
}

// MARK: - 小型空状态视图
struct EmptyStateSmall: View {
    var icon: String
    var message: String
    
    var body: some View {
        VStack(spacing: Theme.Spacing.md) {
            Spacer()
            
            ZStack {
                Circle()
                    .fill(Theme.Colors.gradientSubtle)
                    .frame(width: 60, height: 60)
                
                Image(systemName: icon)
                    .font(.system(size: 24, weight: .light))
                    .foregroundStyle(Theme.Colors.gradientPrimary)
            }
            
            Text(message)
                .font(Theme.Typography.callout)
                .foregroundColor(Theme.Colors.textSecondary)
                .multilineTextAlignment(.center)
            
            Spacer()
        }
        .frame(maxWidth: .infinity)
        .padding(Theme.Spacing.xl)
    }
}
