#if APP_STORE
import Foundation

/// App-owned data only. No other application's account directory is inspected.
struct PlanCredentialStore {
    let directory: URL
    private var file: URL { directory.appendingPathComponent("chatgpt-account.json") }

    func load() throws -> PlanCredentials? {
        guard FileManager.default.fileExists(atPath: file.path) else { return nil }
        let values = try file.resourceValues(forKeys: [.isSymbolicLinkKey, .isRegularFileKey])
        guard values.isSymbolicLink != true, values.isRegularFile == true else {
            throw PlanAuthError.message("Invalid account storage")
        }
        return try JSONDecoder().decode(PlanCredentials.self, from: Data(contentsOf: file))
    }

    func save(_ credentials: PlanCredentials) throws {
        let manager = FileManager.default
        try manager.createDirectory(at: directory, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        guard try directory.resourceValues(forKeys: [.isSymbolicLinkKey]).isSymbolicLink != true else {
            throw PlanAuthError.message("Invalid account directory")
        }
        try manager.setAttributes([.posixPermissions: 0o700], ofItemAtPath: directory.path)
        let temporary = directory.appendingPathComponent(UUID().uuidString + ".tmp")
        defer { try? manager.removeItem(at: temporary) }
        let bytes = try JSONEncoder().encode(credentials)
        guard manager.createFile(atPath: temporary.path, contents: bytes, attributes: [.posixPermissions: 0o600]) else {
            throw PlanAuthError.message(T("无法安全保存登录状态。", "Could not securely save sign-in."))
        }
        // POSIX rename replaces the whole record atomically, including a rotated refresh token.
        guard rename(temporary.path, file.path) == 0 else {
            throw PlanAuthError.message(T("无法更新登录状态。", "Could not update sign-in."))
        }
    }

    func remove() throws {
        if FileManager.default.fileExists(atPath: file.path) { try FileManager.default.removeItem(at: file) }
    }
}

/// SSE framing is separate from transport so partial, multiline and truncated streams are testable.
struct PlanSSEDecoder {
    private var dataLines: [String] = []
    private var size = 0
    mutating func line(_ input: String) throws -> [String: Any]? {
        let value = input.hasSuffix("\r") ? String(input.dropLast()) : input
        if value.isEmpty {
            defer { dataLines.removeAll(keepingCapacity: true); size = 0 }
            guard !dataLines.isEmpty else { return nil }
            let payload = dataLines.joined(separator: "\n")
            if payload == "[DONE]" { return nil }
            guard let bytes = payload.data(using: .utf8),
                  let event = try JSONSerialization.jsonObject(with: bytes) as? [String: Any] else {
                throw PlanAuthError.message(T("回答数据格式异常，请重试。", "Invalid response stream. Please retry."))
            }
            return event
        }
        if value.hasPrefix("data:") {
            var field = String(value.dropFirst(5))
            if field.first == " " { field.removeFirst() }
            size += field.utf8.count
            guard size <= 16_000_000 else { throw PlanAuthError.message("Response event is too large") }
            dataLines.append(field)
        }
        return nil
    }
}
#endif
