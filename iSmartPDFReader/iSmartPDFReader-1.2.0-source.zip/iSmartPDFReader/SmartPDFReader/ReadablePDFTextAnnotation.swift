import AppKit
import PDFKit
import CoreText

/// Draw glyphs directly into the PDF context, retaining sharp text at any zoom and on export.
final class ReadablePDFTextAnnotation: PDFAnnotation {
    static let subject = "SPDF_DROPPED_TEXT"
    static let padding: CGFloat = 3

    static func attributes(font: NSFont, color: NSColor, alignment: NSTextAlignment = .left) -> [NSAttributedString.Key: Any] {
        let paragraph = NSMutableParagraphStyle()
        paragraph.lineBreakMode = .byWordWrapping
        paragraph.lineSpacing = 1.5
        paragraph.alignment = alignment
        return [.font: font, .foregroundColor: color, .paragraphStyle: paragraph]
    }

    static func fittedSize(text: String, font: NSFont, width: CGFloat, maxHeight: CGFloat) -> CGSize {
        let content = NSAttributedString(string: text.isEmpty ? " " : text, attributes: attributes(font: font, color: .black))
        let setter = CTFramesetterCreateWithAttributedString(content)
        let size = CTFramesetterSuggestFrameSizeWithConstraints(setter, CFRange(), nil,
            CGSize(width: max(20, width - padding * 2), height: .greatestFiniteMagnitude), nil)
        return CGSize(width: width, height: min(maxHeight, max(24, ceil(size.height) + padding * 2 + 2)))
    }

    override func draw(with box: PDFDisplayBox, in context: CGContext) {
        guard let contents, !contents.isEmpty else { return }
        context.saveGState()
        defer { context.restoreGState() }
        context.setShouldAntialias(true)
        context.setShouldSmoothFonts(true)
        // PDFKit can decode an absent annotation color as yellow. Text boxes have no fill;
        // drawing that decoded fallback would introduce a yellow rectangle after reopening.
        context.clip(to: bounds)
        context.textMatrix = .identity
        let text = NSAttributedString(string: contents,
            attributes: Self.attributes(font: font ?? .systemFont(ofSize: 11), color: fontColor ?? .black, alignment: alignment))
        let frame = CTFramesetterCreateFrame(CTFramesetterCreateWithAttributedString(text), CFRange(),
            CGPath(rect: bounds.insetBy(dx: Self.padding, dy: Self.padding), transform: nil), nil)
        CTFrameDraw(frame, context)
    }
}

/// Native display view avoids PDFKit's low-resolution annotation appearance cache on Retina screens.
final class ReadablePDFTextView: NSView {
    weak var annotation: ReadablePDFTextAnnotation?
    weak var owner: CustomPDFView?
    var pageTransform = CGAffineTransform.identity
    override func hitTest(_ point: NSPoint) -> NSView? {
        guard !isHidden, let annotation, owner?.canInteractWithText(annotation) == true,
              bounds.contains(convert(point, from: superview)) else { return nil }
        return self
    }
    override var acceptsFirstResponder: Bool { true }
    override func resetCursorRects() { addCursorRect(bounds, cursor: .openHand) }
    override func mouseDown(with event: NSEvent) { owner?.mouseDown(with: event) }
    override func mouseDragged(with event: NSEvent) { NSCursor.closedHand.set(); owner?.mouseDragged(with: event) }
    override func mouseUp(with event: NSEvent) { owner?.mouseUp(with: event); NSCursor.openHand.set() }
    override func menu(for event: NSEvent) -> NSMenu? { owner?.menu(for: event) }
    override func viewDidMoveToWindow() { super.viewDidMoveToWindow(); updateScale() }
    override func viewDidChangeBackingProperties() { super.viewDidChangeBackingProperties(); updateScale() }
    private func updateScale() {
        wantsLayer = true
        layer?.contentsScale = window?.backingScaleFactor ?? 2
        layer?.shouldRasterize = false
        needsDisplay = true
    }
    override func draw(_ dirtyRect: NSRect) {
        guard let annotation, let context = NSGraphicsContext.current?.cgContext else { return }
        context.saveGState()
        context.concatenate(pageTransform)
        annotation.draw(with: .cropBox, in: context)
        context.restoreGState()
    }
}
