import SwiftUI

struct ChatGPTAccountView: View {
    @ObservedObject private var account = ChatGPTClient.shared
    @ObservedObject private var localization = LocalizationManager.shared
    var compact = false

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 8) {
                Image(systemName: account.isSignedIn ? "person.crop.circle.badge.checkmark" : "person.crop.circle")
                    .foregroundStyle(account.isSignedIn ? Theme.Colors.success : Theme.Colors.textSecondary)
                VStack(alignment: .leading, spacing: 3) {
                    Text(account.statusText).font(.callout).textSelection(.enabled)
                        .lineLimit(compact ? 1 : nil).truncationMode(.middle)
                    if !compact && !account.plan.isEmpty {
                        Text(account.plan.capitalized).font(.caption).foregroundStyle(.secondary)
                    }
                }
                Spacer(minLength: 0)
            }
            if account.state == .signingIn {
                HStack {
                    ProgressView().controlSize(.small)
                    Button(T("取消登录", "Cancel sign-in")) { Task { await account.cancelLogin() } }
                }
            } else if account.isSignedIn {
                if !compact {
#if APP_STORE
                    Button(T("重新授权 ChatGPT", "Reauthorize ChatGPT")) { account.signIn() }
#endif
                    Button(T("退出此应用中的账号", "Sign out of this app")) { account.signOut() }
                }
            } else {
                Button(action: account.signIn) {
                    Label(T("登录 ChatGPT", "Continue with ChatGPT"), systemImage: "arrow.up.forward.app")
                }
                .buttonStyle(.borderedProminent)
                .disabled(account.isConnecting)
            }
            if !compact {
#if APP_STORE
            Text(T("使用 ChatGPT 账号可用的套餐额度，无需 API Key。模型及可用性由账号和工作区决定。", "Uses available ChatGPT plan limits. No API key needed. Models and availability depend on your account and workspace."))
                .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
#else
            Text(T("使用账号的 Codex 权益和额度，无需 API Key。", "Uses your account’s Codex access and limits. No API key needed."))
                .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
#endif
            }
            if let error = account.errorMessage {
                Text(error).font(.caption).foregroundStyle(Theme.Colors.error).textSelection(.enabled)
                Button(T("重新连接", "Reconnect")) { account.refresh() }.disabled(account.isConnecting)
            }
        }
    }
}

struct SettingsView: View {
    @ObservedObject private var account = ChatGPTClient.shared
    @ObservedObject private var localization = LocalizationManager.shared
#if APP_STORE
    @AppStorage(PlanPrivacy.consentKey) private var allowSharing = false
#endif

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                Label(T("SmartPDF 设置", "SmartPDF Settings"), systemImage: "gearshape")
                    .font(.title2.bold())
                GroupBox("ChatGPT") {
                    ChatGPTAccountView().padding(12).frame(maxWidth: .infinity, alignment: .leading)
                }
                GroupBox(T("语言", "Language")) {
                    Picker(L(.selectLanguage), selection: Binding(
                        get: { localization.currentLanguage }, set: { localization.setLanguage($0) }
                    )) {
                        ForEach(AppLanguage.allCases, id: \.self) { Text($0.displayName).tag($0) }
                    }.padding(12)
                }
                GroupBox(T("使用说明", "How it works")) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text(T("登录会在系统浏览器中的 OpenAI 官方页面完成。登录后返回阅读器，即可在侧栏基于 PDF 文字、选区和图片提问。", "Sign in on OpenAI’s official page in your system browser, then return here to ask about PDF text, selections, and images."))
#if APP_STORE
                        Text(T("对话保留在当前阅读窗口中，独立于 ChatGPT 网页历史。模型、推理选项及额度取决于账号和工作区的可用权限。", "Conversations stay in the current reading window, separate from ChatGPT web history. Models, reasoning options and usage limits depend on account and workspace access."))
#else
                        Text(T("此应用的对话独立于 ChatGPT 网页历史，模型和额度取决于账号可用的 Codex 权益。", "Conversations are separate from ChatGPT web history. Model access and limits depend on your account’s Codex access."))
#endif
                        Text(T("打开 PDF 只会在本机提取文字；点击发送才会将所附内容提交给 OpenAI。扫描件请使用页面截图。", "Opening a PDF extracts text locally. Content is sent to OpenAI when you send a question. Use page screenshots for scanned PDFs."))
#if APP_STORE
                        Link(T("官方接入说明", "Official integration documentation"), destination: URL(string: "https://developers.openai.com/siwc/token-sharing-open-source")!)
#else
                        Link(T("官方接入说明", "Official integration documentation"), destination: URL(string: "https://learn.chatgpt.com/docs/app-server")!)
#endif
                    }.font(.callout).foregroundStyle(.secondary).padding(12)
                }
#if APP_STORE
                GroupBox(T("隐私与开源", "Privacy and open source")) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text(allowSharing ? T("已允许向 OpenAI 发送问答所需内容。", "Permission to share question content with OpenAI is enabled.") : T("发送问题前会询问您的许可。", "You will be asked for permission before sending a question."))
                        if allowSharing {
                            Button(T("撤回内容分享许可", "Withdraw content-sharing permission")) { allowSharing = false }
                        }
                        Link(T("应用隐私政策", "App privacy policy"), destination: URL(string: "https://whkygl.github.io/smartpdfreader-privacy/")!)
                        Link(T("OpenAI 隐私政策", "OpenAI privacy policy"), destination: URL(string: "https://openai.com/policies/privacy-policy/")!)
                        Link(T("查看开源代码", "View source code"), destination: URL(string: "https://github.com/whkygl/smartpdfreader-privacy/tree/main/iSmartPDFReader")!)
                        Text(T("登录凭据仅保存在此应用的受保护本地目录中。退出会删除此应用的登录凭据。", "Sign-in credentials are kept in this app’s protected local directory. Signing out deletes this app’s credentials."))
                    }.font(.callout).foregroundStyle(.secondary).padding(12)
                }
#else
                DisclosureGroup(T("连接组件", "Connection component")) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text(account.executablePath.isEmpty ? T("自动查找本机已安装的官方 Codex。", "Automatically finds the official Codex installed on this Mac.") : account.executablePath)
                            .font(.caption).textSelection(.enabled)
                        HStack {
                            Button(T("选择 Codex 文件…", "Choose Codex executable…")) { account.chooseExecutable() }
                            Button(T("检查连接", "Check connection")) { account.refresh() }.disabled(account.isConnecting)
                        }
                        Link(T("安装官方 Codex CLI", "Install the official Codex CLI"), destination: URL(string: "https://learn.chatgpt.com/docs/cli")!)
                        Text(T("登录状态单独保存在此应用的本地支持目录，退出不会影响其他应用。此版本为本机使用的桌面应用。", "Login is stored in this app’s local support directory. Signing out does not affect other apps. This build is for local desktop use."))
                            .font(.caption).foregroundStyle(.secondary)
                    }.padding(.top, 10)
                }
#endif
                Text("SmartPDF Reader \(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "") · ChatGPT").font(.caption).foregroundStyle(.secondary)
            }.padding(24)
        }
        .frame(width: 500, height: 680)
        .task { account.refresh() }
    }
}
