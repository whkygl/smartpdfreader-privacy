import SwiftUI
import PDFKit
import UniformTypeIdentifiers

struct MenuBarPopoverView: View {
    @ObservedObject var service: ChatGPTService
    let closeAction: () -> Void
    @State private var extractionID = UUID()

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button(action: openPDF) {
                    Label(T("选择 PDF", "Choose PDF"), systemImage: "paperclip")
                }
                if !service.documentName.isEmpty {
                    Button { extractionID = UUID(); service.resetDocument(); service.isExtractingPDF = false } label: {
                        Image(systemName: "xmark.circle")
                    }.help(T("移除 PDF", "Remove PDF"))
                }
                Spacer()
                Button(action: closeAction) { Image(systemName: "xmark") }.buttonStyle(.plain)
            }.padding(12)
            AIChatSidebar(aiService: service)
        }
        .frame(width: 440, height: 680)
    }

    private func openPDF() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.pdf]
        panel.allowsMultipleSelection = false
        guard panel.runModal() == .OK, let url = panel.url else { return }
        let token = UUID(); extractionID = token
        service.resetDocument(); service.documentName = url.lastPathComponent; service.isExtractingPDF = true
        let extractionAccess = ScopedFileAccess(url)
        DispatchQueue.global(qos: .userInitiated).async {
            defer { withExtendedLifetime(extractionAccess) {} }
            let doc = PDFDocument(url: url)
            let text = doc?.string?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            var content = ""
            if let doc, !text.isEmpty {
                for page in 0..<doc.pageCount {
                    content += "\n[第 \(page + 1) 页 / Page \(page + 1)]\n" + (doc.page(at: page)?.string ?? "")
                }
            }
            DispatchQueue.main.async {
                guard token == extractionID else { return }
                service.pdfFullContent = content; service.isExtractingPDF = false
                Task { try? await service.prepareConversation() }
                if doc == nil { service.errorMessage = T("无法读取 PDF 文件。", "Could not read the PDF file.") }
            }
        }
    }
}
