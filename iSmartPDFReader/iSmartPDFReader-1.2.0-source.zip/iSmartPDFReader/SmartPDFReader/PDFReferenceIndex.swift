import Foundation

/// Local excerpt selection bounds input size without losing access to later pages.
struct PDFReferenceIndex {
    struct Chunk {
        let id: Int
        let page: Int
        let text: String
        let searchable: String
    }
    let chunks: [Chunk]
    let characterCount: Int

    init(_ source: String) {
        characterCount = source.count
        let regex = try! NSRegularExpression(pattern: #"\[第\s*(\d+)\s*页\s*/\s*Page\s*\d+\]"#)
        let ns = source as NSString
        let matches = regex.matches(in: source, range: NSRange(location: 0, length: ns.length))
        var pages: [(Int, String)] = []
        if matches.isEmpty { pages = [(1, source)] }
        else {
            for (i, match) in matches.enumerated() {
                let start = NSMaxRange(match.range)
                let end = i + 1 < matches.count ? matches[i + 1].range.location : ns.length
                pages.append((Int(ns.substring(with: match.range(at: 1))) ?? i + 1,
                              ns.substring(with: NSRange(location: start, length: end - start))))
            }
        }
        var built: [Chunk] = []
        for (page, text) in pages {
            var remaining = text.trimmingCharacters(in: .whitespacesAndNewlines)[...]
            while !remaining.isEmpty {
                let hardEnd = remaining.index(remaining.startIndex, offsetBy: min(1800, remaining.count))
                var end = hardEnd
                if hardEnd < remaining.endIndex,
                   let newline = remaining[..<hardEnd].lastIndex(of: "\n"),
                   remaining.distance(from: remaining.startIndex, to: newline) > 900 { end = remaining.index(after: newline) }
                let body = String(remaining[..<end])
                built.append(Chunk(id: built.count, page: page, text: body, searchable: body.lowercased()))
                remaining = remaining[end...]
            }
        }
        chunks = built
    }

    func excerpts(question: String, selection: String, sent: Set<Int>) -> [Chunk] {
        guard !chunks.isEmpty else { return [] }
        // Small articles retain their complete text, sent only once per conversation.
        if characterCount <= 24_000 { return chunks.filter { !sent.contains($0.id) } }
        let query = question.lowercased()
        let overview = ["简述", "主要内容", "总结", "概述", "全文", "summary", "summarize", "overview", "main findings"]
            .contains { query.contains($0) }
        let stopWords: Set<String> = ["the", "with", "only", "reply", "please", "according", "pdf", "document", "article", "page", "what", "which", "how", "many", "that", "this", "from", "explain", "about", "does", "did", "and", "for", "are", "was"]
        let words = query.components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { $0.count > 2 && !stopWords.contains($0) && !$0.unicodeScalars.contains(where: { $0.value >= 0x3400 }) }
        let chinese = Array(query)
        var tokens = Set(words)
        if chinese.count > 1 {
            for i in 0..<(chinese.count - 1) where chinese[i].unicodeScalars.allSatisfy({ $0.value >= 0x3400 && $0.value <= 0x9fff }) && chinese[i + 1].unicodeScalars.allSatisfy({ $0.value >= 0x3400 && $0.value <= 0x9fff }) {
                tokens.insert(String(chinese[i...i+1]))
            }
        }
        let requestedPage = try! NSRegularExpression(pattern: #"(?:第\s*(\d+)\s*页|page\s*(\d+))"#, options: .caseInsensitive)
        let pageMatches = requestedPage.matches(in: question, range: NSRange(question.startIndex..., in: question))
        let pages = Set(pageMatches.flatMap { m in (1..<m.numberOfRanges).compactMap { Range(m.range(at: $0), in: question).flatMap { Int(question[$0]) } } })
        let selectedPrefix = String(selection.prefix(100)).lowercased()
        var scored: [(chunk: Chunk, score: Double)] = []
        for chunk in chunks {
            var score: Double = 0
            for word in tokens where chunk.searchable.contains(word) { score += Double(min(12, word.count)) }
            if pages.contains(chunk.page) { score += 200 }
            if !selectedPrefix.isEmpty && chunk.searchable.contains(selectedPrefix) { score += 100 }
            if chunk.id == 0 { score += overview ? 30 : 0.5 }
            if overview && ["abstract", "conclusion", "summary", "摘要", "结论"].contains(where: { chunk.searchable.contains($0) }) { score += 18 }
            if overview && chunk.id == chunks.count - 1 { score += 10 }
            scored.append((chunk, score))
        }
        scored.sort { left, right in
            if left.score == right.score { return left.chunk.id < right.chunk.id }
            return left.score > right.score
        }
        let relevant = overview ? scored : scored.filter { $0.score > 1 }
        var chosen = relevant.prefix(overview ? 8 : 5).map { $0.chunk }
        if chosen.isEmpty && sent.isEmpty { chosen = Array(chunks.prefix(3)) }
        if overview {
            // Include material across the whole document, rather than truncating its beginning.
            for fraction in [0.2, 0.4, 0.6, 0.8] { chosen.append(chunks[min(chunks.count - 1, Int(Double(chunks.count) * fraction))]) }
        }
        var included = sent
        return chosen.filter { included.insert($0.id).inserted }.sorted { $0.id < $1.id }
    }
}
