#!/bin/bash
set -euo pipefail
reader_root="$(cd "$(dirname "$0")/.." && pwd)"
reader_developer="${DEVELOPER_DIR:-/Library/Developer/CommandLineTools}"
reader_sdk="$reader_developer/SDKs/MacOSX26.5.sdk"
if [ ! -d "$reader_sdk" ]; then reader_sdk="$(DEVELOPER_DIR="$reader_developer" xcrun --sdk macosx --show-sdk-path)"; fi
reader_swift="$(DEVELOPER_DIR="$reader_developer" xcrun -f swiftc)"
"$reader_swift" -D APP_STORE -swift-version 5 -default-isolation MainActor -sdk "$reader_sdk" \
    "$reader_root/SmartPDFReader/ChatGPTClient.swift" "$reader_root/SmartPDFReader/StoreChatGPTClient.swift" \
    "$reader_root/SmartPDFReader/ChatGPTPlanAuth.swift" "$reader_root/SmartPDFReader/PlanCredentialStore.swift" \
    "$reader_root/SmartPDFReader/LocalizationManager.swift" "$reader_root/Tests/LiveConnectionCheck.swift" \
    -o "$reader_root/Build/LiveConnectionCheck"
"$reader_root/Build/LiveConnectionCheck" "$1"
