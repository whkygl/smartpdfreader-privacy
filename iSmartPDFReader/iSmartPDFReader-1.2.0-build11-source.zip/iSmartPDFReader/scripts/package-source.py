#!/usr/bin/env python3
"""Export only reviewed source categories. No home directories or personal documents."""
from pathlib import Path
import base64, hashlib, json, plistlib, re, shutil, zipfile

root = Path(__file__).resolve().parents[1]
output = root / 'Build' / 'OpenSource' / 'iSmartPDFReader'
top = {'.gitignore', 'README.md', 'LICENSE', 'PRIVACY.md'}
selected = [root / name for name in sorted(top)]
for folder in ['SmartPDFReader', 'scripts', 'Tests', 'SmartPDFReader.xcodeproj']:
    for path in sorted((root / folder).rglob('*')):
        if not path.is_file() or path.is_symlink() or 'xcuserdata' in path.parts:
            continue
        if path.suffix in {'.swift', '.sh', '.py', '.plist', '.entitlements', '.xcprivacy', '.json', '.png', '.icns', '.txt', '.pbxproj', '.xcworkspacedata', '.xcscheme'}:
            selected.append(path)
for name in ['Info.plist', 'Release.xcconfig', 'ExportOptions.plist', 'iSmartPDFReader.entitlements']:
    selected.append(root / 'AppStore' / name)
selected.extend(sorted((root / 'AppStore' / 'metadata').rglob('*.txt')))
patterns = [rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----', rb'\bsk-[A-Za-z0-9_-]{20,}', rb'\b(?:ghp_|github_pat_)[A-Za-z0-9_]{20,}', rb'eyJ[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{20,}']
manifest, payload = [], []
for path in selected:
    data = path.read_bytes()
    relative = path.relative_to(root).as_posix()
    if path.suffix not in {'.png', '.icns'} and any(re.search(pattern, data) for pattern in patterns):
        raise SystemExit('Potential credential detected; export stopped: ' + relative)
    target = output / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
    manifest.append({'path': relative, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
    binary = path.suffix in {'.png', '.icns'}
    payload.append({'path': 'iSmartPDFReader/' + relative, 'mode': '100755' if path.stat().st_mode & 0o111 else '100644', 'type': 'blob', 'encoding': 'base64' if binary else 'utf-8', 'content': base64.b64encode(data).decode() if binary else data.decode('utf-8')})
build = root / 'Build'
(build / 'OpenSourceManifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
(build / 'OpenSourceUpload.json').write_text(json.dumps(payload, ensure_ascii=False))
info = plistlib.loads((root / 'AppStore' / 'Info.plist').read_bytes())
archive = build / ('iSmartPDFReader-' + info['CFBundleShortVersionString'] + '-build' + info['CFBundleVersion'] + '-source.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as package:
    for item in manifest:
        package.write(output / item['path'], 'iSmartPDFReader/' + item['path'])
print(json.dumps({'source_files': len(manifest), 'source_bytes': sum(item['bytes'] for item in manifest), 'credential_findings': 0, 'archive': str(archive)}, ensure_ascii=False))
