import Foundation
import AppKit
import Security

extension Notification.Name { static let languageDidChange = Notification.Name("languageDidChange") }

final class PlanFixtureProtocol: URLProtocol, @unchecked Sendable {
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() { Task { @MainActor in StoreTests.handle(self) } }
    override func stopLoading() {}
}

@main struct StoreTests {
    static var refreshCount = 0
    static var requests: [[String: Any]] = []
    static var failNext = false
    static var hangNext = false
    static var failRefresh = false
    static var streamHeader: String? = "text/event-stream"
    static var bodyVariant = "sse"
    static func check(_ condition: Bool, _ message: String) { precondition(condition, message) }
    static func rejects(_ message: String, _ operation: () throws -> Void) {
        do { try operation(); preconditionFailure(message) } catch {}
    }
    static func until(_ predicate: () -> Bool) async throws {
        for _ in 0..<500 {
            if predicate() { return }
            try await Task.sleep(nanoseconds: 10_000_000)
        }
        throw PlanAuthError.message("Fixture timeout")
    }
    static func body(_ request: URLRequest) -> Data {
        if let data = request.httpBody { return data }
        guard let stream = request.httpBodyStream else { return Data() }
        stream.open(); defer { stream.close() }
        var result = Data(), buffer = [UInt8](repeating: 0, count: 4096)
        while stream.hasBytesAvailable {
            let count = stream.read(&buffer, maxLength: buffer.count)
            if count <= 0 { break }; result.append(contentsOf: buffer.prefix(count))
        }
        return result
    }
    static func handle(_ fixture: PlanFixtureProtocol) {
        let path = fixture.request.url!.path
        var data = Data(), contentType = "application/json", status = 200
        if path.hasSuffix("/oauth/token") {
            refreshCount += 1
            check(String(data: body(fixture.request), encoding: .utf8)!.contains("grant_type=refresh_token"), "refresh grant contract")
            if failRefresh { status = 400; data = Data(#"{"error":"invalid_grant"}"#.utf8) }
            else { data = Data(#"{"access_token":"fixture-access-new","refresh_token":"fixture-refresh-rotated","token_type":"Bearer","expires_in":3600,"scope":"chatgpt.tokens.use.direct resource.invoke"}"#.utf8) }
        } else if path == "/v1/models" {
            data = Data(#"{"models":[{"slug":"fixture","display_name":"Fixture Model","visibility":"list","supported_reasoning_levels":[{"effort":"low"},{"effort":"high"}]},{"slug":"hidden","visibility":"hide"}]}"#.utf8)
        } else if path == "/v1/responses" {
            let value = try! JSONSerialization.jsonObject(with: body(fixture.request)) as! [String: Any]
            requests.append(value)
            check(value["store"] as? Bool == false && value["stream"] as? Bool == true, "plan inference flags")
            check(value["previous_response_id"] == nil && value["tools"] == nil && value["max_output_tokens"] == nil, "no unsupported state or tools")
            check((value["reasoning"] as? [String: Any])?["effort"] as? String == "low", "low reasoning sent")
            check(fixture.request.value(forHTTPHeaderField: "Authorization")?.hasPrefix("Bearer fixture-") == true, "OAuth bearer")
            if hangNext { hangNext = false; return }
            contentType = streamHeader ?? ""
            let terminal = failNext ? #"{"type":"response.failed","response":{"error":{"code":"subscription_sharing_usage_limit_exceeded"}}}"# : #"{"type":"response.completed","response":{"status":"completed"}}"#
            failNext = false
            data = Data(("event: delta\r\ndata: {\"type\":\"response.output_text.delta\",\"delta\":\"清晰的 **回答**\"}\r\n\r\ndata: " + terminal + "\n\n").utf8)
            switch bodyVariant {
            case "bom-cr": data = Data([0xEF, 0xBB, 0xBF]) + Data(String(decoding: data, as: UTF8.self).replacingOccurrences(of: "\r\n", with: "\n").replacingOccurrences(of: "\n", with: "\r").utf8)
            case "json-completed": data = Data(#"{"object":"response","status":"completed","output":[{"type":"message","role":"assistant","content":[{"type":"output_text","text":"清晰的 **回答**"}]}]}"#.utf8)
            case "json-error": data = Data(#"{"error":{"code":"subscription_sharing_usage_limit_exceeded","message":"fixture private server text"}}"#.utf8)
            case "json-incomplete": data = Data(#"{"object":"response","status":"incomplete","incomplete_details":{"reason":"max_output_tokens"}}"#.utf8)
            case "html": data = Data("<!doctype html><html>fixture private verification page</html>".utf8)
            case "truncated": data = Data("data: {\"type\":\"response.output_text.delta\",\"delta\":\"partial\"}\n\n".utf8)
            case "invalid": data = Data("not response data".utf8)
            default: break
            }
        } else { preconditionFailure("Unexpected fixture endpoint") }
        fixture.client?.urlProtocol(fixture, didReceive: HTTPURLResponse(url: fixture.request.url!, statusCode: status, httpVersion: "HTTP/1.1", headerFields: contentType.isEmpty ? [:] : ["Content-Type": contentType])!, cacheStoragePolicy: .notAllowed)
        // Deliver fragmented bytes, including splits inside UTF-8 sequences.
        for start in stride(from: 0, to: data.count, by: 7) { fixture.client?.urlProtocol(fixture, didLoad: data.subdata(in: start..<min(start + 7, data.count))) }
        fixture.client?.urlProtocolDidFinishLoading(fixture)
    }
    static func readDER(_ data: Data, _ offset: inout Int) -> Data {
        offset += 1
        var length = Int(data[offset]); offset += 1
        if length & 128 != 0 {
            let count = length & 127; length = 0
            for _ in 0..<count { length = length * 256 + Int(data[offset]); offset += 1 }
        }
        let result = data.subdata(in: offset..<offset+length); offset += length; return result
    }
    static func jwtTests() throws {
        let privateKey = SecKeyCreateRandomKey([kSecAttrKeyType: kSecAttrKeyTypeRSA, kSecAttrKeySizeInBits: 2048] as CFDictionary, nil)!
        let publicBytes = SecKeyCopyExternalRepresentation(SecKeyCopyPublicKey(privateKey)!, nil)! as Data
        var offset = 0
        let sequence = readDER(publicBytes, &offset)
        offset = 0
        let n = readDER(sequence, &offset), e = readDER(sequence, &offset)
        let keys: [String: Any] = ["keys": [["kid": "fixture", "kty": "RSA", "alg": "RS256", "n": n.base64URL, "e": e.base64URL]]]
        var claims: [String: Any] = ["iss": PlanOAuth.issuer, "aud": "oaiapp_fixture", "sub": "fixture-subject", "nonce": "fixture-nonce", "iat": Date().timeIntervalSince1970, "exp": Date().addingTimeInterval(300).timeIntervalSince1970]
        func signed(_ payload: [String: Any], alg: String = "RS256") throws -> String {
            let header = try JSONSerialization.data(withJSONObject: ["kid": "fixture", "alg": alg]).base64URL
            let body = try JSONSerialization.data(withJSONObject: payload).base64URL
            let message = header + "." + body
            let signature = SecKeyCreateSignature(privateKey, .rsaSignatureMessagePKCS1v15SHA256, Data(message.utf8) as CFData, nil)! as Data
            return message + "." + signature.base64URL
        }
        let token = try signed(claims)
        let validated = try PlanOAuth.validateIDToken(token, clientID: "oaiapp_fixture", nonce: "fixture-nonce", jwks: keys)
        check(validated["sub"] as? String == "fixture-subject", "RSA signature verification")
        rejects("wrong nonce") { _ = try PlanOAuth.validateIDToken(token, clientID: "oaiapp_fixture", nonce: "other", jwks: keys) }
        rejects("wrong audience") { _ = try PlanOAuth.validateIDToken(token, clientID: "oaiapp_other", nonce: "fixture-nonce", jwks: keys) }
        rejects("tampered signature") { _ = try PlanOAuth.validateIDToken(token + "x", clientID: "oaiapp_fixture", nonce: "fixture-nonce", jwks: keys) }
        rejects("algorithm confusion") { _ = try PlanOAuth.validateIDToken(signed(claims, alg: "none"), clientID: "oaiapp_fixture", nonce: "fixture-nonce", jwks: keys) }
        claims["exp"] = Date().addingTimeInterval(-300).timeIntervalSince1970
        rejects("expired identity") { _ = try PlanOAuth.validateIDToken(signed(claims), clientID: "oaiapp_fixture", nonce: "fixture-nonce", jwks: keys) }
    }
    static func main() async throws {
        try jwtTests()
        let auth = PlanOAuth.authorizationURL(hostID: "urn:uuid:fixture", redirect: "http://127.0.0.1:54321/auth/callback", state: "fixture-state", nonce: "fixture-nonce", verifier: "fixture-verifier", previous: nil)
        let query = Dictionary(uniqueKeysWithValues: URLComponents(url: auth, resolvingAgainstBaseURL: false)!.queryItems!.map { ($0.name, $0.value!) })
        check(query["client_id"] == "dynamic_agent_client" && query["code_challenge_method"] == "S256" && query["code_challenge"] != "fixture-verifier", "dynamic registration with PKCE")
        let good = URL(string: "http://127.0.0.1:54321/auth/callback?state=fixture-state&code=fixture&client_id=oaiapp_fixture")!
        check(try PlanOAuth.callback(good, state: "fixture-state", previous: nil).clientID == "oaiapp_fixture", "issued client ID")
        rejects("wrong state") { _ = try PlanOAuth.callback(good, state: "wrong", previous: nil) }
        rejects("duplicate state") { _ = try PlanOAuth.callback(URL(string: good.absoluteString + "&state=fixture-state")!, state: "fixture-state", previous: nil) }
        rejects("missing client ID") { _ = try PlanOAuth.callback(URL(string: "http://127.0.0.1:54321/auth/callback?state=x&code=x")!, state: "x", previous: nil) }
        let listener = PlanLoopbackListener(state: "loopback-state")
        let port = try await listener.start()
        let network = URLSession(configuration: .ephemeral)
        let invalid = URL(string: "http://127.0.0.1:\(port)/auth/callback?state=bad&code=x")!
        let (_, invalidResponse) = try await network.data(from: invalid)
        check((invalidResponse as? HTTPURLResponse)?.statusCode == 400, "unrelated callback cannot end login")
        let valid = URL(string: "http://127.0.0.1:\(port)/auth/callback?state=loopback-state&code=x&client_id=oaiapp_fixture")!
        let (_, validResponse) = try await network.data(from: valid)
        check((validResponse as? HTTPURLResponse)?.statusCode == 200, "loopback callback accepted")
        check(try await listener.callback() == valid, "callback delivered")
        listener.stop(); network.invalidateAndCancel()
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("SmartPDF-store-tests-" + UUID().uuidString)
        let suite = "SmartPDF-store-tests-" + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        let store = PlanCredentialStore(directory: directory)
        let saved = PlanCredentials(clientID: "oaiapp_fixture", subject: "fixture-subject", issuer: PlanOAuth.issuer, email: "fixture@example.invalid", idToken: "fixture-id", accessToken: "fixture-access", refreshToken: "fixture-refresh", scopes: ["chatgpt.tokens.use.direct"], expiresAt: Date().addingTimeInterval(-60))
        try store.save(saved)
        let file = directory.appendingPathComponent("chatgpt-account.json")
        check((try FileManager.default.attributesOfItem(atPath: file.path)[.posixPermissions] as? Int) == 0o600, "owner-only credential file")
        check((try FileManager.default.attributesOfItem(atPath: directory.path)[.posixPermissions] as? Int) == 0o700, "owner-only account directory")
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [PlanFixtureProtocol.self]
        let client = ChatGPTClient(stateDirectory: directory, defaults: defaults, session: URLSession(configuration: configuration), openURL: { _ in true })
        defer { client.disconnect(); defaults.removePersistentDomain(forName: suite); try? FileManager.default.removeItem(at: directory) }
        async let connect1: Void = client.connect()
        async let connect2: Void = client.connect()
        _ = try await (connect1, connect2)
        check(refreshCount == 1 && client.isSignedIn, "concurrent windows share one refresh")
        check(try store.load()?.refreshToken == "fixture-refresh-rotated", "refresh rotation saved atomically")
        check(client.models.map(\.id) == ["fixture"] && client.selectedReasoningEffort == "low", "catalog filtering and fast reasoning")
        let first = try await client.request("thread/start", ["baseInstructions": "Fixture instructions"])
        let thread = (first["thread"] as! [String: Any])["id"] as! String
        var terminal: String?, answer = "", failure = "", completedAnswer = ""
        let subscription = client.events.sink { event in
            let params = event["params"] as? [String: Any] ?? [:]
            if event["method"] as? String == "item/agentMessage/delta" { answer += params["delta"] as? String ?? "" }
            if event["method"] as? String == "item/completed" { completedAnswer = (params["item"] as? [String: Any])?["text"] as? String ?? "" }
            if event["method"] as? String == "turn/completed", let turn = params["turn"] as? [String: Any] {
                terminal = turn["status"] as? String; failure = (turn["error"] as? [String: Any])?["message"] as? String ?? ""
            }
        }
        defer { subscription.cancel() }
        func send(_ question: String, id: String? = nil) async throws -> String {
            terminal = nil
            let result = try await client.request("turn/start", ["threadId": id ?? thread, "input": [["type": "text", "text": question]], "model": "fixture", "effort": "low"])
            return (result["turn"] as! [String: Any])["id"] as! String
        }
        _ = try await send("first synthetic question")
        try await until { terminal != nil }
        check(terminal == "completed" && answer == "清晰的 **回答**", "fragmented UTF-8 streaming")
        _ = try await send("follow-up")
        try await until { terminal != nil }
        check((requests.last?["input"] as? [[String: Any]])?.count == 3, "local history resent without server storage")
        let second = try await client.request("thread/start", [:])
        let other = (second["thread"] as! [String: Any])["id"] as! String
        failNext = true
        _ = try await send("other window", id: other)
        try await until { terminal != nil }
        check(terminal == "failed" && !failure.isEmpty && (requests.last?["input"] as? [[String: Any]])?.count == 1, "late usage failure and separate windows")
        hangNext = true
        let active = try await send("interrupt this")
        try await until { requests.count == 4 }
        _ = try await client.request("turn/interrupt", ["threadId": thread, "turnId": active])
        check(terminal == "interrupted", "cancel has truthful terminal state")
        for (header, variant) in [(nil, "sse"), ("application/octet-stream", "sse"), ("application/json", "sse"), (nil, "bom-cr"), ("application/json", "json-completed")] as [(String?, String)] {
            streamHeader = header; bodyVariant = variant; answer = ""; completedAnswer = ""; failure = ""
            let created = try await client.request("thread/start", [:])
            let isolated = (created["thread"] as! [String: Any])["id"] as! String
            _ = try await send("synthetic compatibility check", id: isolated)
            try await until { terminal != nil }
            check(terminal == "completed" && completedAnswer == "清晰的 **回答**", "missing or rewritten MIME and valid completed responses: " + variant)
            client.releaseConversation(isolated)
        }
        for variant in ["json-error", "json-incomplete", "html", "truncated", "invalid"] {
            streamHeader = nil; bodyVariant = variant; completedAnswer = ""; failure = ""
            let created = try await client.request("thread/start", [:])
            let isolated = (created["thread"] as! [String: Any])["id"] as! String
            _ = try await send("synthetic invalid response check", id: isolated)
            try await until { terminal != nil }
            check(terminal == "failed" && completedAnswer.isEmpty && !failure.isEmpty && !failure.contains("private"), "invalid and incomplete content cannot become an answer: " + variant)
            if variant == "json-error" {
                check(failure == ChatGPTClient.serviceError("subscription_sharing_usage_limit_exceeded", status: nil).localizedDescription, "JSON quota errors keep their actionable meaning")
            }
            client.releaseConversation(isolated)
        }
        let readonlyDirectory = directory.appendingPathComponent("readonly")
        try PlanCredentialStore(directory: readonlyDirectory).save(saved)
        let readonly = ChatGPTClient(stateDirectory: readonlyDirectory, defaults: defaults, session: URLSession(configuration: configuration), allowsCredentialRefresh: false)
        let beforeCheck = refreshCount
        do { try await readonly.connect(); preconditionFailure("read-only probe must not rotate an expired credential") } catch {}
        check(refreshCount == beforeCheck, "connection diagnostics never refresh or replace stored credentials")
        readonly.disconnect()
        client.signOut()
        try await until { client.state == .signedOut }
        check(try store.load() == nil, "sign-out removes only this app's credentials")
        print("PASS: native OAuth, protected storage, reasoning, streaming, cancellation, missing/rewritten MIME, BOM/CR framing, completed JSON, quota errors, HTML rejection, truncated answers and read-only diagnostics")
    }
}
