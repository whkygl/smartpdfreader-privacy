// Explicit synthetic check of this app's own account transport. No PDF or chat history is loaded.
import Foundation
import AppKit

extension Notification.Name { static let languageDidChange = Notification.Name("languageDidChange") }

@main struct LiveConnectionCheck {
    static func main() async {
        guard CommandLine.arguments.count == 2 else { print("Expected app-owned account directory"); return }
        let directory = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
        let suite = "iSmartPDFReader-ConnectionCheck-" + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        let client = ChatGPTClient(stateDirectory: directory, defaults: defaults, allowsCredentialRefresh: false, openURL: { _ in false })
        defer { client.disconnect(); defaults.removePersistentDomain(forName: suite) }
        do {
            try await client.connect()
            guard client.isSignedIn, !client.models.isEmpty else { print("No signed-in app account or models"); return }
            // Model names and capabilities are catalog metadata, not account credentials.
            print("Catalog: " + client.models.map { $0.id + " [" + $0.reasoningEfforts.joined(separator: ",") + "]" }.joined(separator: "; "))
            let thread = (try await client.request("thread/start", ["baseInstructions": "Reply briefly to synthetic connection tests."])["thread"] as! [String: Any])["id"] as! String
            var result: String?, received = false
            let started = Date()
            let subscription = client.events.sink { event in
                let params = event["params"] as? [String: Any] ?? [:]
                guard params["threadId"] as? String == thread else { return }
                if event["method"] as? String == "item/agentMessage/delta", !received {
                    received = true
                    print(String(format: "First text: %.2f s", Date().timeIntervalSince(started)))
                }
                if event["method"] as? String == "item/completed", let item = params["item"] as? [String: Any] {
                    // The input is fixed and contains no personal material; report only its exact expected result.
                    let text = item["text"] as? String ?? ""
                    print("Expected synthetic answer: " + (text.contains("Connection OK") ? "yes" : "no"))
                }
                if event["method"] as? String == "turn/completed", let turn = params["turn"] as? [String: Any] {
                    result = turn["status"] as? String
                    if let error = (turn["error"] as? [String: Any])?["message"] as? String { print("Error: " + error) }
                }
            }
            defer { subscription.cancel(); client.releaseConversation(thread) }
            var params: [String: Any] = ["threadId": thread, "model": client.selectedModel, "input": [["type": "text", "text": "Reply with exactly: Connection OK"]]]
            if !client.selectedReasoningEffort.isEmpty { params["effort"] = client.selectedReasoningEffort }
            _ = try await client.request("turn/start", params)
            for _ in 0..<1200 {
                if result != nil { break }
                try await Task.sleep(nanoseconds: 100_000_000)
            }
            print("Result: " + (result ?? "timed out"))
            print("Transport: " + client.lastResponseMetadata)
        } catch { print("Connection check: " + error.localizedDescription) }
    }
}
