#if APP_STORE
import Foundation
import AppKit
import Combine

/// Native, public-client Sign in with ChatGPT for this free, open-source build.
/// Uses no API key, external executable, tool, plugin, or Codex configuration.
@MainActor final class ChatGPTClient: ObservableObject {
    static let shared = ChatGPTClient()
    typealias ClientError = PlanAuthError
    struct Model: Identifiable, Equatable {
        let id: String
        let name: String
        let reasoningEfforts: [String]
        let defaultReasoningEffort: String?
    }
    enum AccountState { case disconnected, signedOut, signingIn, signedIn }
    @Published private(set) var state: AccountState = .disconnected
    @Published private(set) var email = ""
    @Published private(set) var plan = ""
    @Published private(set) var models: [Model] = []
    @Published private(set) var isConnecting = false
    @Published var errorMessage: String?
    // Diagnostic metadata only; never record credentials, prompts or response content.
    private(set) var lastResponseMetadata = ""
    @Published var selectedModel = "" { didSet { defaults.set(selectedModel, forKey: "planModel") } }
    @Published private var reasoningPreferences: [String: String] = [:] {
        didSet { defaults.set(reasoningPreferences, forKey: "planReasoningEfforts") }
    }
    let events = PassthroughSubject<[String: Any], Never>()
    let stateDirectory: URL
    var workingDirectory: URL { stateDirectory }
    let readerThreadConfiguration: [String: Any] = [:]
    private let defaults: UserDefaults
    private let session: URLSession
    private let openURL: (URL) -> Bool
    private let allowsCredentialRefresh: Bool
    private let storage: PlanCredentialStore
    private var credentials: PlanCredentials?
    private var initialized = false
    private var generation = UUID()
    private var connectionTask: Task<Void, Error>?
    private var refreshTask: Task<PlanCredentials, Error>?
    private var loginTask: Task<Void, Never>?
    private var listener: PlanLoopbackListener?
    private var loginAttempt: UUID?
    private struct Conversation {
        let instructions: String
        var exchanges: [[[String: Any]]] = []
        var activeTurn: String?
    }
    private var conversations: [String: Conversation] = [:]
    private var turns: [String: Task<Void, Never>] = [:]

    init(stateDirectory: URL? = nil, defaults: UserDefaults = .standard,
         session: URLSession? = nil, allowsCredentialRefresh: Bool = true, openURL: ((URL) -> Bool)? = nil) {
        self.defaults = defaults
        self.allowsCredentialRefresh = allowsCredentialRefresh
        self.stateDirectory = stateDirectory ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("iSmartPDFReader/ChatGPT", isDirectory: true)
        storage = PlanCredentialStore(directory: self.stateDirectory)
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 60
        configuration.timeoutIntervalForResource = 600
        configuration.urlCache = nil
        configuration.httpShouldSetCookies = false
        self.session = session ?? URLSession(configuration: configuration)
        self.openURL = openURL ?? { NSWorkspace.shared.open($0) }
        selectedModel = defaults.string(forKey: "planModel") ?? ""
        reasoningPreferences = defaults.dictionary(forKey: "planReasoningEfforts") as? [String: String] ?? [:]
    }

    var isSignedIn: Bool { state == .signedIn }
    var statusText: String {
        if isConnecting { return T("正在连接…", "Connecting…") }
        switch state {
        case .disconnected: return T("尚未连接", "Disconnected")
        case .signedOut: return T("请登录 ChatGPT", "Sign in to ChatGPT")
        case .signingIn: return T("请在浏览器完成登录", "Complete sign-in in your browser")
        case .signedIn: return email.isEmpty ? T("已登录 ChatGPT", "Signed in to ChatGPT") : email
        }
    }
    var availableReasoningEfforts: [String] { models.first { $0.id == selectedModel }?.reasoningEfforts ?? [] }
    var selectedReasoningEffort: String {
        get {
            let supported = availableReasoningEfforts
            if let saved = reasoningPreferences[selectedModel], supported.contains(saved) { return saved }
            for value in ["low", "minimal", "none"] where supported.contains(value) { return value }
            return models.first { $0.id == selectedModel }?.defaultReasoningEffort.flatMap { supported.contains($0) ? $0 : nil } ?? supported.first ?? ""
        }
        set { if availableReasoningEfforts.contains(newValue) { reasoningPreferences[selectedModel] = newValue } }
    }
    func reasoningLabel(_ value: String) -> String {
        switch value {
        case "none": return T("无推理（最快）", "None (fastest)")
        case "minimal": return T("极低（更快）", "Minimal (faster)")
        case "low": return T("低（快速）", "Low (fast)")
        case "medium": return T("中（均衡）", "Medium (balanced)")
        case "high": return T("高（深入）", "High (deep)")
        case "xhigh": return T("超高", "Extra high")
        case "max": return T("最高", "Maximum")
        case "ultra": return T("极致", "Ultra")
        default: return value
        }
    }

    func connect() async throws {
        if let connectionTask { return try await connectionTask.value }
        guard !initialized else { return }
        isConnecting = true
        let epoch = generation
        let task = Task {
            let saved = try storage.load()
            guard epoch == generation else { throw CancellationError() }
            credentials = saved; email = saved?.email ?? ""
            state = saved == nil ? .signedOut : .signedIn
            initialized = true
            if saved != nil { try await loadModels() }
        }
        connectionTask = task
        defer { connectionTask = nil; isConnecting = false }
        do { try await task.value } catch { errorMessage = error.localizedDescription; throw error }
    }

    func refresh() {
        Task {
            do {
                let wasInitialized = initialized
                try await connect()
                if wasInitialized, isSignedIn { try await loadModels() }
                errorMessage = nil
            } catch { errorMessage = error.localizedDescription }
        }
    }

    func signIn() {
        guard loginTask == nil, !isConnecting else { return }
        let attempt = UUID(); loginAttempt = attempt
        loginTask = Task {
            do {
                // Restore the registration even if its network access needs reauthorization.
                if !initialized {
                    credentials = try storage.load(); initialized = true
                    email = credentials?.email ?? ""
                }
                errorMessage = nil; state = .signingIn
                let previous = credentials
                let verifier = try PlanOAuth.random(), nonce = try PlanOAuth.random(), stateValue = try PlanOAuth.random()
                let callbackListener = PlanLoopbackListener(state: stateValue)
                listener = callbackListener
                defer { callbackListener.stop(); if loginAttempt == attempt { listener = nil } }
                let port = try await callbackListener.start()
                let redirect = "http://127.0.0.1:\(port)/auth/callback"
                let hostID: String
                if let stored = defaults.string(forKey: "chatgptHostID"), stored.hasPrefix("urn:uuid:") { hostID = stored }
                else { hostID = "urn:uuid:" + UUID().uuidString.lowercased(); defaults.set(hostID, forKey: "chatgptHostID") }
                let timeout = Task {
                    do { try await Task.sleep(nanoseconds: 300_000_000_000) } catch { return }
                    callbackListener.stop(ClientError.message(T("登录已超时，请重试。", "Sign-in timed out. Please retry.")))
                }
                defer { timeout.cancel() }
                guard openURL(PlanOAuth.authorizationURL(hostID: hostID, redirect: redirect, state: stateValue,
                                                       nonce: nonce, verifier: verifier, previous: previous)) else {
                    throw ClientError.message(T("无法打开系统浏览器。", "Could not open the system browser."))
                }
                let returned = try await callbackListener.callback()
                try Task.checkCancellation()
                let result = try PlanOAuth.callback(returned, state: stateValue, previous: previous)
                let tokens = try await json(PlanOAuth.formRequest(path: "/api/accounts/oauth/token", values: [
                    "grant_type": "authorization_code", "client_id": result.clientID, "code": result.code,
                    "code_verifier": verifier, "redirect_uri": redirect, "resource": PlanOAuth.resource]))
                let saved = try await validatedCredentials(tokens, clientID: result.clientID, nonce: nonce, previous: previous)
                guard loginAttempt == attempt, !Task.isCancelled else { throw CancellationError() }
                try storage.save(saved)
                cancelTurns(); generation = UUID(); credentials = saved; email = saved.email
                state = .signedIn; models = []
                events.send(["method": "reader/accountCleared"])
                try await loadModels()
                NSApp.requestUserAttention(.informationalRequest)
            } catch is CancellationError {
                if loginAttempt == attempt { state = credentials == nil ? .signedOut : .signedIn }
            } catch {
                if loginAttempt == attempt { state = credentials == nil ? .signedOut : .signedIn; errorMessage = error.localizedDescription }
            }
            if loginAttempt == attempt { loginAttempt = nil; loginTask = nil }
        }
    }

    func cancelLogin() async {
        loginAttempt = nil; loginTask?.cancel(); loginTask = nil
        listener?.stop(); listener = nil
        state = credentials == nil ? .signedOut : .signedIn
    }
    func signOut() {
        Task {
            await cancelLogin()
            do {
                try storage.remove()
                generation = UUID(); refreshTask?.cancel(); refreshTask = nil; cancelTurns()
                credentials = nil; email = ""; plan = ""; models = []; selectedModel = ""
                state = .signedOut; errorMessage = nil; initialized = true
                events.send(["method": "reader/accountCleared"])
            } catch { errorMessage = error.localizedDescription }
        }
    }
    func disconnect() {
        generation = UUID(); connectionTask?.cancel(); connectionTask = nil
        refreshTask?.cancel(); refreshTask = nil; loginTask?.cancel(); loginTask = nil
        listener?.stop(); listener = nil; loginAttempt = nil; cancelTurns()
        credentials = nil; state = .disconnected; initialized = false
        events.send(["method": "reader/disconnected"])
    }
    private func cancelTurns() {
        for task in turns.values { task.cancel() }
        turns.removeAll(); conversations.removeAll()
    }
    func releaseConversation(_ id: String) {
        if let turn = conversations[id]?.activeTurn { turns.removeValue(forKey: turn)?.cancel() }
        conversations.removeValue(forKey: id)
    }

    private func json(_ request: URLRequest) async throws -> [String: Any] {
        let (data, response) = try await session.data(for: request)
        try Task.checkCancellation()
        guard let http = response as? HTTPURLResponse else { throw ClientError.message("Invalid network response") }
        guard (200..<300).contains(http.statusCode) else { throw Self.networkError(data, status: http.statusCode) }
        guard let value = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw ClientError.message(T("服务返回了无效数据。", "The service returned invalid data."))
        }
        return value
    }

    private func validatedCredentials(_ tokens: [String: Any], clientID: String, nonce: String?, previous: PlanCredentials?) async throws -> PlanCredentials {
        guard tokens["token_type"] as? String == "Bearer" || tokens["token_type"] as? String == "bearer",
              let access = tokens["access_token"] as? String, !access.isEmpty,
              let refresh = (tokens["refresh_token"] as? String) ?? previous?.refreshToken, !refresh.isEmpty,
              let seconds = tokens["expires_in"] as? TimeInterval, seconds > 0 else {
            throw ClientError.message(T("授权信息不完整，请重新登录。", "Incomplete authorization. Sign in again."))
        }
        let scopeString = tokens["scope"] as? String
        // OAuth permits an omitted scope on refresh to mean unchanged. Never infer new grants.
        let scopes = scopeString.map { $0.split(separator: " ").map(String.init) } ?? (nonce == nil ? previous?.scopes : nil) ?? []
        let token = tokens["id_token"] as? String
        let claims: [String: Any]
        if let token {
            let discovery = try await json(URLRequest(url: URL(string: PlanOAuth.issuer + "/.well-known/openid-configuration")!))
            guard discovery["issuer"] as? String == PlanOAuth.issuer,
                  let jwksURL = (discovery["jwks_uri"] as? String).flatMap(URL.init(string:)),
                  jwksURL.scheme == "https", jwksURL.host == "auth.openai.com", jwksURL.user == nil else {
                throw ClientError.message("Invalid OpenAI discovery metadata")
            }
            let keys = try await json(URLRequest(url: jwksURL))
            claims = try PlanOAuth.validateIDToken(token, clientID: clientID, nonce: nonce, jwks: keys)
        } else if nonce == nil, let previous { claims = ["sub": previous.subject, "email": previous.email] }
        else { throw ClientError.message(T("未收到身份信息，请重试登录。", "No verified identity was returned. Sign in again.")) }
        guard let subject = claims["sub"] as? String,
              previous == nil || (previous?.subject == subject && previous?.issuer == PlanOAuth.issuer && previous?.clientID == clientID) else {
            throw ClientError.message(T("返回的账号与当前账号不匹配，请先退出账号。", "The returned account does not match. Sign out before changing accounts."))
        }
        return PlanCredentials(clientID: clientID, subject: subject, issuer: PlanOAuth.issuer,
            email: claims["email"] as? String ?? previous?.email ?? "", idToken: token ?? previous!.idToken,
            accessToken: access, refreshToken: refresh, scopes: scopes, expiresAt: Date().addingTimeInterval(seconds))
    }

    private func accessToken() async throws -> String {
        guard let current = credentials else { throw ClientError.message(T("请先登录 ChatGPT。", "Sign in to ChatGPT first.")) }
        let epoch = generation
        if current.expiresAt.timeIntervalSinceNow < 60 {
            guard allowsCredentialRefresh else {
                throw ClientError.message(T("请先在阅读器内刷新登录状态，再运行连接测试。", "Refresh sign-in in the reader before running the connection check."))
            }
            if refreshTask == nil {
                refreshTask = Task {
                    let tokens = try await json(PlanOAuth.formRequest(path: "/api/accounts/oauth/token", values: [
                        "grant_type": "refresh_token", "client_id": current.clientID,
                        "refresh_token": current.refreshToken, "resource": PlanOAuth.resource]))
                    let saved = try await validatedCredentials(tokens, clientID: current.clientID, nonce: nil, previous: current)
                    guard epoch == generation, !Task.isCancelled else { throw CancellationError() }
                    try storage.save(saved); credentials = saved; email = saved.email
                    return saved
                }
            }
            guard let task = refreshTask else { throw CancellationError() }
            defer { if epoch == generation { refreshTask = nil } }
            _ = try await task.value
        }
        guard epoch == generation, let saved = credentials else { throw CancellationError() }
        guard saved.scopes.contains("chatgpt.tokens.use.direct") else {
            throw ClientError.message(T("尚未授权使用 ChatGPT 套餐额度，请在设置中重新授权。", "ChatGPT plan usage is not authorized. Reauthorize in Settings."))
        }
        return saved.accessToken
    }

    private func loadModels() async throws {
        let epoch = generation
        var request = URLRequest(url: URL(string: PlanOAuth.resource + "/models")!)
        request.setValue("Bearer " + (try await accessToken()), forHTTPHeaderField: "Authorization")
        let result = try await json(request)
        guard epoch == generation else { throw CancellationError() }
        let catalog = try Self.parseModels(result)
        models = catalog
        if !catalog.contains(where: { $0.id == selectedModel }) { selectedModel = catalog.first?.id ?? "" }
    }

    static func parseModels(_ result: [String: Any]) throws -> [Model] {
        guard let list = result["models"] as? [[String: Any]] else { throw ClientError.message("Invalid model catalog") }
        var seen = Set<String>()
        return list.compactMap { value in
            guard value["visibility"] as? String == "list", let slug = value["slug"] as? String, !slug.isEmpty,
                  seen.insert(slug).inserted else { return nil }
            let raw = value["supported_reasoning_efforts"] as? [Any] ?? value["supported_reasoning_levels"] as? [Any] ?? []
            let efforts = raw.compactMap { item -> String? in
                if let string = item as? String { return string }
                let object = item as? [String: Any]
                return object?["reasoning_effort"] as? String ?? object?["effort"] as? String
            }
            // Only expose levels advertised by the account catalog; never guess model capabilities.
            return Model(id: slug, name: value["display_name"] as? String ?? slug,
                reasoningEfforts: efforts, defaultReasoningEffort: value["default_reasoning_effort"] as? String)
        }
    }

    func request(_ method: String, _ params: [String: Any], timeout: TimeInterval = 30) async throws -> [String: Any] {
        switch method {
        case "thread/start":
            let id = UUID().uuidString
            conversations[id] = Conversation(instructions: params["baseInstructions"] as? String ?? "")
            return ["thread": ["id": id]]
        case "turn/interrupt":
            if let id = params["threadId"] as? String, let turn = params["turnId"] as? String, conversations[id]?.activeTurn == turn {
                conversations[id]?.activeTurn = nil; turns.removeValue(forKey: turn)?.cancel()
                emit("turn/completed", thread: id, turn: turn, extra: ["turn": ["id": turn, "status": "interrupted"]])
            }
            return [:]
        case "turn/start":
            guard let thread = params["threadId"] as? String, var conversation = conversations[thread], conversation.activeTurn == nil,
                  let input = params["input"] as? [[String: Any]], let model = params["model"] as? String,
                  models.contains(where: { $0.id == model }) else {
                throw ClientError.message(T("请选择账号可用的模型后重试。", "Choose an available model and retry."))
            }
            let content: [[String: Any]] = input.compactMap {
                if $0["type"] as? String == "text", let text = $0["text"] as? String { return ["type": "input_text", "text": text] }
                if $0["type"] as? String == "image", let url = $0["url"] as? String { return ["type": "input_image", "image_url": url] }
                return nil
            }
            let turn = UUID().uuidString
            let user: [String: Any] = ["role": "user", "content": content]
            let history = conversation.exchanges.flatMap { $0 } + [user]
            var body: [String: Any] = ["model": model, "input": history, "instructions": conversation.instructions, "stream": true, "store": false]
            if let effort = params["effort"] as? String, models.first(where: { $0.id == model })?.reasoningEfforts.contains(effort) == true {
                body["reasoning"] = ["effort": effort]
            }
            conversation.activeTurn = turn; conversations[thread] = conversation
            turns[turn] = Task { await self.stream(body, user: user, thread: thread, turn: turn) }
            return ["turn": ["id": turn]]
        default: throw ClientError.message("Unsupported reader operation")
        }
    }

    private func emit(_ method: String, thread: String, turn: String, extra: [String: Any] = [:]) {
        var params = extra; params["threadId"] = thread; params["turnId"] = turn
        events.send(["method": method, "params": params])
    }

    private func stream(_ body: [String: Any], user: [String: Any], thread: String, turn: String) async {
        guard conversations[thread]?.activeTurn == turn else { return }
        emit("turn/started", thread: thread, turn: turn, extra: ["turn": ["id": turn]])
        var text = "", completed = false
        do {
            var request = URLRequest(url: URL(string: PlanOAuth.resource + "/responses")!)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue("text/event-stream", forHTTPHeaderField: "Accept")
            request.setValue("Bearer " + (try await accessToken()), forHTTPHeaderField: "Authorization")
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
            let (bytes, response) = try await session.bytes(for: request)
            guard let http = response as? HTTPURLResponse else { throw ClientError.message("Invalid network response") }
            let metadata = "HTTP \(http.statusCode); type=\(http.value(forHTTPHeaderField: "Content-Type") ?? "missing"); host=\(http.url?.host ?? "missing")"
            lastResponseMetadata = metadata
            guard (200..<300).contains(http.statusCode) else {
                var data = Data()
                for try await byte in bytes { if data.count >= 65_536 { break }; data.append(byte) }
                throw Self.networkError(data, status: http.statusCode)
            }
            guard http.url?.scheme == "https", http.url?.host == "api.openai.com" else {
                throw ClientError.message(T("问答请求被转到了其他页面，请检查网络后重试。", "The answer request was redirected to another page. Check your connection and retry."))
            }
            var decoder = PlanResponseDecoder()
            defer { lastResponseMetadata = metadata + "; body=" + decoder.kind }
            let item = "answer-" + turn
            func consume(_ event: [String: Any]) throws {
                let type = event["type"] as? String ?? ""
                if type == "response.output_text.delta", let delta = event["delta"] as? String {
                    text += delta
                    emit("item/agentMessage/delta", thread: thread, turn: turn, extra: ["itemId": item, "delta": delta])
                } else if type == "response.completed" {
                    guard let response = event["response"] as? [String: Any], response["status"] as? String == "completed" else {
                        throw ClientError.message(T("回答未正常完成，请重试。", "The response did not complete. Please retry."))
                    }
                    let finalText = Self.responseText(response)
                    if !finalText.isEmpty { text = finalText }
                    completed = true
                } else if ["response.failed", "response.incomplete", "error"].contains(type) {
                    let response = event["response"] as? [String: Any] ?? event
                    let error = response["error"] as? [String: Any] ?? response["incomplete_details"] as? [String: Any] ?? response
                    throw Self.serviceError(error["code"] as? String ?? error["reason"] as? String ?? "response_incomplete", status: nil)
                }
            }
            for try await byte in bytes {
                try Task.checkCancellation()
                guard conversations[thread]?.activeTurn == turn else { return }
                if let event = try decoder.byte(byte) { try consume(event) }
                if completed { break }
            }
            if !completed, let event = try decoder.finish() { try consume(event) }
            guard completed else { throw ClientError.message(T("回答连接提前断开，内容可能不完整。请重试。", "The response connection ended early. The answer may be incomplete. Please retry.")) }
            guard conversations[thread]?.activeTurn == turn, !Task.isCancelled else { return }
            emit("item/completed", thread: thread, turn: turn, extra: ["item": ["type": "agentMessage", "id": item, "text": text]])
            // Full exchanges stay local. Resend them because this flow does not store server conversations.
            conversations[thread]?.exchanges.append([user, ["role": "assistant", "content": text]])
            finish(thread: thread, turn: turn, status: "completed")
        } catch is CancellationError {
            if conversations[thread]?.activeTurn == turn { finish(thread: thread, turn: turn, status: "interrupted") }
        } catch {
            guard conversations[thread]?.activeTurn == turn else { return }
            finish(thread: thread, turn: turn, status: "failed", message: error.localizedDescription)
        }
    }

    private static func responseText(_ response: [String: Any]) -> String {
        (response["output"] as? [[String: Any]] ?? []).compactMap { item -> String? in
            guard item["type"] as? String == "message" else { return nil }
            let parts = (item["content"] as? [[String: Any]] ?? []).compactMap { part -> String? in
                if part["type"] as? String == "output_text" { return part["text"] as? String }
                if part["type"] as? String == "refusal" { return part["refusal"] as? String }
                return nil
            }
            return parts.isEmpty ? nil : parts.joined()
        }.joined(separator: "\n\n")
    }

    private func finish(thread: String, turn: String, status: String, message: String? = nil) {
        conversations[thread]?.activeTurn = nil; turns.removeValue(forKey: turn)
        var result: [String: Any] = ["id": turn, "status": status]
        if let message { result["error"] = ["message": message] }
        emit("turn/completed", thread: thread, turn: turn, extra: ["turn": result])
    }
    private static func networkError(_ data: Data, status: Int) -> ClientError {
        let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
        let error = object["error"] as? [String: Any]
        return serviceError(error?["code"] as? String ?? object["error"] as? String ?? "", status: status)
    }
    static func serviceError(_ code: String, status: Int?) -> ClientError {
        switch code {
        case "subscription_sharing_usage_limit_exceeded": return .message(T("ChatGPT 共享额度已用完，请稍后再试或在 ChatGPT 中检查额度。", "ChatGPT shared usage limit reached. Retry later or check your limits in ChatGPT."))
        case "subscription_sharing_usage_unavailable": return .message(T("当前账号或工作区暂不可使用 ChatGPT 共享额度。请在 ChatGPT 中检查接入权限。", "ChatGPT shared usage is unavailable for this account or workspace. Check access in ChatGPT."))
        case "invalid_grant", "invalid_token": return .message(T("ChatGPT 授权已失效，请在设置中重新授权。", "ChatGPT authorization expired. Reauthorize in Settings."))
        default:
            if status == 401 { return .message(T("ChatGPT 授权无效，请重新授权。", "ChatGPT authorization is invalid. Reauthorize.")) }
            if status == 403 { return .message(T("账号暂无法使用此功能或模型，请检查 ChatGPT 权限。", "This feature or model is unavailable. Check ChatGPT access.")) }
            if status == 429 { return .message(T("请求过多或额度不足，请稍后重试。", "Too many requests or insufficient quota. Retry later.")) }
            let suffix = status.map { " (HTTP \($0))" } ?? ""
            return .message(T("回答未完成，请检查网络、模型权限和账号额度后重试。", "Response did not complete. Check network, model access and account limits.") + suffix)
        }
    }
}
#endif
