#if APP_STORE
import Foundation

/// App-owned data only. No other application's account directory is inspected.
struct PlanCredentialStore {
    let directory: URL
    private var file: URL { directory.appendingPathComponent("chatgpt-account.json") }

    func load() throws -> PlanCredentials? {
        guard FileManager.default.fileExists(atPath: file.path) else { return nil }
        let values = try file.resourceValues(forKeys: [.isSymbolicLinkKey, .isRegularFileKey])
        guard values.isSymbolicLink != true, values.isRegularFile == true else {
            throw PlanAuthError.message("Invalid account storage")
        }
        return try JSONDecoder().decode(PlanCredentials.self, from: Data(contentsOf: file))
    }

    func save(_ credentials: PlanCredentials) throws {
        let manager = FileManager.default
        try manager.createDirectory(at: directory, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        guard try directory.resourceValues(forKeys: [.isSymbolicLinkKey]).isSymbolicLink != true else {
            throw PlanAuthError.message("Invalid account directory")
        }
        try manager.setAttributes([.posixPermissions: 0o700], ofItemAtPath: directory.path)
        let temporary = directory.appendingPathComponent(UUID().uuidString + ".tmp")
        defer { try? manager.removeItem(at: temporary) }
        let bytes = try JSONEncoder().encode(credentials)
        guard manager.createFile(atPath: temporary.path, contents: bytes, attributes: [.posixPermissions: 0o600]) else {
            throw PlanAuthError.message(T("无法安全保存登录状态。", "Could not securely save sign-in."))
        }
        // POSIX rename replaces the whole record atomically, including a rotated refresh token.
        guard rename(temporary.path, file.path) == 0 else {
            throw PlanAuthError.message(T("无法更新登录状态。", "Could not update sign-in."))
        }
    }

    func remove() throws {
        if FileManager.default.fileExists(atPath: file.path) { try FileManager.default.removeItem(at: file) }
    }
}

/// SSE framing is separate from transport so partial, multiline and truncated streams are testable.
struct PlanSSEDecoder {
    private var dataLines: [String] = []
    private var size = 0
    mutating func line(_ input: String) throws -> [String: Any]? {
        let value = input.hasSuffix("\r") ? String(input.dropLast()) : input
        if value.isEmpty {
            defer { dataLines.removeAll(keepingCapacity: true); size = 0 }
            guard !dataLines.isEmpty else { return nil }
            let payload = dataLines.joined(separator: "\n")
            if payload == "[DONE]" { return nil }
            guard let bytes = payload.data(using: .utf8),
                  let event = try JSONSerialization.jsonObject(with: bytes) as? [String: Any] else {
                throw PlanAuthError.message(T("回答数据格式异常，请重试。", "Invalid response stream. Please retry."))
            }
            return event
        }
        if value.hasPrefix("data:") {
            var field = String(value.dropFirst(5))
            if field.first == " " { field.removeFirst() }
            size += field.utf8.count
            guard size <= 16_000_000 else { throw PlanAuthError.message("Response event is too large") }
            dataLines.append(field)
        }
        return nil
    }
}

/// Inspect framing rather than trusting MIME headers, which some gateways omit or rewrite.
/// Only structured Responses terminal events can complete a turn; HTML is never answer text.
struct PlanResponseDecoder {
    private enum Mode { case detecting, sse, json }
    private var mode: Mode = .detecting
    private var prefix = Data()
    private var line = Data()
    private var json = Data()
    private var wasCR = false
    private var sse = PlanSSEDecoder()
    private(set) var kind = "undetermined"

    mutating func byte(_ byte: UInt8) throws -> [String: Any]? {
        switch mode {
        case .json:
            guard json.count < 16_000_000 else { throw invalidFormat() }
            json.append(byte); return nil
        case .sse: return try sseByte(byte)
        case .detecting:
            prefix.append(byte)
            guard prefix.count <= 128 else { throw invalidFormat() }
            // A UTF-8 BOM may be split between received bytes.
            if prefix.first == 0xEF {
                if prefix.count < 3 { return nil }
                guard prefix.starts(with: [0xEF, 0xBB, 0xBF]) else { throw invalidFormat() }
                prefix = Data(prefix.dropFirst(3))
            }
            guard let string = String(data: prefix, encoding: .utf8) else {
                if prefix.count < 4 { return nil }
                throw invalidFormat()
            }
            let start = string.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !start.isEmpty else { return nil }
            if start.first == "<" {
                kind = "html"
                throw PlanAuthError.message(T("服务返回了网页而非问答数据。请检查网络连接，稍后重试。", "The service returned a web page instead of answer data. Check your connection and retry later."))
            }
            if start.first == "{" || start.first == "[" {
                mode = .json; kind = "json"; json = Data(start.utf8); prefix.removeAll(); return nil
            }
            let fields = ["data:", "event:", "id:", "retry:", ":"]
            guard fields.contains(where: { $0.hasPrefix(start) || start.hasPrefix($0) }) else { throw invalidFormat() }
            guard fields.contains(where: { start.hasPrefix($0) }) else { return nil }
            mode = .sse; kind = "sse"; prefix.removeAll()
            for value in start.utf8 { _ = try sseByte(value) }
            return nil
        }
    }

    mutating func finish() throws -> [String: Any]? {
        switch mode {
        case .detecting: return nil
        case .sse:
            if !line.isEmpty { _ = try consumeLine() }
            return try sse.line("")
        case .json:
            guard let object = (try? JSONSerialization.jsonObject(with: json)) as? [String: Any] else { throw invalidFormat() }
            if let error = object["error"] as? [String: Any] { return ["type": "error", "error": error] }
            if let code = object["error"] as? String { return ["type": "error", "error": ["code": code]] }
            guard object["object"] as? String == "response", let status = object["status"] as? String,
                  ["completed", "failed", "incomplete"].contains(status) else { throw invalidFormat() }
            return ["type": "response." + status, "response": object]
        }
    }

    private mutating func sseByte(_ byte: UInt8) throws -> [String: Any]? {
        if byte == 10 && wasCR { wasCR = false; return nil }
        wasCR = byte == 13
        if byte == 10 || byte == 13 { return try consumeLine() }
        guard line.count < 16_000_000 else { throw invalidFormat() }
        line.append(byte); return nil
    }
    private mutating func consumeLine() throws -> [String: Any]? {
        guard let string = String(data: line, encoding: .utf8) else { throw invalidFormat() }
        line.removeAll(keepingCapacity: true)
        return try sse.line(string)
    }
    private func invalidFormat() -> PlanAuthError {
        .message(T("服务返回的问答数据无法识别，请稍后重试。", "The service returned unrecognized answer data. Please retry later."))
    }
}
#endif
