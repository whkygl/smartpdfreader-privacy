# iSmartPDFReader

Free, open-source macOS PDF reader with clear, movable annotations, ChatGPT account Q&A and the interactive “页灵” (Page Sprite) companion.

## App Store edition — 1.2.0

Preview build 11 recognizes valid response framing even if a gateway omits or rewrites MIME headers. It rejects HTML and incomplete answers, and preserves explicit quota errors.

The store edition uses native Sign in with ChatGPT, HTTP/SSE streaming and App Sandbox. It does not require an API key or an installed Codex executable. Account and workspace access, supported models and usage limits are controlled by OpenAI. Sign-in does not guarantee inference access. This app is independent and is not an OpenAI product.

The source is licensed under MIT. That license covers this application's code and original artwork; it does not grant rights to third-party services, brands, Apple assets or ChatGPT subscriptions. Keep the app free and open source when using the documented open-source ChatGPT plan flow. A paid or hosted derivative must arrange its own permitted integration.

### Build and test

Requires macOS 14+, a current Swift toolchain with a compatible macOS SDK, and Python 3 for build helpers. No third-party Swift dependencies are used.

```sh
bash scripts/test-store.sh
bash scripts/test-local.sh
bash scripts/test-annotations.sh
bash scripts/build-local.sh --store-preview
```

The preview is a local test build with a separate bundle identifier. It is not an App Store upload package. `Build/last-store-preview-path.txt` identifies the signed staging copy. The icon renderer regenerates all icon sizes from `SidebarPet.swift`.

To archive the original App Store app, use the shared `iSmartPDFReader-Store` scheme and `AppStore/Release.xcconfig`:

```sh
bash scripts/archive-store.sh
```

The account holder must accept applicable Apple agreements and configure distribution signing in Xcode. Set your own team and bundle identifier when building a fork. Do not attempt to upload a local ad hoc preview. App Store approval is separate from a successful local build.

The ordinary build, `bash scripts/build-local.sh`, retains the earlier personal Codex app-server client for local use. The `APP_STORE` compilation condition selects the self-contained native client. Personal account directories are separate from the store edition and from other applications.

### Data and security

Opening a PDF extracts text locally. Sending a question shares selected PDF excerpts, the question, selections, attached images and required conversation context directly with OpenAI, after the user's first-send permission. No developer relay server, analytics or advertising SDK is included. Conversation history stays in process memory and is resent as needed; it is not synchronized with ChatGPT web history. Long documents use bounded local excerpt retrieval, which cannot establish findings in omitted pages.

OAuth uses an IPv4 loopback listener, fresh state/nonce, PKCE S256, an issued client registration and verified RS256 ID tokens. Credentials stay in an app-owned directory with owner-only file permissions; refresh-token rotation replaces the record atomically. Signing out clears this app's credentials. Never publish that directory, screenshots containing account details, tokens, signing keys or private PDFs. See [PRIVACY.md](PRIVACY.md).

The native client supplies no skills, commands, plugins or tools to the model. PDF content is treated as reference material. Supported reasoning choices come from the model catalog; low is preferred when available. Lower reasoning can reduce wait time but cannot guarantee a particular latency.

### Interface

- Context-menu text and text dragged from Q&A default to 11-point red vector text. Drag to move; double-click to edit. Moving supports undo/redo.
- Note icons open compact editable cards with scrollable text and resizing.
- “页灵” follows the pointer with its eyes and cycles six click actions. It respects Reduce Motion.
- Chinese and English are available in Settings.

### Verification

Offline tests exercise OAuth callback attacks and ID signatures, protected storage, refresh rotation, SSE fragments and late failures, independent window history, cancellation, model reasoning, PDF excerpt retrieval, Markdown, annotations, PDF save/reload and pet actions. They use synthetic fixtures and send no personal PDFs. Live sign-in and store signing must also be checked before submission.

Official integration references: [Sign in](https://developers.openai.com/siwc/token-sharing-open-source/sign-in), [models and inference](https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference), [preview limitations](https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations).

## 中文说明

这是 iSmartPDFReader 的免费开源源码。商店配置保留原应用标识，改用原生 ChatGPT 账号登录，不需要 API Key 或另装 Codex。ChatGPT 功能需要账号和工作区支持相应接入，模型、额度与可用性由 OpenAI 决定。阅读和批注 PDF 无需登录。

右键和拖入的文字默认采用清晰的 11 号红字，支持移动、编辑和撤销；右侧页灵会跟随鼠标，点击触发不同动作。首次发送问题会征求向 OpenAI 分享所需内容的许可，设置中可撤回。

`--store-preview` 构建只供本机验证。正式归档、签名、上传和审核需使用 Apple 开发者账户；源码公开或本机构建通过都不代表已上架。
